function [S, T]=DPWM_3L(Vref,theta,Vdc,f)
T=[0 ;0 ;0];
S=[0 0 0;
    0 0 0 ;
    0 0 0];
Ts=1/f;

%% Vector in whole space
% Zero Vectors
Vector(7)=0;
Vector(8)=0;
Vector(9)=0;

% Positive Small Vectors
Vector(2)=1/3*Vdc*(cos(pi/3)+sin(pi/3)*j);
Vector(4)=1/3*Vdc*(cos(3*pi/3)+sin(3*pi/3)*j);
Vector(6)=1/3*Vdc*(cos(5*pi/3)+sin(5*pi/3)*j);
Vector(10)=1/3*Vdc*(cos(0*pi/3)+sin(0*pi/3)*j);
Vector(12)=1/3*Vdc*(cos(2*pi/3)+sin(2*pi/3)*j);
Vector(14)=1/3*Vdc*(cos(4*pi/3)+sin(4*pi/3)*j);

% Negative Small Vectors
Vector(1)=1/3*Vdc*(cos(0*pi/3)+sin(0*pi/3)*j);
Vector(3)=1/3*Vdc*(cos(2*pi/3)+sin(2*pi/3)*j);
Vector(5)=1/3*Vdc*(cos(4*pi/3)+sin(4*pi/3)*j);
Vector(11)=1/3*Vdc*(cos(pi/3)+sin(pi/3)*j);
Vector(13)=1/3*Vdc*(cos(3*pi/3)+sin(3*pi/3)*j);
Vector(15)=1/3*Vdc*(cos(5*pi/3)+sin(5*pi/3)*j);

% Large Vectors
Vector(16)=2/3*Vdc;
Vector(18)=2/3*Vdc*(cos(pi/3)+sin(pi/3)*j);
Vector(20)=2/3*Vdc*(cos(2*pi/3)+sin(2*pi/3)*j);
Vector(22)=-2/3*Vdc;
Vector(24)=2/3*Vdc*(cos(4*pi/3)+sin(4*pi/3)*j);
Vector(26)=2/3*Vdc*(cos(5*pi/3)+sin(5*pi/3)*j);

% Medium Vectors
Vector(17)=sqrt(3)/3*Vdc*(cos(pi/6)+sin(pi/6)*j);
Vector(19)=sqrt(3)/3*Vdc*(cos(pi/2)+sin(pi/2)*j);
Vector(21)=sqrt(3)/3*Vdc*(cos(5*pi/6)+sin(5*pi/6)*j);
Vector(23)=sqrt(3)/3*Vdc*(cos(7*pi/6)+sin(7*pi/6)*j);
Vector(25)=-sqrt(3)/3*Vdc*j;
Vector(27)=sqrt(3)/3*Vdc*(cos(11*pi/6)+sin(11*pi/6)*j);

%% Switching Function of Each Vector
SF(1,1:3)=[1 0 0];
SF(2,1:3)=[1 1 0];
SF(3,1:3)=[0 1 0];
SF(4,1:3)=[0 1 1];
SF(5,1:3)=[0 0 1];
SF(6,1:3)=[1 0 1];
SF(7,1:3)=[0 0 0];
SF(8,1:3)=[1 1 1];
SF(9,1:3)=[-1 -1 -1];
SF(10,1:3)=[0 -1 -1];
SF(11,1:3)=[0 0 -1];
SF(12,1:3)=[-1 0 -1];
SF(13,1:3)=[-1 0 0];
SF(14,1:3)=[-1 -1 0];
SF(15,1:3)=[0 -1 0];
SF(16,1:3)=[1 -1 -1];
SF(17,1:3)=[1 0 -1];
SF(18,1:3)=[1 1 -1];
SF(19,1:3)=[0 1 -1];
SF(20,1:3)=[-1 1 -1];
SF(21,1:3)=[-1 1 0];
SF(22,1:3)=[-1 1 1];
SF(23,1:3)=[-1 0 1];
SF(24,1:3)=[-1 -1 1];
SF(25,1:3)=[0 -1 1];
SF(26,1:3)=[1 -1 1];
SF(27,1:3)=[1 -1 0];
%% Current Function
CF(1,1:3)=[-1 0 0];
CF(2,1:3)=[0 0 1];
CF(3,1:3)=[0 -1 0];
CF(4,1:3)=[1 0 0];
CF(5,1:3)=[0 0 -1];
CF(6,1:3)=[0 1 0];
CF(7,1:3)=[0 0 0];
CF(8,1:3)=[0 0 0];
CF(9,1:3)=[0 0 0];
CF(10,1:3)=[1 0 0];
CF(11,1:3)=[0 0 -1];
CF(12,1:3)=[0 1 0];
CF(13,1:3)=[-1 0 0];
CF(14,1:3)=[0 0 1];
CF(15,1:3)=[0 -1 0];
CF(16,1:3)=[0 0 0];
CF(17,1:3)=[0 1 0];
CF(18,1:3)=[0 0 0];
CF(19,1:3)=[1 0 0];
CF(20,1:3)=[0 0 0];
CF(21,1:3)=[0 0 1];
CF(22,1:3)=[0 0 0];
CF(23,1:3)=[0 1 0];
CF(24,1:3)=[0 0 0];
CF(25,1:3)=[1 0 0];
CF(26,1:3)=[0 0 0];
CF(27,1:3)=[0 0 1];

%% Sector and Region Calculation
Sector=0;Region=0;

if (theta>=0)&&(theta<pi/3)
    Sector=1+0.5*(theta>pi/6);
    theta_eq=theta-0;
    Va_eq=Vref*cos(theta_eq);
    Vb_eq=Vref*sin(theta_eq);
    if ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)<0)
        Region=1;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)>0)
        Region=2;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)<=0)&&((Vb_eq-sqrt(3)/6*Vdc)<0)
        Region=3;
    else
        Region=4;
    end
end

if (theta>=pi/3)&&(theta<2*pi/3)
    Sector=2+0.5*(theta>3*pi/6);
    theta_eq=theta-pi/3;
    Va_eq=Vref*cos(theta_eq);
    Vb_eq=Vref*sin(theta_eq);
    if ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)<0)
        Region=1;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)>0)
        Region=2;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)<=0)&&((Vb_eq-sqrt(3)/6*Vdc)<0)
        Region=3;
    else
        Region=4;
    end
end

if (theta>=2*pi/3)&&(theta<3*pi/3)
    Sector=3+0.5*(theta>5*pi/6);
    theta_eq=theta-2*pi/3;
    Va_eq=Vref*cos(theta_eq);
    Vb_eq=Vref*sin(theta_eq);
    if ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)<0)
        Region=1;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)>0)
        Region=2;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)<=0)&&((Vb_eq-sqrt(3)/6*Vdc)<0)
        Region=3;
    else
        Region=4;
    end
end

if (theta>=3*pi/3)&&(theta<4*pi/3)
    Sector=4+0.5*(theta>7*pi/6);
    theta_eq=theta-3*pi/3;
    Va_eq=Vref*cos(theta_eq);
    Vb_eq=Vref*sin(theta_eq);
    if ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)<0)
        Region=1;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)>0)
        Region=2;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)<=0)&&((Vb_eq-sqrt(3)/6*Vdc)<0)
        Region=3;
    else
        Region=4;
    end
end

if (theta>=4*pi/3)&&(theta<5*pi/3)
    Sector=5+0.5*(theta>9*pi/6);
    theta_eq=theta-4*pi/3;
    Va_eq=Vref*cos(theta_eq);
    Vb_eq=Vref*sin(theta_eq);
    if ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)<0)
        Region=1;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)>0)
        Region=2;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)<=0)&&((Vb_eq-sqrt(3)/6*Vdc)<0)
        Region=3;
    else
        Region=4;
    end
end

if (theta>=5*pi/3)&&(theta<6*pi/3)
    Sector=6+0.5*(theta>11*pi/6);
    theta_eq=theta-5*pi/3;
    Va_eq=Vref*cos(theta_eq);
    Vb_eq=Vref*sin(theta_eq);
    if ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)<0)
        Region=1;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)>0)
        Region=2;
    elseif ((Va_eq+sqrt(3)/3*Vb_eq-Vdc/3)>=0)&&((Va_eq-sqrt(3)/3*Vb_eq-Vdc/3)<=0)&&((Vb_eq-sqrt(3)/6*Vdc)<0)
        Region=3;
    else
        Region=4;
    end
end
%% DPWM Calculation
    Valfa=Vref*cos(theta);
    Vbelta=Vref*sin(theta);
%% Sector 1  
    %% clamp a phase positive rail
% region=1
    if (Sector==1)&&(Region==1)
    i=1;g=2;h=8;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];
% region=2
    elseif (Sector==1)&&(Region==2)
    i=16;g=17;h=1;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];
% region=3
    elseif (Sector==1)&&(Region==3)
    i=2;g=1;h=17;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);    
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];
% region=4
    elseif (Sector==1)&&(Region==4)
    i=17;g=18;h=2;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h); 
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];    
    end
%% Sector 1  
    %% clamp c phase negtive rail 

% region=1   
    if (Sector==1.5)&&(Region==1)
    i=11;g=10;h=9;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h); 
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 2
    elseif (Sector==1.5)&&(Region==2)  
    i=17;g=16;h=10;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 3
    elseif (Sector==1.5)&&(Region==3)
    i=10;g=11;h=17;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 4
    elseif (Sector==1.5)&&(Region==4)
    i=18;g=17;h=11;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];       
    end
%% Sector 2
	%% clamp c phase negtive rail
% region 1
    if (Sector==2)&&(Region==1)
    i=11;g=12;h=9;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 2
    elseif (Sector==2)&&(Region==2)
    i=18;g=19;h=11;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 3
    elseif (Sector==2)&&(Region==3)
    i=12;g=11;h=19;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 4
    elseif (Sector==2)&&(Region==4)
    i=19;g=20;h=12;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];         
    end
%% Sector 2
    %% clamp b phase positive rail
% region 1
    if (Sector==2.5)&&(Region==1)
    i=3;g=2;h=8;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 2
    elseif (Sector==2.5)&&(Region==2)
    i=19;g=18;h=2;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 3
    elseif (Sector==2.5)&&(Region==3)
    i=2;g=3;h=19;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 4
    elseif (Sector==2.5)&&(Region==4)
    i=20;g=19;h=3;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];      
    end
%% Sector 3
%% clamp b phase positive rail
% region 1
    if (Sector==3)&&(Region==1)
    i=3;g=4;h=8;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 2
    elseif (Sector==3)&&(Region==2)

    i=20;g=21;h=3;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 3
    elseif (Sector==3)&&(Region==3)
    i=4;g=3;h=21;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 4
    elseif (Sector==3)&&(Region==4)
    i=21;g=22;h=4;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];         
    end
%% Sector 3
    %% clamp a phase negtive rail
% region 1
    if (Sector==3.5)&&(Region==1)
    i=13;g=12;h=9;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 2
    elseif (Sector==3.5)&&(Region==2)
    i=21;g=20;h=12;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 3
    elseif (Sector==3.5)&&(Region==3)
    i=12;g=13;h=21;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 4
    elseif (Sector==3.5)&&(Region==4)
   i=22;g=21;h=13;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];      
    end
%% Sector 4
    %% clamp a phase negtive rail
% region 1
    if (Sector==4)&&(Region==1)
    i=13;g=14;h=9;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 2
    elseif (Sector==4)&&(Region==2)
    i=22;g=23;h=13;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 3
    elseif (Sector==4)&&(Region==3)
    i=14;g=13;h=23;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 4
    elseif (Sector==4)&&(Region==4)
    i=23;g=24;h=14;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];       
    end
%% Sector 4
    %% clamp c phase positive rail
% region 1
    if (Sector==4.5)&&(Region==1)
    i=5;g=4;h=8;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 2
    elseif (Sector==4.5)&&(Region==2)
    i=23;g=22;h=4;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 3
    elseif (Sector==4.5)&&(Region==3)
    i=4;g=5;h=23;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 4
    elseif (Sector==4.5)&&(Region==4)
    i=24;g=23;h=5;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];       
    end
%% Sector 5
    %% clamp c phase positive rail
% region 1
    if (Sector==5)&&(Region==1)
    i=5;g=6;h=8;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 2
    elseif (Sector==5)&&(Region==2)
    i=24;g=25;h=5;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 3
    elseif (Sector==5)&&(Region==3)
    i=6;g=5;h=25;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 4
    elseif (Sector==5)&&(Region==4)
    i=25;g=26;h=6;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];      
    end   
%% Sector 5
    %% clamp b phase negtive rail
% region 1
    if (Sector==5.5)&&(Region==1)
    i=15;g=14;h=9;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 2
    elseif (Sector==5.5)&&(Region==2)
    i=25;g=24;h=14;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 3
    elseif (Sector==5.5)&&(Region==3)
    i=14;g=15;h=25;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 4
    elseif (Sector==5.5)&&(Region==4)
    i=26;g=25;h=15;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];    
    end   
%% Sector 6
    %% clamp b phase negtive rail
% region 1
    if (Sector==6)&&(Region==1)
    i=15;g=10;h=9;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 2
    elseif (Sector==6)&&(Region==2)
    i=26;g=27;h=15;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 3
    elseif (Sector==6)&&(Region==3)
    i=10;g=15;h=27;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 4
    elseif (Sector==6)&&(Region==4)
    i=27;g=16;h=10;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];       
    end   
%% Sector 6
    %% clamp a phase positive rail
% region 1
    if (Sector==6.5)&&(Region==1)
    i=1;g=6;h=8;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 2
    elseif (Sector==6.5)&&(Region==2)
    i=27;g=26;h=6;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 3
    elseif (Sector==6.5)&&(Region==3)
    i=6;g=1;h=27;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];  
% region 4
    elseif (Sector==6.5)&&(Region==4)
    i=16;g=27;h=1;
    Va=Vector(i);Vb=Vector(g);Vc=Vector(h);
    A=[1 1 1;
    real(Va) real(Vb) real(Vc);
    imag(Va) imag(Vb) imag(Vc)];
    B=[Ts; 	Valfa*Ts; Vbelta*Ts];
    T=(inv(A)*B)';
    S=[SF(i,1:3) ;
       SF(g,1:3) ;
       SF(h,1:3)];    
    end   
    end