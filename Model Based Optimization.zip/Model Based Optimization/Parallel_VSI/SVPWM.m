function [S, T]=SVPWM(Vref,theta,Vdc,f)
T=[0 0 0];
S=[0 0 0;
    0 0 0 ;
    0 0 0];
% sector 1 clamp a positive rail
if (theta>=0)&&(theta<pi/6)
    t1=sqrt(3)*Vref*cos(theta+pi/6)/(Vdc*f);
    t2=sqrt(3)*Vref*sin(theta)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[1 0 0 ;
        1 1 0;
        1 1 1];
end
if (theta>=pi/6)&&(theta<pi/3)
    t2=sqrt(3)*Vref*cos(theta+pi/6)/(Vdc*f);
    t1=sqrt(3)*Vref*sin(theta)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[1 1 0 ;
        1 0 0;
        0 0 0];
end
% sector 2
if (theta>=pi/3)&&(theta<pi/2)
    t1=sqrt(3)*Vref*cos(theta-pi/3+pi/6)/(Vdc*f);
    t2=sqrt(3)*Vref*sin(theta-pi/3)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[1 1 0;
    0 1 0;
    0 0 0];
end
if (theta>=pi/2)&&(theta<2*pi/3)
    t2=sqrt(3)*Vref*cos(theta-pi/3+pi/6)/(Vdc*f);
    t1=sqrt(3)*Vref*sin(theta-pi/3)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[0 1 0;
    1 1 0;
    1 1 1];
end
% sector 3
if (theta>=2*pi/3)&&(theta<5*pi/6)
    t1=sqrt(3)*Vref*cos(theta-2*pi/3+pi/6)/(Vdc*f);
    t2=sqrt(3)*Vref*sin(theta-2*pi/3)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[0 1 0;
        0 1 1;
        1 1 1];
end
if (theta>=5*pi/6)&&(theta<pi)
    t2=sqrt(3)*Vref*cos(theta-2*pi/3+pi/6)/(Vdc*f);
    t1=sqrt(3)*Vref*sin(theta-2*pi/3)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[0 1 1;
        0 1 0;
        0 0 0];
end
% sector 4
if (theta>=pi)&&(theta<7*pi/6)
    t1=sqrt(3)*Vref*cos(theta-pi+pi/6)/(Vdc*f);
    t2=sqrt(3)*Vref*sin(theta-pi)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[0 1 1;
        0 0 1;
        0 0 0];
end
if (theta>=7*pi/6)&&(theta<4*pi/3)
    t2=sqrt(3)*Vref*cos(theta-pi+pi/6)/(Vdc*f);
    t1=sqrt(3)*Vref*sin(theta-pi)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[0 0 1;
        0 1 1;
        1 1 1];
end
% sector 5
if (theta>=4*pi/3)&&(theta<3*pi/2)
    t1=sqrt(3)*Vref*cos(theta-4*pi/3+pi/6)/(Vdc*f);
    t2=sqrt(3)*Vref*sin(theta-4*pi/3)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[0 0 1;
        1 0 1;
       1 1 1];
end
if (theta>=3*pi/2)&&(theta<5*pi/3)
    t2=sqrt(3)*Vref*cos(theta-4*pi/3+pi/6)/(Vdc*f);
    t1=sqrt(3)*Vref*sin(theta-4*pi/3)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[1 0 1;
        0 0 1;
        0 0 0];
end
% sector 6
if (theta>=5*pi/3)&&(theta<11*pi/6)
    t1=sqrt(3)*Vref*cos(theta-5*pi/3+pi/6)/(Vdc*f);
    t2=sqrt(3)*Vref*sin(theta-5*pi/3)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[1 0 1;
        1 0 0;
        0 0 0];
end
if (theta>=11*pi/6)&&(theta<2*pi)
    t2=sqrt(3)*Vref*cos(theta-5*pi/3+pi/6)/(Vdc*f);
    t1=sqrt(3)*Vref*sin(theta-5*pi/3)/(Vdc*f);
    t3=1/f-t1-t2;
    T=[t1 t2 t3];
    S=[1 0 0;
        1 0 1;
        1 1 1];
end
end