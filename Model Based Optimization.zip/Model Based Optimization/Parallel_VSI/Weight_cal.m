function Weight=Weight_cal(Device_sw,Device_num,Topology,Combination)
switch Topology
    case 1
        switch Combination
            case 1
                Weight=3*(Device_sw(1).Weight_sw*Device_num(1))/676;
            case 2
                Weight=3*(Device_sw(1).Weight_sw*Device_num(1))/675;
            case 3
                Weight=3*2*(Device_sw(1).Weight_sw*Device_num(1)+Device_sw(2).Weight_sw*Device_num(2))/700;
        end
    case 2
        switch Combination
            case 1
                Weight=3*2*(Device_sw(1).Weight_sw*Device_num(1)+Device_sw(3).Weight_sw*Device_num(3))/676;
            case 2
                Weight=3*2*(Device_sw(1).Weight_sw*Device_num(1)+Device_sw(3).Weight_sw*Device_num(3))/570;
            case 3
                Weight=3*2*(2*Device_sw(1).Weight_sw*Device_num(1)+Device_sw(3).Weight_sw*Device_num(3))/700;
        end
    case 3
        switch Combination
            case 1
                Weight=3*(Device_sw(1).Weight_sw*Device_num(1)+2*Device_sw(3).Weight_sw*Device_num(3))/676;
            case 2
                Weight=3*(Device_sw(1).Weight_sw*Device_num(1)+2*(Device_sw(3).Weight_sw*Device_num(3)+Device_sw(4).Weight_sw*Device_num(4)))/675;
            case 3
                Weight=3*2*(Device_sw(1).Weight_sw*Device_num(1)+Device_sw(2).Weight_sw*Device_num(2)+Device_sw(3).Weight_sw*Device_num(3))/700;
        end
    case 4
        switch Combination
            case 1
                Weight=3*(Device_sw(1).Weight_sw*Device_num(1)+Device_sw(2).Weight_sw*Device_num(2))/676;
        end
    case 5
        switch Combination
            case 1
                Weight=3*2*(Device_sw(1).Weight_sw*Device_num(1)+Device_sw(2).Weight_sw*Device_num(2)...
                    +2*Device_sw(3).Weight_sw*Device_num(3)+Device_sw(4).Weight_sw*Device_num(4))/676;
        end
    case 6
        switch Combination
            case 1
                Weight=3*(Device_sw(1).Weight_sw*Device_num(1)+Device_sw(2).Weight_sw*Device_num(2)+2*Device_sw(3).Weight_sw*Device_num(3)...
                    +2*(Device_sw(4).Weight_sw*Device_num(4)+Device_sw(5).Weight_sw*Device_num(5)+Device_sw(5).Weight_sw*Device_num(5)))/676;
        end
end


end