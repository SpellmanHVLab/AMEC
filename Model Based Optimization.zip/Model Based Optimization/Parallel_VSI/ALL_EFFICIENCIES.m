clc
clear all
close all

Efficiency_cal_main
save('2L_Results','Efficiency','P_sw','P_cond','T_junction');

Efficiency_cal_main
save('3LNPC_Results','Efficiency','P_sw','P_cond','T_junction');

Efficiency_cal_main
save('3LANPC_Results','Efficiency','P_sw','P_cond','T_junction');

Efficiency_cal_main
save('3LTNPC_Results','Efficiency','P_sw','P_cond','T_junction');
%}

x=load('2L_Results.mat');
y=load('3LNPC_Results.mat');
yy=load('3LANPC_Results.mat');
z=load('3LTNPC_Results.mat');


subplot(2,1,1)
plot(x.P_sw,'Linewidth',4);hold on;
plot(y.P_sw,'Linewidth',4);hold on;
plot(yy.P_sw,'Linewidth',4);hold on;
plot(z.P_sw,'Linewidth',4);hold on;
set(gca,'FontSize',8,'FontName','Times New Roman');
legend('2LC','3L-NPC','3L-ANPC','3L-TNPC');
set(gca,'FontSize',8,'FontName','Times New Roman');
grid on;
xlabel('Frequency (kHz)','Fontsize',16,'FontName','Times New Roman');
set(gca,'XMinorGrid','on');set(gca,'YMinorGrid','on');
title('Switching Losses of 1.5 kVA Inverter','fontsize',14,'FontName','Times New Roman');
ylabel('Losses (W)','fontsize',16,'FontName','Times New Roman');
%set(gca,'FontSize',16,'FontName','Times New Roman');
set(gca,'XTick',[1:2:23]);
set(gca,'xtickLabel',{'5','15','25','35','45','55','65','75','85','95','105','115'});

subplot(2,1,2)
plot(x.P_cond,'Linewidth',4);hold on;
plot(y.P_cond,'Linewidth',4);hold on;
plot(yy.P_cond,'Linewidth',4);hold on;
plot(z.P_cond,'Linewidth',4);hold on;
set(gca,'FontSize',8,'FontName','Times New Roman');
legend('2LC','3L-NPC','3L-ANPC','3L-TNPC');
set(gca,'FontSize',8,'FontName','Times New Roman');
grid on;
xlabel('Frequency (kHz)','Fontsize',16,'FontName','Times New Roman');
set(gca,'XMinorGrid','on');set(gca,'YMinorGrid','on');
title('Conduction Losses of 450 kVA Inverter @ pf=.95','fontsize',14,'FontName','Times New Roman');
ylabel('Losses (W)','fontsize',16,'FontName','Times New Roman');
%set(gca,'FontSize',16,'FontName','Times New Roman');
set(gca,'XTick',[1:2:23]);
set(gca,'xtickLabel',{'5','15','25','35','45','55','65','75','85','95','105','115'});


figure(2)
plot(x.Efficiency,'Linewidth',4);hold on;
plot(y.Efficiency,'Linewidth',4);hold on;
plot(yy.Efficiency,'Linewidth',4);hold on;
plot(z.Efficiency,'Linewidth',4);hold on;
set(gca,'FontSize',8,'FontName','Times New Roman');
legend('2LC','3L-NPC','3L-ANPC','3L-TNPC');
set(gca,'FontSize',8,'FontName','Times New Roman');
grid on;
xlabel('Frequency(kHz)','Fontsize',18,'FontName','Times New Roman');
set(gca,'XMinorGrid','on');set(gca,'YMinorGrid','on');
title('Efficiency Analysis of 450 kVA Inverter @ pf=.95','fontsize',18,'FontName','Times New Roman');
ylabel('Efficiency %','fontsize',18,'FontName','Times New Roman');
set(gca,'FontSize',16,'FontName','Times New Roman');
set(gca,'XTick',[1:2:23]);
set(gca,'xtickLabel',{'5','15','25','35','45','55','65','75','85','95','105','115'});

%}