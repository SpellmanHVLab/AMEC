function [Loss, Cond_Loss, Switch_Loss] =PowerLossFun_ANPC(System_para,Device_sw,Device_num,Rg)
%% This is the loss calculation function, several assumptions have been made:
% Assume that the chip temperatures for same parallel switches are the same
% Assume that the parralleled chips have equal current sharing

%% initial system parameters
f1=System_para(1);
fs=System_para(2);
Vdc=System_para(3);
Vref=System_para(4);
P=System_para(5);
pf=System_para(6);
T_device=System_para(10);
%% Calculate system parameters
i=[0 0 0];  % three phase currents
%Vc=Vdc/2;   % commutation voltage of devices
if (pf>0)angle=acos(pf);
else angle=-acos(-pf);
end
Carrier=fs/f1;    % carrier ratio
N=floor(Carrier);
%% Device Initial
% Phase Leg:        LegMosfet  LegIGBT    LegDiode,
% Pahse Leg No.:    Ns1_MOS    Ns1_IGBT   Nd1_DIODE
%                   Ns2_MOS    Ns2_IGBT   Nd2_DIODE
%% Load Calculation p.f.
Power=P;            % active power
AP=Power/pf;        % apparent power
I=(2/3)*AP/Vref;    % magnitude of phase current
%% Initial Power Matrix
Pcond=[0 0; 0 0;0 0;0 0;0 0];
Pconduction=[0 0; 0 0;0 0;0 0;0 0];
Pswitch=[0 0; 0 0;0 0;0 0;0 0];

%% Intial Tempurature of Device 
Ts=[T_device,T_device,T_device,T_device,T_device,T_device];
Td=[T_device,T_device,T_device,T_device,T_device,T_device];
Device_temp=[Ts,Td]; %[s1 s2 s3 s4 s5 s6 d1 d2 d3 d4 d5 d6]
%% calculate the power loss in one switching cycle
for m=0:1:N
    %% three phase current calculation
    theta=m*2*pi/N;
    i(1)=I*cos(theta-angle);
    i(2)=I*cos(theta-angle-2*pi/3);
    i(3)=I*cos(theta-angle+2*pi/3);
    %% calcuation Switching function and time
      [S, T]=DPWM_3L(Vref,theta,Vdc,fs);
    %% Conduction Loss Power Calculation
 

        Pconduction=Pconduction_function_NPC(S,T,i,Device_temp,Device_sw,Device_num,System_para);

    %Now we calculate the total conduction loss for groups of paralled switch
     %% S1 and D1
    Pc_mos_s1(m+1)=Pconduction(1,1);
    Pc_sic_d1(m+1)=Pconduction(1,2);
     %% S2 and D2
    Pc_mos_s2(m+1)=Pconduction(2,1);
    Pc_sic_d2(m+1)=Pconduction(2,2);
     %% S3 and D3
    Pc_mos_s3(m+1)=Pconduction(3,1);
    Pc_sic_d3(m+1)=Pconduction(3,2);
     %% S4 and D4
    Pc_mos_s4(m+1)=Pconduction(4,1);
    Pc_sic_d4(m+1)=Pconduction(4,2);
    %% S5 and D5
    Pc_mos_s5(m+1)=Pconduction(5,1);
    Pc_sic_d5(m+1)=Pconduction(5,2);
     %% S6 and D6
    Pc_mos_s6(m+1)=Pconduction(6,1);
    Pc_sic_d6(m+1)=Pconduction(6,2);
        
    %% swtiching loss power Calculation
    Pswitching=Pswitching_function_NPC(S,i,System_para,Device_temp,Device_sw,Device_num,Rg);
     %% S1 and D1
    Psw_mos_s1(m+1)=Pswitching(1,1);
    Psw_sic_d1(m+1)=Pswitching(1,2);
     %% S2 and D2
    Psw_mos_s2(m+1)=Pswitching(2,1);
    Psw_sic_d2(m+1)=Pswitching(2,2);    
     %% S3 and D3
    Psw_mos_s3(m+1)=Pswitching(3,1);
    Psw_sic_d3(m+1)=Pswitching(3,2);
     %% S4 and D4
    Psw_mos_s4(m+1)=Pswitching(4,1);
    Psw_sic_d4(m+1)=Pswitching(4,2);
     %% S5 and D5
    Psw_mos_s5(m+1)=Pswitching(5,1);
    Psw_sic_d5(m+1)=Pswitching(5,2);
    %% S4 and D4
    Psw_mos_s6(m+1)=Pswitching(6,1);
    Psw_sic_d6(m+1)=Pswitching(6,2);
     
    %% total power loss
     %% S1 and D1    
    Psum_mos_s1(m+1)=Psw_mos_s1(m+1)+Pc_mos_s1(m+1);
    Psum_sic_d1(m+1)=Psw_sic_d1(m+1)+Pc_sic_d1(m+1);
     %% S2 and D2   
    Psum_mos_s2(m+1)=Psw_mos_s2(m+1)+Pc_mos_s2(m+1);
    Psum_sic_d2(m+1)=Psw_sic_d2(m+1)+Pc_sic_d2(m+1);
     %% S3 and D3
    Psum_mos_s3(m+1)=Psw_mos_s3(m+1)+Pc_mos_s3(m+1);
    Psum_sic_d3(m+1)=Psw_sic_d3(m+1)+Pc_sic_d3(m+1);
     %% S4 and D4
    Psum_mos_s4(m+1)=Psw_mos_s4(m+1)+Pc_mos_s4(m+1);
    Psum_sic_d4(m+1)=Psw_sic_d4(m+1)+Pc_sic_d4(m+1);
     %% S5 and D5
    Psum_mos_s5(m+1)=Psw_mos_s5(m+1)+Pc_mos_s5(m+1);
    Psum_sic_d5(m+1)=Psw_sic_d5(m+1)+Pc_sic_d5(m+1);
     %% S6 and D6
    Psum_mos_s6(m+1)=Psw_mos_s6(m+1)+Pc_mos_s6(m+1);
    Psum_sic_d6(m+1)=Psw_sic_d6(m+1)+Pc_sic_d6(m+1);
    %% Reset temp parameters
    Pcond=[0 0; 0 0; 0 0; 0 0;0 0;0 0];
    Pconduction=[0 0;0 0;0 0;0 0;0 0;0 0];
end

%% Conculsion of Power Loss
TotalConductionPowerLoss=1./fs.*f1*[sum(Pc_mos_s1) sum(Pc_sic_d1) sum(Pc_mos_s2) sum(Pc_sic_d2) sum(Pc_mos_s3) sum(Pc_sic_d3) sum(Pc_mos_s4) sum(Pc_sic_d4) sum(Pc_mos_s5) sum(Pc_sic_d5) sum(Pc_mos_s6) sum(Pc_sic_d6)];
TotalSwitchingPowerLoss=1*f1*[sum(Psw_mos_s1) sum(Psw_sic_d1) sum(Psw_mos_s2) sum(Psw_sic_d2) sum(Psw_mos_s3) sum(Psw_sic_d3) sum(Psw_mos_s4) sum(Psw_sic_d4) sum(Psw_mos_s5) sum(Psw_sic_d5) sum(Psw_mos_s6) sum(Psw_sic_d6)];
TotalPowerLoss=TotalSwitchingPowerLoss+TotalConductionPowerLoss;

Loss=sum(TotalPowerLoss);
Cond_Loss=(TotalConductionPowerLoss);
Switch_Loss=(TotalSwitchingPowerLoss);
end




function Pconduction=Pconduction_function_NPC(S,T,i,Device_temp,Device_sw,Device_num,System_para)
%% This function calculate the conduction loss of single discrete switch/diode the switch notations follow the convetional notation
fs=System_para(2);
Pconduction=[0,0;     % Conduction loss matrix [s1 d1; s2 d2; s3 d3; s4 d4]
             0,0;
             0,0;
             0,0;
             0,0;
             0,0];
N_leg_mos=Device_num(1);
N_leg_sicD=Device_num(2);
N_clp_mos=Device_num(3);
N_clamp_sicD=Device_num(4);
for t=1:1:3
        Sa=S(t,1);
        %accodrding to different conditions, we can calculate the current
        %loop and conduction loss based on current in each phase and
        %switching function.
        Pcond=T(t).*fs.*CondPowerLoss_NPC(i,Sa,Device_temp,Device_sw,Device_num);
        Pconduction=Pcond+Pconduction;
end

    %% S1 and D1
    Pconduction(1,1)=Pconduction(1,1)*N_leg_mos;
    Pconduction(1,2)=Pconduction(1,2)*N_leg_sicD;
    %% S2 and D2
    Pconduction(2,1)=Pconduction(2,1)*N_clp_mos;
    Pconduction(2,2)=Pconduction(2,2)*N_clamp_sicD;
    %% S3 and D3
    Pconduction(3,1)=Pconduction(3,1)*N_clp_mos;
    Pconduction(3,2)=Pconduction(3,2)*N_clamp_sicD;
    %% S4 and D4
    Pconduction(4,1)=Pconduction(4,1)*N_leg_mos;
    Pconduction(4,2)=Pconduction(4,2)*N_leg_sicD;    
    %% D5 and D6
    Pconduction(5,1)=Pconduction(5,1)*N_clamp_sicD;
    Pconduction(5,2)=Pconduction(5,2)*N_clamp_sicD;    
end



function  Pcond=CondPowerLoss_NPC(i,Sa,Device_temp,Device_sw,Device_num)
%% i calacution
ia=i(1);

%% Current Sharing and Forward Voltage
[Vs_mos_leg,is_mos_leg]=V_eq_s_NPC(ia,Device_temp(1),Device_sw(1),Device_num(1));
[Vd_Diode_leg,id_sicD_leg]=V_eq_d_NPC(ia,Device_temp(7),Device_sw(2),Device_num(2));

[Vs_clamp,is_clamp]=V_eq_s_NPC(ia,Device_temp(2),Device_sw(1),Device_num(1));               %%% Switch S2
[Vs_clamp_d,is_clamp_d]=V_eq_d_NPC(ia,Device_temp(8),Device_sw(2),Device_num(2));           %%% Diode  D2 

[Vs_mos_clamp,is_mos_clamp]=V_eq_s_NPC(ia,Device_temp(5),Device_sw(3),Device_num(3));       %%% Switch S5
[Vd_diode_clamp,id_sicD_clamp]=V_eq_d_NPC(ia,Device_temp(11),Device_sw(4),Device_num(4));   %%% Switch D5
%% Conduction Loss

Pcond_s1=Device_num(5)*(Vs_mos_leg*is_mos_leg)*((ia>=0)&(Sa==1));
Pcond_s2=Device_num(5)*((Vs_clamp*is_clamp)*((ia>=0)&(Sa==1))+(Vs_clamp*is_clamp/2)*((ia>=0)&(Sa==0)));
Pcond_s3=Device_num(5)*((Vs_clamp*is_clamp/2)*((ia<0)&(Sa==0))+(Vs_clamp*is_clamp)*((ia<0)&(Sa==-1)));
Pcond_s4=Device_num(5)*(Vs_mos_leg*is_mos_leg)*((ia<0)&(Sa==-1));
Pcond_s5=Device_num(6)*(Vs_mos_clamp*is_mos_clamp/2)*((ia<0)&(Sa==0));
Pcond_s6=Device_num(6)*(Vs_mos_clamp*is_mos_clamp/2)*((ia>=0)&(Sa==0));

Pcond_d1=Device_num(5)*(Vd_Diode_leg*id_sicD_leg)*((ia<0)&(Sa==1));
Pcond_d2=Device_num(5)*((Vs_clamp_d*is_clamp_d)*((ia<0)&(Sa==1))+(Vs_clamp_d*is_clamp_d/2)*((ia<0)&(Sa==0)));
Pcond_d3=Device_num(5)*((Vs_clamp_d*is_clamp_d)*((ia>=0)&(Sa==-1))+(Vs_clamp_d*is_clamp_d/2)*((ia>=0)&(Sa==0)));
Pcond_d4=Device_num(5)*(Vd_Diode_leg*id_sicD_leg)*((ia>=0)&(Sa==-1));
Pcond_d5=Device_num(6)*(Vd_diode_clamp*id_sicD_clamp/2)*((ia>=0)&(Sa==0));
Pcond_d6=Device_num(6)*(Vd_diode_clamp*id_sicD_clamp/2)*((ia<0)&(Sa==0));

Pcond=[Pcond_s1  Pcond_d1;Pcond_s2  Pcond_d2;Pcond_s3  Pcond_d3;Pcond_s4  Pcond_d4; Pcond_s5  Pcond_d5;Pcond_s6  Pcond_d6;];
end

function [Vs_mos,is_mos]=V_eq_s_NPC(i,Device_temp,Device_sw,Device_num)
%% This fuction calculate the forward voltage of one single switch
% Funtion input is the conduction current and device parameters/temperature
Device_mos=Device_sw;
%%
ts_mos=Device_temp;
%%
N_mos=Device_num;
%% Mosfet tempreture dependent parameters
k1_mos=Device_mos.ks1;
k2_mos=Device_mos.ks2;
a1_mos=Device_mos.as1;
a2_mos=Device_mos.as2;
t1_mos=Device_mos.ts1;
t2_mos=Device_mos.ts2;
%%
i_total=abs(i);
is_mos=i_total/N_mos;
K_MOS=((ts_mos-t1_mos)/(t2_mos-t1_mos)*(k2_mos-k1_mos)+k1_mos);
A_MOS=(ts_mos-t1_mos)/(t2_mos-t1_mos)*(a2_mos-a1_mos)+a1_mos;
%%
Vs_mos=K_MOS*is_mos+A_MOS;

end


function [Vd_Diode,id_sicD]=V_eq_d_NPC(i,Device_temp,Device_sw,Device_num)
%% This fuction calculate the forward voltage of one single diode
% Funtion input is the conduction current and device parameters/temperature
Device_sicD=Device_sw;
%%
ts_sicD=Device_temp;
%%
N_sicD=Device_num;
%% Mosfet tempreture dependent parameters
k1_sicD=Device_sicD.kd1;
k2_sicD=Device_sicD.kd2;
a1_sicD=Device_sicD.ad1;
a2_sicD=Device_sicD.ad2;
t1_sicD=Device_sicD.td1;
t2_sicD=Device_sicD.td2;
%%
i_total=abs(i);
id_sicD=i_total/N_sicD;
K_SICD=((ts_sicD-t1_sicD)/(t2_sicD-t1_sicD)*(k2_sicD-k1_sicD)+k1_sicD);
A_SICD=(ts_sicD-t1_sicD)/(t2_sicD-t1_sicD)*(a2_sicD-a1_sicD)+a1_sicD;
%%
Vd_Diode=K_SICD*id_sicD+A_SICD;
end


function Pswitching=Pswitching_function_NPC(S,i,System_para,Device_temp,Device_sw,Device_num,Rg)
Vc=System_para(3)/2;
fs=System_para(2);
ia=i(1);
Pswitching=(Esw_NPC(S(1,1),S(2,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg)...
    +Esw_NPC(S(2,1),S(3,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg)...
    +Esw_NPC(S(3,1),S(2,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg)...
    +Esw_NPC(S(2,1),S(1,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg));
end



function  Esw=Esw_NPC(S1,S2,ia,Vc,Device_temp,Device_sw,Device_num,Rg)
%% Device
Leg_Mosfet          = Device_sw(1);
Leg_Diode           = Device_sw(2);
Clamp_Mosfet        = Device_sw(3);
Clamp_Diode         = Device_sw(4);
%% Initial loss of leg device(s1 s2 s4 s4 d1 d2 d3 d4)
%% Phase Leg Mosfet Parameters
%Vn_mos_leg=Leg_Mosfet.Vns;
%In_mos_leg=Leg_Mosfet.Ins;
%Vn_mos_clp=Clamp_Mosfet.Vns;
%In_mos_clp=Clamp_Mosfet.Ins;

N_mos_leg = Device_num(1);
sicD_leg  = Device_num(2);
N_mos_clamp = Device_num(3);
sicD_clamp = Device_num(4);
I_single_Mos_Leg=ia/N_mos_leg;
I_single_sicD_Leg=ia/sicD_leg;
I_single_Mos_clamp=ia/N_mos_clamp;
I_single_sicD_clamp=ia/sicD_clamp;
ix=abs(I_single_Mos_Leg);
iy=abs(I_single_Mos_clamp);


a11_on_mos_leg=Leg_Mosfet.a11_on;
a12_on_mos_leg=Leg_Mosfet.a12_on;
a13_on_mos_leg=Leg_Mosfet.a13_on;
a14_on_mos_leg=Leg_Mosfet.a14_on;
a11_off_mos_leg=Leg_Mosfet.a11_off;
a12_off_mos_leg=Leg_Mosfet.a12_off;
a13_off_mos_leg=Leg_Mosfet.a13_off;
a14_off_mos_leg=Leg_Mosfet.a14_off;
v1_mos_Leg=Leg_Mosfet.V1;

rg1_on_leg=Leg_Mosfet.rg1_on;
rg2_on_leg=Leg_Mosfet.rg2_on;
rg1_off_leg=Leg_Mosfet.rg1_off;
rg2_off_leg=Leg_Mosfet.rg2_off;
I_ref_leg=Leg_Mosfet.I_ref;

E1_on_mos_leg=(a14_on_mos_leg*ix^3)+(a13_on_mos_leg*ix^2)+(a12_on_mos_leg*ix)+a11_on_mos_leg;
E1_off_mos_leg=(a14_off_mos_leg*ix^3)+(a13_off_mos_leg*ix^2)+(a12_off_mos_leg*ix)+a11_off_mos_leg;

Es_on_mos(1)=Vc*(E1_on_mos_leg/v1_mos_Leg);
Es_on_mos(4)=Vc*(E1_on_mos_leg/v1_mos_Leg);
Es_off_mos(1)=Vc*(E1_off_mos_leg/v1_mos_Leg);
Es_off_mos(4)=Vc*(E1_off_mos_leg/v1_mos_Leg);


E1_on_mos_leg_ref=(a14_on_mos_leg*I_ref_leg^3)+(a13_on_mos_leg*I_ref_leg^2)+(a12_on_mos_leg*I_ref_leg)+a11_on_mos_leg;
E1_off_mos_leg_ref=(a14_off_mos_leg*I_ref_leg^3)+(a13_off_mos_leg*I_ref_leg^2)+(a12_off_mos_leg*I_ref_leg)+a11_off_mos_leg;
E_ON_scaling_leg=(rg2_on_leg*Rg+rg1_on_leg)/E1_on_mos_leg_ref;
E_OFF_scaling_leg=(rg2_off_leg*Rg+rg1_off_leg)/E1_off_mos_leg_ref;

Es_on_mos(1)=Es_on_mos(1)*E_ON_scaling_leg;
Es_on_mos(4)=Es_on_mos(4)*E_ON_scaling_leg;
Es_off_mos(1)=Es_off_mos(1)*E_OFF_scaling_leg;
Es_off_mos(4)=Es_off_mos(4)*E_OFF_scaling_leg;

Es_on_mos(2)=Es_on_mos(1);
Es_on_mos(3)=Es_on_mos(4);
Es_off_mos(2)=Es_off_mos(1);
Es_off_mos(3)=Es_off_mos(4);

Es_on_mos(5)=Es_on_mos(2);
Es_on_mos(6)=Es_on_mos(3);
Es_off_mos(5)=Es_off_mos(2);
Es_off_mos(6)=Es_off_mos(3);

%% Phase Leg Sic Diode Parameters
Vnd_sicD_leg=Leg_Diode.Vnd;
Ind_sicD_leg=Leg_Diode.Ind;
td1_sicD_leg=Leg_Diode.td1;
td2_sicD_leg=Leg_Diode.td2;
Qrr_d_sicD_leg=Leg_Diode.Qrr1;

Vnd_sicD_clp=Clamp_Diode.Vnd;
Ind_sicD_clp=Clamp_Diode.Ind;
td1_sicD_clp=Clamp_Diode.td1;
td2_sicD_clp=Clamp_Diode.td2;
Qrr_d_sicD_clp=Clamp_Diode.Qrr1;
%% Phase Leg Diode Loss Calculation
Ed_on_sicD(1)=0;
Ed_on_sicD(2)=0;
Ed_on_sicD(3)=0;
Ed_on_sicD(4)=0;
%Ed_off_sicD(1)=((Td_sic(1)-td1_sicD_leg)/(td2_sicD_leg-td1_sicD_leg)*Qrr_d_sicD_leg*Vnd_sicD_leg);
%Ed_off_sicD(2)=((Td_sic(2)-td1_sicD_leg)/(td2_sicD_leg-td1_sicD_leg)*Qrr_d_sicD_leg*Vnd_sicD_leg);
%Ed_off_sicD(3)=((Td_sic(3)-td1_sicD_leg)/(td2_sicD_leg-td1_sicD_leg)*Qrr_d_sicD_leg*Vnd_sicD_leg);
%Ed_off_sicD(4)=((Td_sic(4)-td1_sicD_leg)/(td2_sicD_leg-td1_sicD_leg)*Qrr_d_sicD_leg*Vnd_sicD_leg);
Ed_off_sicD(1)=Qrr_d_sicD_leg*Vc;
Ed_off_sicD(2)=Qrr_d_sicD_clp*Vc;
Ed_off_sicD(3)=Qrr_d_sicD_clp*Vc;
Ed_off_sicD(4)=Qrr_d_sicD_leg*Vc;


%% Clamping device calculation
%% Initial loss of clamping device(D5 D6)
%% Clamping Leg SiC Diode Parameters
Vnd_sicD_clamp=Clamp_Diode.Vnd;
Ind_sicD_clamp=Clamp_Diode.Ind;
td1_sicD_clamp=Clamp_Diode.td1;
td2_sicD_clamp=Clamp_Diode.td2;
Qrr_d_sicD_clamp=Clamp_Diode.Qrr1;
%% Clamping Leg Diode Loss Calculation
Ed_on_sicD(5)=0;
Ed_on_sicD(6)=0;
Ed_off_sicD(5)=Qrr_d_sicD_clamp*Vc;
Ed_off_sicD(6)=Qrr_d_sicD_clamp*Vc;
%% Loss Calculation
%% IGBT loss
Es1_mos=Es_off_mos(1)*((S1==1)&(S2==-1)&(ia>=0))...
       +Es_on_mos(1)*((S1==-1)&(S2==1)&(ia>=0))...
       +Es_off_mos(1)*((S1==1)&(S2==0)&(ia>=0))...
       +Es_on_mos(1)*((S1==0)&(S2==1)&(ia>=0));
Es2_mos=Es_off_mos(2)*((S1==1)&(S2==-1)&(ia>=0))...
       +Es_on_mos(2)*((S1==-1)&(S2==1)&(ia>=0))...
       +Es_off_mos(2)*0.5*((S1==0)&(S2==-1)&(ia>=0))...
       +Es_on_mos(2)*0.5*((S1==-1)&(S2==0)&(ia>=0));
Es3_mos=Es_off_mos(3)*((S1==-1)&(S2==1)&(ia<0))...
       +Es_on_mos(3)*((S1==1)&(S2==-1)&(ia<0))...
       +Es_off_mos(3)*0.5*((S1==0)&(S2==1)&(ia<0))...
       +Es_on_mos(3)*0.5*((S1==1)&(S2==0)&(ia<0));
Es4_mos=Es_off_mos(4)*((S1==-1)&(S2==1)&(ia<0))...
       +Es_on_mos(4)*((S1==1)&(S2==-1)&(ia<0))...
       +Es_off_mos(4)*((S1==-1)&(S2==0)&(ia<0))...
       +Es_on_mos(4)*((S1==0)&(S2==-1)&(ia<0));
Es5_mos=Es_off_mos(5)*0.5*((S1==0)&(S2==1)&(ia<0))...
       +Es_on_mos(5)*0.5*((S1==1)&(S2==0)&(ia<0))...
       +Es_off_mos(5)*0.5*((S1==0)&(S2==-1)&(ia<0))...
       +Es_on_mos(5)*0.5*((S1==-1)&(S2==0)&(ia<0));
Es6_mos=Es_on_mos(6)*0.5*((S1==-1)&(S2==0)&(ia>=0))...
       +Es_off_mos(6)*0.5*((S1==0)&(S2==-1)&(ia>=0))...
       +Es_off_mos(6)*0.5*((S1==0)&(S2==1)&(ia>=0))...
       +Es_on_mos(6)*0.5*((S1==1)&(S2==0)&(ia>=0));
%% diode loss
% Ed1_sicD=-Ed_off_sicD(1)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==1)&(S2==-1)&(ia<0))...
%     -Ed_off_sicD(1)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==1)&(S2==0)&(ia<0))...
%     -Ed_on_sicD(1)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==-1)&(S2==1)&(ia<0))...
%     -Ed_on_sicD(1)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==0)&(S2==1)&(ia<0));
% Ed2_sicD=-Ed_off_sicD(2)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==1)&(S2==-1)&(ia<0))...
%     -Ed_on_sicD(2)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==-1)&(S2==1)&(ia<0));
% Ed3_sicD=Ed_on_sicD(3)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==1)&(S2==-1)&(ia>=0))...
%     +Ed_off_sicD(3)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==-1)&(S2==1)&(ia>=0));
% Ed4_sicD=Ed_on_sicD(4)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==1)&(S2==-1)&(ia>=0))...
%     +Ed_off_sicD(4)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==-1)&(S2==1)&(ia>=0))...
%     +Ed_off_sicD(4)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==-1)&(S2==0)&(ia>=0))...
%    +Ed_on_sicD(4)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==0)&(S2==-1)&(ia>=0));
Ed1_sicD=-Ed_off_sicD(1)*ia/(Ind_sicD_leg)*((S1==1)&(S2==-1)&(ia<0))...
         -Ed_off_sicD(1)*ia/(Ind_sicD_leg)*((S1==1)&(S2==0)&(ia<0))...
         -Ed_on_sicD(1)*ia/(Ind_sicD_leg)*((S1==-1)&(S2==1)&(ia<0))...
         -Ed_on_sicD(1)*ia/(Ind_sicD_leg)*((S1==0)&(S2==1)&(ia<0));
Ed2_sicD=-Ed_off_sicD(2)*ia/(Ind_sicD_leg)*((S1==1)&(S2==-1)&(ia<0))...
         -Ed_on_sicD(2)*ia/(Ind_sicD_leg)*((S1==-1)&(S2==1)&(ia<0));
Ed3_sicD= Ed_on_sicD(3)*ia/(Ind_sicD_leg)*((S1==1)&(S2==-1)&(ia>=0))...
          +Ed_off_sicD(3)*ia/(Ind_sicD_leg)*((S1==-1)&(S2==1)&(ia>=0));
Ed4_sicD= Ed_on_sicD(4)*ia/(Ind_sicD_leg)*((S1==1)&(S2==-1)&(ia>=0))...
          +Ed_off_sicD(4)*ia/(Ind_sicD_leg)*((S1==-1)&(S2==1)&(ia>=0))...
          +Ed_off_sicD(4)*ia/(Ind_sicD_leg)*((S1==-1)&(S2==0)&(ia>=0))...
          +Ed_on_sicD(4)*ia/(Ind_sicD_leg)*((S1==0)&(S2==-1)&(ia>=0));
Ed5_sicD= Ed_on_sicD(5)*ia*0.5/(Ind_sicD_clamp)*((S1==1)&(S2==0)&(ia>=0))...
          +Ed_off_sicD(5)*ia*0.5/(Ind_sicD_clamp)*((S1==0)&(S2==1)&(ia>=0))...
          +Ed_on_sicD(5)*ia*0.5/(Ind_sicD_clamp)*((S1==-1)&(S2==0)&(ia>=0))...
          +Ed_off_sicD(5)*ia*0.5/(Ind_sicD_clamp)*((S1==0)&(S2==-1)&(ia>=0));
Ed6_sicD= -Ed_on_sicD(6)*ia*0.5/(Ind_sicD_clamp)*((S1==-1)&(S2==0)&(ia<0))...
          -Ed_off_sicD(6)*ia*0.5/(Ind_sicD_clamp)*((S1==0)&(S2==-1)&(ia<0))...
          -Ed_on_sicD(6)*ia*0.5/(Ind_sicD_clamp)*((S1==1)&(S2==0)&(ia<0))...
          -Ed_off_sicD(6)*ia*0.5/(Ind_sicD_clamp)*((S1==0)&(S2==1)&(ia<0));

%%
Esw =[Es1_mos*N_mos_leg,      Ed1_sicD;
      Es2_mos*N_mos_leg,      Ed2_sicD;
      Es3_mos*N_mos_leg,      Ed3_sicD;
      Es4_mos*N_mos_leg,      Ed4_sicD;
      Es5_mos*N_mos_clamp,    Ed5_sicD;
      Es6_mos*sicD_clamp,     Ed6_sicD;];
end