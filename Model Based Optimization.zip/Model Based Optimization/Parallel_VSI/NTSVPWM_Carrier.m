% Vref should be vector

function D = NTSVPWM_Carrier(M,theta)
%D=zeros(3,3);
%Ts=1/f;


dap=M*cos(theta-pi/6)*((theta>=0)&&(theta<2*pi/3))+M*cos(theta+pi/6)*((theta>=4*pi/3)&&(theta<=2*pi));
dan=-(M*cos(theta+pi/6)*((theta>=pi/3)&&(theta<pi))+M*cos(theta-pi/6)*((theta>=pi)&&(theta<5*pi/3)));
dao=1-dap-dan;

dbp=M*sin(theta)*((theta>=0)&&(theta<2*pi/3))+M*sin(theta-pi/3)*((theta>=2*pi/3)&&(theta<=4*pi/3));
dbn=M*sin(theta+2*pi/3)*((theta>=0)&&(theta<pi/3))+M*sin(theta-pi)*((theta>=pi)&&(theta<=5*pi/3))+M*sin(theta-4*pi/3)*((theta>=5*pi/3)&&(theta<=2*pi));
dbo=1-dap-dan;

dcp=M*sin(theta-2*pi/3)*((theta>=2*pi/3)&&(theta<4*pi/3))+M*sin(theta-pi)*((theta>=4*pi/3)&&(theta<=2*pi));
dcn=M*sin(theta+pi/3)*((theta>=0)&&(theta<pi/3))+M*sin(theta)*((theta>=pi/3)&&(theta<pi))+M*sin(theta-5*pi/3)*((theta>=5*pi/3)&&(theta<=2*pi));
dco=1-dcp-dcn;

D=[dap dan dao;
    dbp dbn dbo;
    dcp dcn dco];
%D=[dap dan dao];
end