function Device_initial()
%% These codes are for generating device database
%% Devices:
% Diode1:   ONSEMI FFSH2065A-D 650V 20A Schottcky diode
% Diode2:   CREE C5D50065D 650V 50A Schottcky diode        Confirmed by Mustafeez
% Diode3:   CREE CPW3-1700-S025B-WP 1700V 25A Schottcky diode
% Diode4:   IXYS DSEI2x101-06A 600V 200A Schottcky diode

% Mosfet1:  CREE C2M0025120D 1200V 90/60A SiC MOSFET       Confirmed by Mustafeez
% Mosfet2:  Onsemi NTH027N65S3F-D 650V 75 Si MOSFET        Confirmed by Mustafeez
% Mosfet3:  Rohm SCT2120AF 650V 29/20A SiC MOSFET          Confirmed by Mustafeez
% Mosfet4:  CREE CPM2-1200-0025B 1200V 98/71A SiC MOSFET   Confirmed by Mustafeez
% Mosfet5:  CREE CPM2-1700-0045B 1700V 72/48A SiC MOSFET   Confirmed by Mustafeez
 
% Igbt1:    Onsemi Discrete Si MOSFET FCH023N65S3L4 650V 75A
% Igbt2:    Infineon Discrete IGBT IKW40T120 1200V 40A
% Igbt3:    Infineon Discrete IGBT IGW75N60T 600V 75A
% Igbt4:    Infineon Discrete IGBT IGW60T120 1200V 60A
% Igbt5:    Infineon Discrete IGBT IKW40N120T2 1200V 40A

%% Devices:
% Module1:  CREE SiC Module Powermodule CAS300M17BM2 1700V 225A 
% Module2:  CREE SiC Module Powermodule CAS300M12BM2  1200V 404/285A
% Module3:  Infineon IGBT Module FF600R17ME4 1700V 600A
% Module4:  Infineon IGBT module FF150R17KE4 1700V 150A
% Module5:  CREE SiC Module Powermodule CAS120M12BM2 1200V 193/138A
% Module6:  Infineon IGBT Module FD1000R33HL3-K 3300V 1000A
% Module7:  CREE SiC Module Powermodule Experiment CAS300M17BM2 1700V 225A

%% Devices:
% Bjt1: GeneSiC GA100JT17-227 1700V 160/100A SiC Junction Transistor       Confirmed by Mustafeez
% Bjt2: GeneSiC GA100SICP12-227 1200V 160/100A SiC Junction Transistor     Partially Confirmed by Mustafeez



%% These parts are for generating diode database
% Naming rules: Brand Product# Volt Current Diodetype

%% ONSEMI FFSH2065A-D 650V 20A Schottcky diode
% Switch parameters
Diode(1).Vns=0;
Diode(1).Ins=0;
Diode(1).ts1=0;
Diode(1).ts2=0;
%  Switch temperature dependent parameters
Diode(1).ks1=0;
Diode(1).ks2=0;
Diode(1).as1=0;
Diode(1).as2=0;
%  Switching energy (J)
Diode(1).E1_on=0;
Diode(1).E2_on=0;
Diode(1).E1_off=0;
Diode(1).E2_off=0;
%  Thermal model
Diode(1).Rjct=0;

% Diode parameters
Diode(1).Vnd=800;
Diode(1).Ind=20;
Diode(1).td1=25;
Diode(1).td2=125;
%  Diode temperature dependent parameters
Diode(1).kd1=(1.4-1.01)/(18-2);
%Diode(1).kd2=(1.61-1.02)/(20-4);
Diode(1).kd2=(1.4-1.01)/(18-2);      %No Temperature Dependency%
Diode(1).ad1=1.01-(1.4-1.01)/(18-2)*2;
%Diode(1).ad2=1.02-(1.61-1.02)/(20-4)*4;
Diode(1).ad2=1.01-(1.4-1.01)/(18-2)*2;
%  Reverse recovery charge
Diode(1).Qrr1=0;
Diode(1).Qrr2=0;
%  Thermal model
Diode(1).Rjcd=0.29;

%  Judge whether it is a module
Diode(1).Module=0;
%  Price(dollar)
Diode(1).Price_sw=45;
%  Weight(g)
Diode(1).Weight_sw=8;
%  Price(dollar)
Diode(1).Price_gd=0;
%  Weight(g)
Diode(1).Weight_gd=0; 


%% CPW5-1200-Z050B Silicon Carbide Schottcky Diode Chip
% Switch parameters
Diode(2).Vns=0;
Diode(2).Ins=0;
Diode(2).ts1=0;
Diode(2).ts2=0;
%  Switch temperature dependent parameters
Diode(2).ks1=0;
Diode(2).ks2=0;
Diode(2).as1=0;
Diode(2).as2=0;
%  Switching energy (J)
Diode(2).E1_on=0;
Diode(2).E2_on=0;
Diode(2).E1_off=0;
Diode(2).E2_off=0;
%  Thermal model
Diode(2).Rjct=0;

%Diode parameters
Diode(2).Vnd=1200;
Diode(2).Ind=50;
Diode(2).td1=25;
Diode(2).td2=175;
%  Diode temperature dependent parameters
Diode(2).kd1=13.64*10^-3;
Diode(2).kd2=13.64*10^-3;
Diode(2).ad1=0.9344;
Diode(2).ad2=0.9344;
%  Reverse recovery charge
Diode(2).Qrr1=246*10^-9;
Diode(2).Qrr2=0;
%  Thermal model
Diode(2).Rjcd=0.5;

%  Judge whether it is a module
Diode(2).Module=0;
%  Price(dollar)
Diode(2).Price_sw=25.8;
%  Weight(g)
Diode(2).Weight_sw=8;
%  Price(dollar)
Diode(2).Price_gd=0;
%  Weight(g)
Diode(2).Weight_gd=0; 
%
Diode(2).a11_on   =0;        %ZEROTH order co-efficienct
Diode(2).a12_on   =0;        %FIRST order co-efficienct
Diode(2).a13_on   =0;        %SECOND order co-efficienct
Diode(2).a14_on   =0;        %THIRD order co-efficienct
Diode(2).a11_off  =0;
Diode(2).a12_off  =0;
Diode(2).a13_off  =0;
Diode(2).a14_off  =0;
Diode(2).V1       =0;

Diode(2).rg1_on   =0;        %%ZEROTH order co-efficienct
Diode(2).rg2_on   =0;

Diode(2).rg1_off  =0;        %%ZEROTH order co-efficienct
Diode(2).rg2_off  =0;
Diode(2).I_ref    =0;        %Reference current for E with Rg curve


%% CREE C3D25170H 1700V 25A Schottcky diode
% Switch parameters
Diode(3).Vns=0;
Diode(3).Ins=0;
Diode(3).ts1=0;
Diode(3).ts2=0;
%  Switch temperature dependent parameters
Diode(3).ks1=0;
Diode(3).ks2=0;
Diode(3).as1=0;
Diode(3).as2=0;
%  Switching energy (J)
Diode(3).E1_on=0;
Diode(3).E2_on=0;
Diode(3).E1_off=0;
Diode(3).E2_off=0;
%  Thermal model
Diode(3).Rjct=0;

%Diode parameters
Diode(3).Vnd=1700;
Diode(3).Ind=25;
Diode(3).td1=25;
Diode(3).td2=175;
%  Diode temperature dependent parameters
Diode(3).kd1=(1.8-.85)/25;
Diode(3).kd2=(3.22-0.7)/25;
Diode(3).ad1=1.8;
Diode(3).ad2=3.2;
%  Reverse recovery charge
Diode(3).Qrr1=170*10^-9;
Diode(3).Qrr2=270*10^-9;
%  Thermal model
Diode(3).Rjcd=0.4;

%  Judge whether it is a module
Diode(3).Module=0;
%  Price(dollar)
Diode(3).Price_sw=25.8;
%  Weight(g)
Diode(3).Weight_sw=8;
%  Price(dollar)
Diode(3).Price_gd=0;
%  Weight(g)
Diode(3).Weight_gd=0; 

%% IXYS DSEI2x101-06A 600V 200A Schottcky diode
% Switch parameters
Diode(4).Vns=0;
Diode(4).Ins=0;
Diode(4).ts1=0;
Diode(4).ts2=0;
%  Switch temperature dependent parameters
Diode(4).ks1=0;
Diode(4).ks2=0;
Diode(4).as1=0;
Diode(4).as2=0;
%  Switching energy (J)
Diode(4).E1_on=0;
Diode(4).E2_on=0;
Diode(4).E1_off=0;
Diode(4).E2_off=0;
%  Thermal model
Diode(4).Rjct=0;

%Diode parameters
Diode(4).Vnd=300;
Diode(4).Ind=100;
Diode(4).td1=25;
Diode(4).td2=150;
%  Diode temperature dependent parameters
Diode(4).kd1=(1.25-0.9)/100;
Diode(4).kd2=(1.2-0.7)/100;
Diode(4).ad1=0.9;
Diode(4).ad2=0.7;
%  Reverse recovery charge
Diode(4).Qrr1=200*10^-9;
Diode(4).Qrr2=200*10^-9;
%  Thermal model
Diode(4).Rjcd=0.4;

%  Judge whether it is a module
Diode(4).Module=0;
%  Price(dollar)
Diode(4).Price_sw=22.12;
%  Weight(g)
Diode(4).Weight_sw=30;
%  Price(dollar)
Diode(4).Price_gd=0;
%  Weight(g)
Diode(4).Weight_gd=0; 

save('Diodedata','Diode');


%% These codes are for generating MOSFET database
% Naming rules: Brand Product# Volt Current MOSFETtype

%% CREE C2M0080120D 1200V 36/36A SiC MOSFET
% Switch parameters 
Mosfet(1).Vns=600;
Mosfet(1).Ins=40;
%Mosfet(1).Ins=40;
Mosfet(1).ts1=25;
Mosfet(1).ts2=125;
% Switch temperature dependent parameters
Mosfet(1).ks1=0.080;
Mosfet(1).ks2=0.112;
Mosfet(1).as1=0;
Mosfet(1).as2=0;
%  Switching energy (J) rg =2.5Ohm
Mosfet(1).E1_on=0.81*10^-3;
Mosfet(1).E2_on=0.78*10^-3;
Mosfet(1).E1_off=0.360*10^-3;
Mosfet(1).E2_off=0.380*10^-3;
%Mosfet(1).E1_on=2.8*10^-3;
%Mosfet(1).E2_on=2.8*10^-3;
%Mosfet(1).E1_off=3.6*10^-3;
%Mosfet(1).E2_off=3.6*10^-3;
%  Thermal model
Mosfet(1).Rjct=0.24;

% Diode parameters
Mosfet(1).Vnd=800;
Mosfet(1).Ind=20;
Mosfet(1).td1=25;
Mosfet(1).td2=125;
%  Diode temperature dependent parameters
Mosfet(1).kd1=0.080;
Mosfet(1).kd2=0.112;
Mosfet(1).ad1=0;
Mosfet(1).ad2=0;
%  Reverse recovery charge
Mosfet(1).Qrr1=192e-9;
Mosfet(1).Qrr2=0;
%  Thermal model
Mosfet(1).Rjcd=0;

%  Judge whether it is a module
Mosfet(1).Module=0;
%  Price(dollar)
Mosfet(1).Price_sw=70;
%  Weight(g)
Mosfet(1).Weight_sw=8;
%  Price(dollar)
Mosfet(1).Price_gd=50;
%  Weight(g)
Mosfet(1).Weight_gd=50; 

%% Onsemi NTH027N65S3F-D 650V 75 Si MOSFET
% Switch parameters 
Mosfet(2).Vns=400;
Mosfet(2).Ins=40;
Mosfet(2).ts1=25;
Mosfet(2).ts2=125;
%  MOSFET temperature dependent parameters
Mosfet(2).ks1=27.4e-3;
Mosfet(2).ks2=49.3e-3;
Mosfet(2).as1=0;
Mosfet(2).as2=0;
%  Switching energy (J)
Mosfet(2).E1_on=0.25*10^-3;
Mosfet(2).E2_on=0.25*10^-3;
Mosfet(2).E1_off=0.8*10^-3;
Mosfet(2).E2_off=0.8*10^-3;
%  Thermal model
Mosfet(2).Rjct=1;

% Diode parameters
Mosfet(2).Vnd=400;
Mosfet(2).Ind=40;
Mosfet(2).td1=25;
Mosfet(2).td2=125;
%  Diode temperature dependent parameters
Mosfet(2).kd1=27.4e-3;
Mosfet(2).kd2=49.3e-3;
Mosfet(2).ad1=0;
Mosfet(2).ad2=0;
%  Reverse recovery charge
Mosfet(2).Qrr1=1.0816e-6;
Mosfet(2).Qrr2=0;
%  Thermal model
Mosfet(2).Rjcd=0;

%  Judge whether it is a module
Mosfet(2).Module=0;
%  Price(dollar)
Mosfet(2).Price_sw=10;
%  Weight(g)
Mosfet(2).Weight_sw=8;
%  Price(dollar)
Mosfet(2).Price_gd=50;
%  Weight(g)
Mosfet(2).Weight_gd=50; 

%% Rohm SCT2120AF 650V 29/20A SiC MOSFET
% Switch parameters
Mosfet(3).Vns=300;
Mosfet(3).Ins=10;
Mosfet(3).ts1=25;
Mosfet(3).ts2=150;
%  MOSFET temperature dependent parameters
Mosfet(3).ks1=120*10^-3;
Mosfet(3).ks2=149*10^-3;
Mosfet(3).as1=0;
Mosfet(3).as2=0;
%  Switching energy (J)
Mosfet(3).E1_on=61*10^-6;
Mosfet(3).E2_on=60*10^-6;
Mosfet(3).E1_off=41*10^-6;
Mosfet(3).E2_off=42*10^-6;
%  Thermal model
Mosfet(3).Rjct=0.7;

% Diode parameters
Mosfet(3).Vnd=0;
Mosfet(3).Ind=0;
Mosfet(3).td1=0;
Mosfet(3).td2=0;
%  Diode temperature dependent parameters
Mosfet(3).kd1=0;
Mosfet(3).kd2=0;
Mosfet(3).ad1=0;
Mosfet(3).ad2=0;
%  Reverse recovery charge
Mosfet(3).Qrr1=0;
Mosfet(3).Qrr2=0;
%  Thermal model
Mosfet(3).Rjcd=0;

%  Judge whether it is a module
Mosfet(3).Module=0;
%  Price(dollar)
Mosfet(3).Price_sw=9.07;
%  Weight(g)
Mosfet(3).Weight_sw=8;
%  Price(dollar)
Mosfet(3).Price_gd=50;
%  Weight(g)
Mosfet(3).Weight_gd=50; 

%% CREE CPM2-1200-0025B 1200V 98/71A SiC MOSFET
% Switch parameters
Mosfet(4).Vns=800;
Mosfet(4).Ins=50;
Mosfet(4).ts1=25;
Mosfet(4).ts2=175;
%  MOSFET temperature dependent parameters
Mosfet(4).ks1=25*10^-3;
%Mosfet(4).ks2=52*10^-3;
Mosfet(4).ks2=25*10^-3;
Mosfet(4).as1=0;
Mosfet(4).as2=0;
%  Switching energy (J)
Mosfet(4).E1_on=  1.4*10^-3;
Mosfet(4).E2_on=  1.3*10^-3;
Mosfet(4).E1_off= 0.3*10^-3;
Mosfet(4).E2_off=0.35*10^-3;
%  Thermal model
Mosfet(4).Rjct=0.7;

% Diode parameters
Mosfet(4).Vnd=800;
Mosfet(4).Ind=50;
Mosfet(4).td1=25;
Mosfet(4).td2=175;
%  Diode temperature dependent parameters
Mosfet(4).kd1=25*10^-3;
%Mosfet(4).kd2=52*10^-3;
Mosfet(4).kd2=25*10^-3;
Mosfet(4).ad1=0;
Mosfet(4).ad2=0;
%  Reverse recovery charge
Mosfet(4).Qrr1=406*10^-9;
Mosfet(4).Qrr2=0;
%  Thermal model
Mosfet(4).Rjcd=0;

%  Judge whether it is a module
Mosfet(4).Module=0;
%  Price(dollar)
Mosfet(4).Price_sw=9.07;
%  Weight(g)
Mosfet(4).Weight_sw=8;
%  Price(dollar)
Mosfet(4).Price_gd=50;
%  Weight(g)
Mosfet(4).Weight_gd=50;


Mosfet(4).a11_on=100e-6;          %ZEROTH order co-efficienct
Mosfet(4).a12_on=-4.25e-6;        %FIRST order co-efficienct
Mosfet(4).a13_on=.9792e-6;        %SECOND order co-efficienct
Mosfet(4).a14_on=-5.417e-9;       %THIRD order co-efficienct
Mosfet(4).a11_off=50e-6;
Mosfet(4).a12_off=.2167e-6;
Mosfet(4).a13_off=.2792e-6;
Mosfet(4).a14_off=-.8333e-12;
Mosfet(4).V1     =800;

Mosfet(4).rg1_on=0.001245;      %%ZEROTH order co-efficienct
Mosfet(4).rg2_on=5.13e-05;

Mosfet(4).rg1_off=0.0001652;    %%ZEROTH order co-efficienct
Mosfet(4).rg2_off=6.61e-05;
Mosfet(4).I_ref=50;             %Reference current for E with Rg curve




%% CREE CPM2-1700-0045B 1700V 72/48A SiC MOSFET
% Switch parameters
Mosfet(5).Vns=1200;
Mosfet(5).Ins=50;
Mosfet(5).ts1=25;
Mosfet(5).ts2=150;
%  MOSFET temperature dependent parameters
Mosfet(5).ks1=45*10^-3;
%Mosfet(5).ks2=90*10^-3;
Mosfet(5).ks2=45*10^-3;
Mosfet(5).as1=0;
Mosfet(5).as2=0;
%  Switching energy (J)
Mosfet(5).E1_on=  4.7*10^-3;
Mosfet(5).E2_on=  4.6*10^-3;
Mosfet(5).E1_off=0.93*10^-3;
Mosfet(5).E2_off= 1.1*10^-3;
%  Thermal model
Mosfet(5).Rjct=0.7;

% Diode parameters
Mosfet(5).Vnd=1200;
Mosfet(5).Ind=50;
Mosfet(5).td1=25;
Mosfet(5).td2=150;
%  Diode temperature dependent parameters
Mosfet(5).kd1=45*10^-3;
%Mosfet(5).kd2=90*10^-3;
Mosfet(5).kd2=45*10^-3;
Mosfet(5).ad1=0;
Mosfet(5).ad2=0;
%  Reverse recovery charge
Mosfet(5).Qrr1=530*10^-9;
Mosfet(5).Qrr2=0;
%  Thermal model
Mosfet(5).Rjcd=0;

%  Judge whether it is a module
Mosfet(5).Module=0;
%  Price(dollar)
Mosfet(5).Price_sw=9.07;
%  Weight(g)
Mosfet(5).Weight_sw=8;
%  Price(dollar)
Mosfet(5).Price_gd=50;
%  Weight(g)
Mosfet(5).Weight_gd=50;


Mosfet(5).a11_on=0.0003879;           %ZEROTH order co-efficienct
Mosfet(5).a12_on=2.869e-05;        %FIRST order co-efficienct
Mosfet(5).a13_on=4.654e-07;        %SECOND order co-efficienct
Mosfet(5).a14_on=-1.263e-10;       %THIRD order co-efficienct
Mosfet(5).a11_off=0.0001109;
Mosfet(5).a12_off=-6.548e-06;
Mosfet(5).a13_off=3.149e-07;
Mosfet(5).a14_off=5.051e-10;
Mosfet(5).V1     =1200;

Mosfet(5).rg1_on=0.002808;      %%ZEROTH order co-efficienct
Mosfet(5).rg2_on=8.229e-05;

Mosfet(5).rg1_off=0.0003573;    %%ZEROTH order co-efficienct
Mosfet(5).rg2_off=0.0001334;
Mosfet(5).I_ref=50;             %Reference current for E with Rg curve


save('Mosfetdata','Mosfet');

%% These parts are for generating BJT database
% Naming rules: Brand Product# Volt Current BJTtype
%% GeneSiC GA100JT17-227 1700V 160/100A SiC Junction Transistor
Bjt(1).Vns=1200;
Bjt(1).Ins=100;
Bjt(1).ts1=25;
Bjt(1).ts2=175;
%  MOSFET temperature dependent parameters
Bjt(1).ks1=10*10^-3;
Bjt(1).ks2=21*10^-3;
Bjt(1).as1=0;
Bjt(1).as2=0;
%  Switching energy (mJ)
Bjt(1).E1_on=3.5*10^-3;
Bjt(1).E2_on=3.55*10^-3;
Bjt(1).E1_off=2.3*10^-3;
Bjt(1).E2_off=2.4*10^-3;
%  Thermal model
Bjt(1).Rjct=0.28;
%%
Bjt(1).Vnd=0;
Bjt(1).Ind=0;
Bjt(1).td1=0;
Bjt(1).td2=0;
%  Mosfet temperature dependent parameters
Bjt(1).kd1=0;
Bjt(1).kd2=0;
Bjt(1).ad1=0;
Bjt(1).ad2=0;
%  Reverse recovery charge
Bjt(1).Qrr1=0;
Bjt(1).Qrr2=0;
%  Thermal model
Bjt(1).Rjcd=0;

%  Judge whether it is a module
Bjt(1).Module=0;
%  Price(dollar)
Bjt(1).Price_sw=9.07;
%  Weight(g)
Bjt(1).Weight_sw=30;
%  Price(dollar)
Bjt(1).Price_gd=50;
%  Weight(g)
Bjt(1).Weight_gd=50; 

%% GeneSiC GA100SICP12-227 1200V 160/100A SiC Junction Transistor
Bjt(2).Vns=800;
Bjt(2).Ins=50;
Bjt(2).ts1=25;
Bjt(2).ts2=175;
%  Mosfet temperature dependent parameters
Bjt(2).ks1=10*10^-3;
Bjt(2).ks2=18*10^-3;
Bjt(2).as1=0;
Bjt(2).as2=0;
%  Switching energy (mJ)
Bjt(2).E1_on=1.8*10^-3;
Bjt(2).E2_on=1.85*10^-3;
Bjt(2).E1_off=1.4*10^-3;
Bjt(2).E2_off=1.3*10^-3;
%  Thermal model
Bjt(2).Rjct=0.28;
%%
Bjt(2).Vnd=800;
Bjt(2).Ind=50;
Bjt(2).td1=25;
Bjt(2).td2=150;
%  Mosfet temperature dependent parameters
Bjt(2).kd1=(1.2-0.9)/100;
Bjt(2).kd2=(1.32-0.75)/100;
Bjt(2).ad1=0.9;
Bjt(2).ad2=0.75;
%  Recovery charge
Bjt(2).Qrr1=4.4*10^-6; %uC
Bjt(2).Qrr2=4.4*10^-6; %uC
%
Bjt(2).Rjcd=0.26;

%  Judge whether it is a module
Bjt(2).Module=0;
%  Price(dollar)
Bjt(2).Price_sw=9.07;
%  Weight(g)
Bjt(2).Weight_sw=30;
%  Price(dollar)
Bjt(2).Price_gd=50;
%  Weight(g)
Bjt(2).Weight_gd=50; 

save('Bjtdata','Bjt');

%% These parts are for generating igbt database
% Naming rules: Brand Product# Volt Current igbt type
%% Onsemi Discrete Si MOSFET FCH023N65S3L4 650V 75A
IGBT(1).Vns=400;
IGBT(1).Ins=40;
IGBT(1).ts1=25;
IGBT(1).ts2=125;
%  IGBT temperature dependent parameters
IGBT(1).ks1=0.023;
IGBT(1).ks2=0.04761;
IGBT(1).as1=0;
IGBT(1).as2=0;
%  Switching energy (J)
IGBT(1).E1_on=0.25*10^-3;
IGBT(1).E2_on=0.25*10^-3;
IGBT(1).E1_off=0.8*10^-3;
IGBT(1).E2_off=0.8*10^-3;
%  Thermal model
IGBT(1).Rjct=0.45;

%Diode parameters
IGBT(1).Vnd=400;
IGBT(1).Ind=40;
IGBT(1).td1=25;
IGBT(1).td2=175;
%  Diode temperature dependent parameters
IGBT(1).kd1=0.023;
IGBT(1).kd2=0.04761;
IGBT(1).ad1=0;
IGBT(1).ad2=0;
%  Reverse Recovery Loss
IGBT(1).Qrr1=19.09e-6;
IGBT(1).Qrr2=0;
%  Thermal model
IGBT(1).Rjcd=0.8;

%  Judge whether it is a module
IGBT(1).Module=0;
%  Price(dollar)
IGBT(1).Price_sw=6.19;
%  Weight(g)
IGBT(1).Weight_sw=5;
%  Price(dollar)
IGBT(1).Price_gd=50;
%  Weight(g)
IGBT(1).Weight_gd=50;


%% Infineon Discrete IGBT IKW40T120 1200V 40A
% Switch parameters
IGBT(2).Vns=600;
IGBT(2).Ins=40;
IGBT(2).ts1=25;
IGBT(2).ts2=150;
%  IGBT temperature dependent parameters
IGBT(2).ks1=(2-1)/50;
IGBT(2).ks2=(3-0.9)/70;
IGBT(2).as1=1;
IGBT(2).as2=0.9;
%  Switching energy (J)
IGBT(2).E1_on=3.3*10^-3;
IGBT(2).E2_on=5*10^-3;
IGBT(2).E1_off=3.2*10^-3;
IGBT(2).E2_off=5.4*10^-3;
%  Thermal model
IGBT(2).Rjct=0.45;

%Diode parameters
IGBT(2).Vnd=600;
IGBT(2).Ind=40;
IGBT(2).td1=25;
IGBT(2).td2=150;
%  Diode temperature dependent parameters
IGBT(2).kd1=(1.7-1)/40;
IGBT(2).kd2=(1.75-0.75)/40;
IGBT(2).ad1=1;
IGBT(2).ad2=0.75;
%  Reverse Recovery Loss
IGBT(2).Qrr1=3.8*10^-6;
IGBT(2).Qrr2=8.8*10^-6;
%  Thermal model
IGBT(2).Rjcd=0.81;

%  Judge whether it is a module
IGBT(2).Module=0;
%  Price(dollar)
IGBT(2).Price_sw=6;
%  Weight(g)
IGBT(2).Weight_sw=5;
%  Price(dollar)
IGBT(2).Price_gd=50;
%  Weight(g)
IGBT(2).Weight_gd=50;


%% Infineon Discrete IGBT IGW75N60T 600V 75A
% Switch parameters
IGBT(3).Vns=400;
IGBT(3).Ins=75;
IGBT(3).ts1=25;
IGBT(3).ts2=175;
%  IGBT temperature dependent parameters
IGBT(3).ks1=(1.4-0.9)/80;
IGBT(3).ks2=(2-0.8)/90;
IGBT(3).as1=0.9;
IGBT(3).as2=0.8;
%  Switching energy (J)
IGBT(3).E1_on=2*10^-3;
IGBT(3).E2_on=2.9*10^-3;
IGBT(3).E1_off=2.5*10^-3;
IGBT(3).E2_off=2.9*10^-3;
%  Thermal model
IGBT(3).Rjct=0.35;

% Diode parameters
IGBT(3).Vnd=0;
IGBT(3).Ind=0;
IGBT(3).td1=0;
IGBT(3).td2=0;
%  Diode temperature dependent parameters
IGBT(3).kd1=0;
IGBT(3).kd2=0;
IGBT(3).ad1=0;
IGBT(3).ad2=0;
%  Reverse recovery charge
IGBT(3).Qrr1=0;
IGBT(3).Qrr2=0;
%  Thermal model
IGBT(3).Rjcd=0;

%  Judge whether it is a module
IGBT(3).Module=0;
%  Price(dollar)
IGBT(3).Price_sw=6.58;
%  Weight(g)
IGBT(3).Weight_sw=5.42;
%  Price(dollar)
IGBT(3).Price_gd=50;
%  Weight(g)
IGBT(3).Weight_gd=50;

%% Infineon Discrete IGBT IGW60T120 1200V 60A
% Switch parameters
IGBT(4).Vns=600;
IGBT(4).Ins=60;
IGBT(4).ts1=25;
IGBT(4).ts2=175;
%  IGBT temperature dependent parameters
IGBT(4).ks1=(2-1)/75;
IGBT(4).ks2=(2.5-0.8)/75;
IGBT(4).as1=1;
IGBT(4).as2=0.8;
%  Switching energy (J)
IGBT(4).E1_on=4.3*10^-3;
IGBT(4).E2_on=6.4*10^-3;
IGBT(4).E1_off=5.2*10^-3;
IGBT(4).E2_off=9.4*10^-3;
%  Thermal model
IGBT(4).Rjct=0.33;

% Diode parameters
IGBT(4).Vnd=0;
IGBT(4).Ind=0;
IGBT(4).td1=0;
IGBT(4).td2=0;
%  Diode temperature dependent parameters
IGBT(4).kd1=0;
IGBT(4).kd2=0;
IGBT(4).ad1=0;
IGBT(4).ad2=0;
%  Reverse recovery charge
IGBT(4).Qrr1=0;
IGBT(4).Qrr2=0;
%  Thermal model
IGBT(4).Rjcd=0;

%  Judge whether it is a module
IGBT(4).Module=0;
%  Price(dollar)
IGBT(4).Price_sw=3.64;
%  Weight(g)
IGBT(4).Weight_sw=5.42;
%  Price(dollar)
IGBT(4).Price_gd=50;
%  Weight(g)
IGBT(4).Weight_gd=50;

%% Infineon Discrete IGBT IKW40N120T2 1200V 40A
% Switch parameters
IGBT(5).Vns=600;
IGBT(5).Ins=40;
IGBT(5).ts1=25;
IGBT(5).ts2=175;
%  IGBT temperature dependent parameters
IGBT(5).ks1=(1.85-0.9)/50;
IGBT(5).ks2=(2.3-0.5)/50;
IGBT(5).as1=0.9;
IGBT(5).as2=0.5;
%  Switching energy (J)
IGBT(5).E1_on=3.2*10^-3;
IGBT(5).E2_on=4.5*10^-3;
IGBT(5).E1_off=2.05*10^-3;
IGBT(5).E2_off=3.8*10^-3;
%  Thermal model
IGBT(5).Rjct=0.31;

% Diode parameters
IGBT(5).Vnd=600;
IGBT(5).Ind=40;
IGBT(5).td1=25;
IGBT(5).td2=175;
%  Diode temperature dependent parameters
IGBT(5).kd1=(1.8-0.8)/50;
IGBT(5).kd2=(2-0.5)/50;
IGBT(5).ad1=0.8;
IGBT(5).ad2=0.5;
%  Reverse recovery charge
IGBT(5).Qrr1=6.6*10^-6;
IGBT(5).Qrr2=6.6*10^-6;
%  Thermal model
IGBT(5).Rjcd=0.53;

%  Judge whether it is a module
IGBT(5).Module=0;
%  Price(dollar)
IGBT(5).Price_sw=7.49;
%  Weight(g)
IGBT(5).Weight_sw=5.42;
%  Price(dollar)
IGBT(5).Price_gd=50;
%  Weight(g)
IGBT(5).Weight_gd=50;

save('IGBTdata','IGBT');


%% This part is for the generation of power modules
%Naming convention: Manufacture_Device type_Part number_Volt_Current
%% CREE SiC Module Powermodule CAS300M17BM2 1700V 225A 
%  Switch parameters
Module(1).Vns=900;
Module(1).Ins=300;
Module(1).ts1=25;
Module(1).ts2=150;
%  Module temperature dependent parameters
Module(1).ks1=(1.8-0)/200;
Module(1).ks2=(3-0)/200;
Module(1).as1=0;
Module(1).as2=0;
%  Switching energy (J)
Module(1).E1_on=13.8*10^-3;
Module(1).E2_on=13*10^-3;
Module(1).E1_off=10*10^-3;
Module(1).E2_off=10*10^-3;
%  Thermal model
Module(1).Rjct=0.067;

%  Diode parameters
Module(1).Vnd=900;
Module(1).Ind=300;
Module(1).td1=25;
Module(1).td2=150;
%  Diode temperature dependent parameters
Module(1).kd1=(0.65-0)/100;
Module(1).kd2=(0.9-0)/100;
Module(1).ad1=0;
Module(1).ad2=0;
%  Thermal model
Module(1).Rjcd=0.06;
%  Recovery charge
Module(1).Qrr1=4.4*10^-6; 
Module(1).Qrr2=4.4*10^-6; 

%  Judge whether it is a module
Module(1).Module=1;
%  Price(dollar)
Module(1).Price_sw=858;
%  Weight(g)
Module(1).Weight_sw=360;
%  Price(dollar)
Module(1).Price_gd=120;
%  Weight(g)
Module(1).Weight_gd=50;

%% CREE SiC Module Powermodule CAS300M12BM2  1200V 404/285A+
%  Switch parameters
Module(2).Vns=600;
Module(2).Ins=300;
Module(2).ts1=25;
Module(2).ts2=150;
%  Switch temperature dependent parameters
Module(2).ks1=(1-0)/200;
Module(2).ks2=(1.7-0)/200;
Module(2).as1=0;
Module(2).as2=0;
%  Switching energy (J)
Module(2).E1_on=6*10^-3;
Module(2).E2_on=5.8*10^-3;
Module(2).E1_off=6*10^-3;
Module(2).E2_off=6*10^-3;
%  Thermal model
Module(2).Rjct=0.07;

%  Diode parameters
Module(2).Vnd=600;
Module(2).Ind=300;
Module(2).td1=25;
Module(2).td2=150;
%  Diode temperature dependent parameters
Module(2).kd1=(0.9-0)/200;
Module(2).kd2=(0.75-0)/100;
Module(2).ad1=0;
Module(2).ad2=0;
%  Thermal model
Module(2).Rjcd=0.073;
%  Recovery charge
Module(2).Qrr1=3.2*10^-6;
Module(2).Qrr2=3.2*10^-6;

%  Judge whether it is a module
Module(2).Module=1;
%  Price(dollar)
Module(2).Price_sw=561;
%  Weight(g)
Module(2).Weight_sw=300;
%  Price(dollar)
Module(2).Price_gd=120;
%  Weight(g)
Module(2).Weight_gd=50;

%% Infineon IGBT Module FF600R17ME4 1700V 600A
%  Switch parameters
Module(3).Vns=900;
Module(3).Ins=600;
Module(3).ts1=25;
Module(3).ts2=150;
%  Switch temperature dependent parameters
Module(3).ks1=(2-0.9)/600;
Module(3).ks2=(2.45-0.6)/600;
Module(3).as1=0.9;
Module(3).as2=0.6;
%  Switching energy (J)
Module(3).E1_on=140*10^-3;
Module(3).E2_on=225*10^-3;
Module(3).E1_off=115*10^-3;
Module(3).E2_off=205*10^-3;
%  Thermal model
Module(2).Rjct=0.033;

%  Diode parameters
Module(3).Vnd=900;
Module(3).Ind=600;
Module(3).td1=25;
Module(3).td2=150;
%  Diode temperature dependent parameters
Module(3).kd1=(1.6-0.75)/400;
Module(3).kd2=(1.65-0.5)/400;
Module(3).ad1=0.75;
Module(3).ad2=0.5;
%  Thermal model
Module(3).Rjcd=0.073;
%  Recovery charge
Module(3).Qrr1=150*10^-6;
Module(3).Qrr2=285*10^-6;


%  Judge whether it is a module
Module(3).Module=1;
%  Price(dollar)
Module(3).Price_sw=269.23;
%  Weight(g)
Module(3).Weight_sw=345;
%  Price(dollar)
Module(3).Price_gd=125;
%  Weight(g)
Module(3).Weight_gd=50;


%% Infineon IGBT module FF150R17KE4 1700V 150A
%  Switch parameters
Module(4).Vns=900;
Module(4).Ins=150;
Module(4).ts1=25;
Module(4).ts2=150;
%  IGBT temperature dependent parameters
Module(4).ks1=(2.75-1.15)/300;
Module(4).ks2=(3.9-1)/300;
Module(4).as1=1.15;
Module(4).as2=1;
% Switching energy (J)
Module(4).E1_on=47*10^-3;
Module(4).E2_on=64*10^-3;
Module(4).E1_off=28*10^-3;
Module(4).E2_off=49*10^-3;
%  Thermal model
Module(4).Rjct=0.135;

%  Diode parameters
Module(4).Vnd=900;
Module(4).Ind=150;
Module(4).td1=25;
Module(4).td2=150;
%  Diode temperature dependent parameters
Module(4).kd1=(1.4-0.9)/90;
Module(4).kd2=(1.4-0.7)/90;
Module(4).ad1=0.9;
Module(4).ad2=0.7;
%  Thermal model
Module(4).Rjcd=0.037;
%  Recovery charge
Module(4).Qrr1=45*10^-6;
Module(4).Qrr2=85*10^-6;


%  Judge whether it is a module
Module(4).Module=1;
%  Price(dollar)
Module(4).Price_sw=105.8;
%  Weight(g)
Module(4).Weight_sw=340;
%  Price(dollar)
Module(4).Price_gd=125.65;
%  Weight(g)
Module(4).Weight_gd=50;


%% Module5:  CREE SiC Module Powermodule CAS120M12BM2 1200V 193/138A
%  Switch parameters
Module(5).Vns=600;
Module(5).Ins=120;
Module(5).ts1=25;
Module(5).ts2=150;
%  Mosfet temperature dependent parameters
Module(5).ks1=2.5/180;
Module(5).ks2=4.4/180;
Module(5).as1=0;
Module(5).as2=0;
% Switching energy (J)
Module(5).E1_on=1.95*10^-3;
Module(5).E2_on=1.7*10^-3;
Module(5).E1_off=0.45*10^-3;
Module(5).E2_off=0.4*10^-3;
%  Thermal model
Module(5).Rjct=0.125;

%  Diode parameters
Module(5).Vnd=600;
Module(5).Ind=120;
Module(5).td1=25;
Module(5).td2=150;
%  Diode temperature dependent parameters
Module(5).kd1=0.75/60;
Module(5).kd2=0.9/60;
Module(5).ad1=0;
Module(5).ad2=0;
%  Thermal model
Module(5).Rjcd=0.108;
%  Recovery charge
Module(5).Qrr1=1.1*10^-6;
Module(5).Qrr2=1.1*10^-6;


%  Judge whether it is a module
Module(5).Module=1;
%  Price(dollar)
Module(5).Price_sw=330;
%  Weight(g)
Module(5).Weight_sw=290;
%  Price(dollar)
Module(5).Price_gd=199;
%  Weight(g)
Module(5).Weight_gd=44;

%% Infineon IGBT module FD1000R33HL3-K 3300V 1000A
%  Switch parameters
Module(6).Vns=1800;
Module(6).Ins=1000;
Module(6).ts1=25;
Module(6).ts2=150;
%  IGBT temperature dependent parameters
Module(6).ks1=(3-1.2)/1600;
Module(6).ks2=(4-1.45)/1600;
Module(6).as1=1.2;
Module(6).as2=1.45;
% Switching energy (J)
Module(6).E1_on=1550*10^-3;
Module(6).E2_on=2400*10^-3;
Module(6).E1_off=1600*10^-3;
Module(6).E2_off=2050*10^-3;
%  Thermal model
Module(6).Rjct=0.135;

%  Diode parameters
Module(6).Vnd=1800;
Module(6).Ind=1000;
Module(6).td1=25;
Module(6).td2=150;
%  Diode temperature dependent parameters
Module(6).kd1=(2.55-1.1)/1400;
Module(6).kd2=(2.55-1.3)/1400;
Module(6).ad1=1.1;
Module(6).ad2=1.3;
%  Thermal model
Module(6).Rjcd=0.037;
%  Recovery charge
Module(6).Qrr1=1000*10^-6;
Module(6).Qrr2=1950*10^-6;


%  Judge whether it is a module
Module(6).Module=1;
%  Price(dollar)
Module(6).Price_sw=300;
%  Weight(g)
Module(6).Weight_sw=1200;
%  Price(dollar)
Module(6).Price_gd=125.65;
%  Weight(g)
Module(6).Weight_gd=50;

%% EXperiment
%% CREE SiC Module Powermodule CAS300M17BM2 1700V 225A 
%  Switch parameters
Module(7).Vns=1160;
Module(7).Ins=300;
Module(7).ts1=25;
Module(7).ts2=150;
%  Module temperature dependent parameters
Module(7).ks1=(1.8-0)/200;
Module(7).ks2=(3-0)/200;
Module(7).as1=0;
Module(7).as2=0;
%  Switching energy (J)
Module(7).E1_on=17.4*10^-3;
Module(7).E2_on=17.4*10^-3;
Module(7).E1_off=12.1*10^-3;
Module(7).E2_off=12.1*10^-3;
%  Thermal model
Module(7).Rjct=0.067;

%  Diode parameters
Module(7).Vnd=900;
Module(7).Ind=300;
Module(7).td1=25;
Module(7).td2=150;
%  Diode temperature dependent parameters
Module(7).kd1=(0.65-0)/100;
Module(7).kd2=(0.9-0)/100;
Module(7).ad1=0;
Module(7).ad2=0;
%  Thermal model
Module(7).Rjcd=0.06;
%  Recovery charge
Module(7).Qrr1=4.4*10^-6; 
Module(7).Qrr2=4.4*10^-6; 

%  Judge whether it is a module
Module(7).Module=1;
%  Price(dollar)
Module(7).Price_sw=858;
%  Weight(g)
Module(7).Weight_sw=360;
%  Price(dollar)
Module(7).Price_gd=120;
%  Weight(g)
Module(7).Weight_gd=50;

save('Moduledata','Module');
end