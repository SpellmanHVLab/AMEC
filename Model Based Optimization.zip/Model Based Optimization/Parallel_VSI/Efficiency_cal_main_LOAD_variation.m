%*********************** Efficiency & Loss calculation **************************
% 
clear all;
close all;
clc;

x=1; %Minimum 12 Devices in 3LNPC
y=1; %Minimum 09 Devices in 3LTNPC
z=1;  %Minimum 09 Devices in 2LC

%% This is the program for Ttype efficiency calculation
%% Entering Device type
run('Device_initial.m');
load('Mosfetdata.mat');   % Loading discrete SiC Mosfet database
load('Diodedata.mat');    % Loading diode database
load('Moduledata.mat');   % Loading power module database
load('IGBTdata.mat');     % Loading power module database
load('Bjtdata.mat');      % Loading BJT database
%% Devices:
%% Diode
% Diode1:   ONSEMI FFSH2065A-D 650V 20A Schottcky diode
% Diode2:   CREE C5D50065D 650V 50A Schottcky diode
% Diode3:   CREE C5D50065D 1700V 25A Schottcky diode
% Diode4:   IXYS DSEI2x101-06A 600V 200A Schottcky diode

%% Mosfet
% Mosfet1:  CREE C2M0025120D 1200V 90/60A SiC MOSFET
% Mosfet2:  Onsemi NTH027N65S3F-D 650V 75 Si MOSFET
% Mosfet3:  Rohm SCT2120AF 650V 29/20A SiC Mosfet
% Mosfet4:  CREE CPM2-1200-0025B 1200V 98/71A SiC MOSFET   Confirmed by Mustafeez
% Mosfet5:  CREE CPM2-1700-0045B 1700V 72/48A SiC MOSFET   Confirmed by Mustafeez

%% IGBT
% IGBT1:    Infineon Discrete IGBT IKW50N60T 600V 50A
% IGBT2:    Infineon Discrete IGBT IKW40T120 1200V 40A
% IGBT3:    Infineon Discrete IGBT IGW75N60T 600V 75A
% IGBT4:    Infineon Discrete IGBT IGW60T120 1200V 60A
% IGBT5:    Infineon Discrete IGBT IKW40N120T2 1200V 40A
%% Module
% Module1:  CREE SiC Module Powermodule CAS300M17BM2 1700V 225A 
% Module2:  CREE SiC Module Powermodule CAS300M12BM2  1200V 404/285A
% Module3:  Infineon IGBT Module FF600R17ME4 1700V 600A
% Module4:  Infineon IGBT module FF150R17KE4 1700V 150A
% Module5:  CREE SiC Module Powermodule CAS120M12BM2 1200V 193/138A 
%% BJT:
% Bjt1: GeneSiC GA100JT17-227 1700V 160/100A SiC Junction Transistor
% Bjt2: GeneSiC GA100SICP12-227 1200V 160/100A SiC Junction Transistor
%%

%% Topology & Device Combination Selection
disp('************************** Loss Evaluation ***************************');
disp('************************ Topology Selection **************************');
disp('------- Input 1: 2L Topology -----------------------------------------');
disp('------- Input 2: 3L NPC Topology -------------------------------------');
disp('------- Input 3: 3L ANPC Topology ----------------------------------');
disp('------- Input 4: 3L T-type Topology ----------------------------------');

Topology=input('------- Enter Topology Number: '); 
disp(' ');
disp('************************ Combination Selection ***********************');
disp('------- Input 1: Si/SiC MOSFET ;Clamping SiC Diode Device --------------------------------------');
disp('------- Input 2: SiC MOSFET ;Clamping SiC Diode Device -----------------------------------');
disp('------- Input 3: Hybrid Switch module --------------------------------');
disp('------- Input 4: SiC BJT Devices -------------------------------------');
disp('------- Input 5: 3.3 KV IGBT Devices or NPC 1700V SiC -------------------------------------');
comb=input('------- Enter Combination Number: '); 
disp(' ');

disp('************************ Combination Selection ***********************');
disp('------- Input 1: Vref=490 (Peak Phase);P=450000;Vdc=1000;pf=.95 ---------------------');
disp('------- Input 2: Vref=490;P=500000;Vdc=1000;pf=0.8 ------------------');
disp('------- Input 3: Vref=490;P=500000;Vdc=1000;pf=-0.8 ------------------');
disp('------- Input 4: Vref=150;P=500000;Vdc=1000;pf=0.85 ------------------');
disp('------- Input 5: Vref=1000;P=500000;Vdc=2000;pf=0.85 ------------------');
Case=input('------- Enter Case Type: ');
disp(' ');
%%
switch Topology;
    case 1 %% 2L Topology
     switch comb
         case 1  %%Si/SiC MOSFET ;Clamping SiC Diode Device
             Phaseleg_switch=Mosfet(4);
             Phaseleg_diode=Mosfet(4);
             Phaseleg_switch_parallel_num=z;
             Phaseleg_diode_parallel_num=z;
             Phaseleg_switch_series_num=1;

         case 2  %%SiC MOSFET ;Clamping SiC Diode Device
             Phaseleg_switch=Mosfet(1);
             Phaseleg_diode=Mosfet(1);
             Phaseleg_switch_parallel_num=3;
             Phaseleg_diode_parallel_num=3;
             Phaseleg_switch_series_num=1;

         case 3  %%Hybrid Switch module
             Phaseleg_Mosfet=Module(1);
             Phaseleg_IGBT=Module(3);
             Phaseleg_SiC_diode=Module(1);
             Phaseleg_Mosfet_num=1;
             Phaseleg_IGBT_num=1;
             Phaseleg_SiC_diode_num=3;

         case 4  %%SiC BJT Devices
             Phaseleg_switch=Bjt(1);
             Phaseleg_diode=Diode(3);
             Phaseleg_switch_parallel_num=6;
             Phaseleg_diode_parallel_num=24;
             Phaseleg_switch_series_num=1;

         case 5  %%3.3 KV IGBT Devices or NPC 1700V SiC
             Phaseleg_switch=Module(6);
             Phaseleg_diode=Module(6);
             Phaseleg_switch_parallel_num=1;
             Phaseleg_diode_parallel_num=1;
             Phaseleg_switch_series_num=1;

     end
     switch comb
         case 3
             Device_sw=[Phaseleg_Mosfet,Phaseleg_IGBT,Phaseleg_SiC_diode];
             Device_num=[Phaseleg_Mosfet_num,Phaseleg_IGBT_num,Phaseleg_SiC_diode_num];
         otherwise
             Device_sw=[Phaseleg_switch,Phaseleg_diode];
             Device_num=[Phaseleg_switch_parallel_num,Phaseleg_diode_parallel_num,Phaseleg_switch_series_num];
     end
     %%
    case 2 %% 3L NPC Topology
        
       switch comb
         case 1  %%Si/SiC MOSFET ;Clamping SiC Diode Device
             Phaseleg_switch=Mosfet(4);                 %First and Fourth Switch in the Phase Leg
             Phaseleg_diode=Mosfet(4);                  %First and Fourth Diode in the Phase Leg
           % Clamping_switch=Mosfet(4);                 %Second and Third Switch in the Phase Leg
             Clamping_diode=Diode(2);                   %Second and Third Diode in the Phase Leg
             Phaseleg_switch_parallel_num=x;
             Phaseleg_diode_parallel_num=x;
             Clamping_diode_num_parallel=x;
             Phaseleg_switch_series_num=1;
             Clamping_diode_series_num=1;
             %Phaseleg_switch=Module(3);
             %Phaseleg_diode=Module(3);
             %Clamping_diode=Diode(1);
             %Phaseleg_switch_num=1;
             %Phaseleg_diode_num=1;
             %Clamping_diode_num=12;
         case 2  %%SiC MOSFET ;Clamping SiC Diode Device
             Phaseleg_switch=Mosfet(1);
             Phaseleg_diode=Mosfet(1);
             Clamping_diode=Diode(1);
             Phaseleg_switch_parallel_num=3;
             Phaseleg_diode_parallel_num=3;
             Clamping_diode_num_parallel=3;
             Phaseleg_switch_series_num=1;
             Clamping_diode_series_num=1;
             %Phaseleg_switch=Mosfet(1);
             %Phaseleg_diode=Mosfet(1);
             %Clamping_diode=Diode(1);
             %Phaseleg_switch_num=3;
             %Phaseleg_diode_num=3;
             %Clamping_diode_num=3;
         case 3  %%Hybrid Switch module
             Phaseleg_Mosfet=Module(5);
             Phaseleg_IGBT=Module(3);
             Phaseleg_SiC_diode=Diode(1);
             Clamping_diode=Diode(1);
             Phaseleg_Mosfet_num=1;
             Phaseleg_IGBT_num=1;
             Phaseleg_SiC_diode_num=12;
             Clamping_diode_num_parallel=12;
         case 4  %%SiC BJT Devices
             Phaseleg_switch=Bjt(2);
             Phaseleg_diode=Bjt(2);
             Clamping_switch=Bjt(2);
             Clamping_diode=Diode(1);
             Phaseleg_switch_parallel_num=6;
             Phaseleg_diode_parallel_num=6;
             Clamping_switch_num_parallel=6;
             Clamping_diode_num_parallel=12;
             Phaseleg_switch_series_num=1;
             Clamping_switch_series_num=1;
             Clamping_diode_series_num=1;
             %Phaseleg_switch=Bjt(2);
             %Phaseleg_diode=Bjt(2);
             %Clamping_diode=Diode(1);
             %Phaseleg_switch_num=6;
             %Phaseleg_diode_num=6;
             %Clamping_diode_num=12;
%          case 5
%              Phaseleg_switch=Module(1);
%              Phaseleg_diode=Module(1);
%              Clamping_diode=Module(1);
%              Phaseleg_switch_num=4;
%              Phaseleg_diode_num=4;
%              Clamping_diode_num=4;
%          case 5
%              Phaseleg_switch=Module(3);
%              Phaseleg_diode=Module(3);
%              Clamping_diode=Module(3);
%              Phaseleg_switch_num=2;
%              Phaseleg_diode_num=2;
%              Clamping_diode_num=2;
         case 5  %%3.3 KV IGBT Devices or NPC 1700V SiC
             Phaseleg_switch=Module(1);     %First and Fourth Switch in the Phase Leg
             Phaseleg_diode=Module(1);      %First and Fourth Diode in the Phase Leg
             Clamping_switch=Module(1);     %Second and Third Switch in the Phase Leg
             Clamping_diode=Module(1);      %Second and Third Diode in the Phase Leg
             Phaseleg_switch_parallel_num=4;
             Phaseleg_diode_parallel_num=4;
             Clamping_switch_num_parallel=4;
             Clamping_diode_num_parallel=4;
             Phaseleg_switch_series_num=1;
             Clamping_switch_series_num=1;
             Clamping_diode_series_num=1;
             %Phaseleg_switch=Module(1);
             %Phaseleg_diode=Module(1);
             %Clamping_diode=Module(1);
             %Phaseleg_switch_num=4;
             %Phaseleg_diode_num=4;
             %Clamping_diode_num=4;
       end
       switch comb
         case 3
             Device_sw=[Phaseleg_Mosfet,Phaseleg_IGBT,Phaseleg_SiC_diode,Clamping_diode];
             Device_num=[Phaseleg_Mosfet_num,Phaseleg_IGBT_num,Phaseleg_SiC_diode_num,Clamping_diode_num_parallel];
           otherwise
             Device_sw=[Phaseleg_switch,Phaseleg_diode,Clamping_diode];
             Device_num=[Phaseleg_switch_parallel_num,Phaseleg_diode_parallel_num,Clamping_diode_num_parallel,Phaseleg_switch_series_num,Clamping_diode_series_num];             %Device_sw=[Phaseleg_switch,Phaseleg_diode,Clamping_diode];
             %Device_num=[Phaseleg_switch_num,Phaseleg_diode_num,Clamping_diode_num];
       end
     
     %%
    case 3 %% 3L ANPC Topology
       switch comb
         case 1  %%Si/SiC MOSFET ;Clamping SiC Diode Device
             Phaseleg_switch=Mosfet(4);                 %First and Fourth Switch in the Phase Leg
             Phaseleg_diode=Mosfet(4);                  %First and Fourth Diode in the Phase Leg
             Clamping_switch=Mosfet(4);                 %Second and Third Switch in the Phase Leg
             Clamping_diode=Mosfet(4);                  %Second and Third Diode in the Phase Leg
             Phaseleg_switch_parallel_num=x;
             Phaseleg_diode_parallel_num=x;
             Clamping_switch_num_parallel=x;
             Clamping_diode_num_parallel=x;
             Phaseleg_switch_series_num=1;
             Clamping_switch_series_num=1;
             %Phaseleg_switch=Module(3);
             %Phaseleg_diode=Module(3);
             %Clamping_diode=Diode(1);
             %Phaseleg_switch_num=1;
             %Phaseleg_diode_num=1;
             %Clamping_diode_num=12;
         case 2  %%SiC MOSFET ;Clamping SiC Diode Device
             Phaseleg_switch=Mosfet(1);
             Phaseleg_diode=Mosfet(1);
             Clamping_switch=Mosfet(1);
             Clamping_diode=Diode(1);
             Phaseleg_switch_parallel_num=3;
             Phaseleg_diode_parallel_num=3;
             Clamping_switch_num_parallel=3;
             Clamping_diode_num_parallel=3;
             Phaseleg_switch_series_num=1;
             Clamping_switch_series_num=1;
             %Phaseleg_switch=Mosfet(1);
             %Phaseleg_diode=Mosfet(1);
             %Clamping_diode=Diode(1);
             %Phaseleg_switch_num=3;
             %Phaseleg_diode_num=3;
             %Clamping_diode_num=3;
         case 3  %%Hybrid Switch module
             Phaseleg_Mosfet=Module(5);
             Phaseleg_IGBT=Module(3);
             Phaseleg_SiC_diode=Diode(1);
             Clamping_diode=Diode(1);
             Phaseleg_Mosfet_num=1;
             Phaseleg_IGBT_num=1;
             Phaseleg_SiC_diode_num=12;
             Clamping_diode_num_parallel=12;
         case 4  %%SiC BJT Devices
             Phaseleg_switch=Bjt(2);
             Phaseleg_diode=Bjt(2);
             Clamping_switch=Bjt(2);
             Clamping_diode=Diode(1);
             Phaseleg_switch_parallel_num=6;
             Phaseleg_diode_parallel_num=6;
             Clamping_switch_num_parallel=6;
             Clamping_diode_num_parallel=12;
             Phaseleg_switch_series_num=1;
             Clamping_switch_series_num=1;
             Clamping_diode_series_num=1;
             %Phaseleg_switch=Bjt(2);
             %Phaseleg_diode=Bjt(2);
             %Clamping_diode=Diode(1);
             %Phaseleg_switch_num=6;
             %Phaseleg_diode_num=6;
             %Clamping_diode_num=12;
         case 5  %%3.3 KV IGBT Devices or NPC 1700V SiC
             Phaseleg_switch=Module(1);     %First and Fourth Switch in the Phase Leg
             Phaseleg_diode=Module(1);      %First and Fourth Diode in the Phase Leg
             Clamping_switch=Module(1);     %Second and Third Switch in the Phase Leg
             Clamping_diode=Module(1);      %Second and Third Diode in the Phase Leg
             Phaseleg_switch_parallel_num=4;
             Phaseleg_diode_parallel_num=4;
             Clamping_switch_num_parallel=4;
             Clamping_diode_num_parallel=4;
             Phaseleg_switch_series_num=1;
             Clamping_switch_series_num=1;
             Clamping_diode_series_num=1;
             %Phaseleg_switch=Module(1);
             %Phaseleg_diode=Module(1);
             %Clamping_diode=Module(1);
             %Phaseleg_switch_num=4;
             %Phaseleg_diode_num=4;
             %Clamping_diode_num=4;
       end
       switch comb
         case 3
             Device_sw=[Phaseleg_Mosfet,Phaseleg_IGBT,Phaseleg_SiC_diode,Clamping_diode];
             Device_num=[Phaseleg_Mosfet_num,Phaseleg_IGBT_num,Phaseleg_SiC_diode_num,Clamping_diode_num_parallel];
           otherwise
             Device_sw=[Phaseleg_switch,Phaseleg_diode,Clamping_switch,Clamping_diode];
             Device_num=[Phaseleg_switch_parallel_num,Phaseleg_diode_parallel_num,Clamping_switch_num_parallel,Clamping_diode_num_parallel,Phaseleg_switch_series_num,Clamping_switch_series_num];             %Device_sw=[Phaseleg_switch,Phaseleg_diode,Clamping_diode];
             %Device_num=[Phaseleg_switch_num,Phaseleg_diode_num,Clamping_diode_num];
     end
%%     
    case 4  %% T-type
       switch comb
         case 1  %%Si/SiC MOSFET ;Clamping SiC Diode Device
             Phaseleg_switch=Mosfet(5);
             Phaseleg_diode=Mosfet(5);
             Clamping_switch=Mosfet(4);
             Clamping_diode=Mosfet(4);
             Phaseleg_switch_parallel_num=y;
             Phaseleg_diode_parallel_num=y;
             Clamping_switch_num_parallel=y;
             Clamping_diode_num_parallel=y;
             Phaseleg_switch_series_num=1;
             Clamping_switch_series_num=1;

         case 2  %%SiC MOSFET ;Clamping SiC Diode Device
             Phaseleg_switch=Mosfet(1);
             Phaseleg_diode=Mosfet(1);
             Clamping_switch=Mosfet(1);
             Clamping_diode=Mosfet(1);
             Phaseleg_switch_parallel_num=3;
             Phaseleg_diode_parallel_num=3;
             Clamping_switch_num_parallel=3;
             Clamping_diode_num_parallel=3;
             Phaseleg_switch_series_num=1;
             Clamping_switch_series_num=1;

         case 3  %%Hybrid Switch module
             Phaseleg_Mosfet=Module(1);
             Phaseleg_IGBT=Module(3);
             Phaseleg_SiC_diode=Diode(3);
             Clamping_Mosfet=Mosfet(1);
             Clamping_IGBT=IGBT(5);
             Clamping_SiC_diode=Diode(1);
             Phaseleg_Mosfet_num=1;
             Phaseleg_IGBT_num=1;
             Phaseleg_SiC_diode_num=24;
             Clamping_Mosfet_num=2;
             Clamping_IGBT_num=15;
             Clamping_SiC_diode_num=12;
%              Phaseleg_Mosfet=Module(1);
%              Phaseleg_IGBT=Module(3);
%              Phaseleg_SiC_diode=Module(1);
%              Clamping_Mosfet=Mosfet(1);
%              Clamping_IGBT=IGBT(5);
%              Clamping_SiC_diode=Diode(1);
%              Phaseleg_Mosfet_num=1;
%              Phaseleg_IGBT_num=1;
%              Phaseleg_SiC_diode_num=1;
%              Clamping_Mosfet_num=2;
%              Clamping_IGBT_num=15;
%              Clamping_SiC_diode_num=12;
         case 4  %%SiC BJT Devices
             Phaseleg_switch=Bjt(1);
             Phaseleg_diode=Diode(3);
             Clamping_switch=Bjt(2);
             Clamping_diode=Bjt(2);
             Phaseleg_switch_parallel_num=6;
             Phaseleg_diode_parallel_num=24;
             Clamping_switch_num_parallel=6;
             Clamping_diode_num_parallel=6;
             Phaseleg_switch_series_num=1;
             Clamping_switch_series_num=1;

         case 5  %%3.3 KV IGBT Devices or NPC 1700V SiC
             Phaseleg_switch=Module(2);
             Phaseleg_diode=Module(2);
             Clamping_switch=Mosfet(1);
             Clamping_diode=Diode(1);
             Phaseleg_switch_parallel_num=3;
             Phaseleg_diode_parallel_num=3;
             Clamping_switch_num_parallel=14;
             Clamping_diode_num_parallel=20;
             Phaseleg_switch_series_num=1;
             Clamping_switch_series_num=1;

       end
       switch comb
         case 3
             Device_sw=[Phaseleg_Mosfet,Phaseleg_IGBT,Phaseleg_SiC_diode,Clamping_Mosfet,Clamping_IGBT,Clamping_SiC_diode];
             Device_num=[Phaseleg_Mosfet_num,Phaseleg_IGBT_num,Phaseleg_SiC_diode_num,Clamping_Mosfet_num,Clamping_IGBT_num,Clamping_SiC_diode_num];
         otherwise
             Device_sw=[Phaseleg_switch,Phaseleg_diode,Clamping_switch,Clamping_diode];
             Device_num=[Phaseleg_switch_parallel_num,Phaseleg_diode_parallel_num,Clamping_switch_num_parallel,Clamping_diode_num_parallel,Phaseleg_switch_series_num,Clamping_switch_series_num];
       end
end
%% Select system parameters
switch Case
    case 1
        Vll_rms=172;
        Vref=Vll_rms*sqrt(2/3);        %%%Peak of Phase Voltage
        S=1.5510e+03;
        pf=0.9985;
        P=S*pf;
        mi=0.97;
        Vdc=sqrt(3/2)*Vll_rms/mi;      %%%For 2L Converter
        f1=100;
        Rcs=0.1;
        Rsa=.045;
        Tamb=25;
        
    case 2 
        Vll_rms=600;
        Vref=Vll_rms*sqrt(2/3);        %%%Peak of Phase Voltage
        S=450e+03;
        pf=0.9985;
        P=S*pf;
        mi=0.97;
        Vdc=2*sqrt(2/3)*Vll_rms/mi;    %%%For 3L-TNPC/ANPC/NPC Converter
        f1=100;
        Rcs=0.1;
        Rsa=.045;
        Tamb=25;
end


%% Price & Weight Calculation
%Weight=Weight_cal(Device_sw,Device_num,Topology,comb);
%Price=Price_cal(Device_sw,Device_num,Topology,comb);
% Converter efficiency in different switching frequency
% 5k-75k
for k=1:1:20                   %Number of Converters Running in Parallel
        S_new=S*k/20;
        Vdc=1000;
        Total_Devices=24/k;   %For a Fixed Number of Devices Overall
        Total_Devices=24;     %For a Fixed Number of Devices per Single Converter
        Clamp_Leg=4;
        Phase_Leg=(Total_Devices-2*Clamp_Leg)/2;
        Device_num(1:4)=[Phase_Leg,Phase_Leg,Clamp_Leg,Clamp_Leg];  %Just Comment it when no more interested in Sweeping options
        T_device=Tamb; % Device temperature
        Rg=6.8;
        fs=70e3;
        System_para=[f1,fs,Vdc,Vref,S_new,pf,Rcs,Rsa,Tamb,T_device]; % Setting system parameters
            switch Topology
                case 1  %%2L Topology
                    switch comb
                        case 3  %%Hybrid Switch module
                            [Loss_Total,Conduction_Loss,Switch_Loss]=PowerLossFun_2L_Hybrid(System_para,Device_sw,Device_num);
                        otherwise  %%Other than Hybrid Switch module
                            [T_device_new, Loss_Total, Conduction_Loss, Switch_Loss] = ThermalModel_2L(System_para,Device_sw,Device_num,Rg);
                            %[Loss_Total,Conduction_Loss,Switch_Loss]=PowerLossFun_2L(System_para,Device_sw,Device_num,Rg);
                    end
             
                case 2  %%3L NPC Topology
                    switch comb
                        case 3  %%Hybrid Switch module
                            [Loss_Total,Conduction_Loss,Switch_Loss]=PowerLossFun_NPC_Hybrid(System_para,Device_sw,Device_num);
                    otherwise  %%Other than Hybrid Switch module
                            [T_device_new, Loss_Total, Conduction_Loss, Switch_Loss] = ThermalModel_3LNPC(System_para,Device_sw,Device_num,Rg);
                    end
                    
                case 3  %%3L ANPC Topology
                    switch comb
                        case 3  %%Hybrid Switch module
                            [Loss_Total,Conduction_Loss,Switch_Loss]=PowerLossFun_NPC_Hybrid(System_para,Device_sw,Device_num);
                    otherwise  %%Other than Hybrid Switch module
                            [T_device_new, Loss_Total, Conduction_Loss, Switch_Loss] = ThermalModel_3LANPC(System_para,Device_sw,Device_num,Rg);
                    end    
             
                case 4  %%3L T-type Topology
                    switch comb
                        case 3  %%Hybrid Switch module
                            [Loss_Total,Conduction_Loss,Switch_Loss]=PowerLossFun_Ttype_Hybrid(System_para,Device_sw,Device_num);
                        otherwise  %%Other than Hybrid Switch module
                            [T_device_new, Loss_Total, Conduction_Loss, Switch_Loss] = ThermalModel_3LTNPC(System_para,Device_sw,Device_num,Rg);
                    end  
            end
        Efficiency(k)=(S_new*pf)./((S_new*pf)+3*Loss_Total)*100;
        P_cond(k)=3*sum(Conduction_Loss);
        P_sw(k)=3*sum(Switch_Loss);
        T_junction(k)=T_device_new;
      
        %subplot(2,1,1)
        %plot(P_cond,'Linewidth',4);hold on;
        %subplot(2,1,2)
        %plot(P_sw,'Linewidth',4);hold on;
end
plot(Efficiency,'Linewidth',4);hold on;
save('VSI_LOAD_VARIATION','Efficiency');