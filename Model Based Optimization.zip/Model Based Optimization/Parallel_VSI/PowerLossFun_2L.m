function [Loss, Cond_Loss, Switch_Loss] =PowerLossFun_2L(System_para,Device_sw,Device_num,Rg)

%% initial system parameters
f1=System_para(1);
fs=System_para(2);
Vdc=System_para(3);
Vref=System_para(4);
P=System_para(5);
pf=System_para(6);
T_device=System_para(10);
%% Calculate system parameters
i=[0 0 0];  % three phase currents
%Vc=Vdc/2;   % commutation voltage of devices
if (pf>0)angle=acos(pf);
else angle=-acos(-pf);
end
Carrier=fs/f1;    % carrier ratio
N=floor(Carrier);
%% Device Initial
% Phase Leg:        LegMosfet  LegIGBT    LegDiode,
% Pahse Leg No.:    Ns1_MOS    Ns1_IGBT   Nd1_DIODE
%                   Ns2_MOS    Ns2_IGBT   Nd2_DIODE
%% Load Calculation p.f.
Power=P;          % active power
AP=Power/pf;         % apparent power
I=(2/3)*AP/Vref;    % magnitude of phase current
%% initial power matrix
Pswitching=[0 0 0;
    0 0 0];
%% intial tempurature as well as forward voltage
T_phaseleg_mos=[T_device T_device];
T_phaseleg_sicD=[T_device T_device];
Device_temp=[T_phaseleg_mos, T_phaseleg_sicD];
%% calculate the power loss in one switching cycle
for m=0:1:N
    %% three phase current calculation
    theta=m*2*pi/N;
    i(1)=I*cos(theta-angle);
    i(2)=I*cos(theta-angle-2*pi/3);
    i(3)=I*cos(theta-angle+2*pi/3);
    %% calcuation Switching function and time
    [S, T]=SVPWM(Vref,theta,Vdc,fs);
    %% Conduction Loss Power Calculation
    Pconduction=Device_num(3)*Pcondution_function_2L(S,T,i,Device_temp,Device_sw,Device_num,System_para);
    
    %% S1 and D1
    Pc_mos_s1(m+1)=Pconduction(1,1);
    Pc_sic_d1(m+1)=Pconduction(1,2);
    %% S2 and D2
    Pc_mos_s2(m+1)=Pconduction(2,1);
    Pc_sic_d2(m+1)=Pconduction(2,2);
    
    %% swtiching loss power Calculation
    Pswitching=Device_num(3)*Pswitching_function_2L(S,i,System_para,Device_temp,Device_sw,Device_num,Rg);
    
    %% S1 and D1    
    Psw_mos_s1(m+1)=Pswitching(1,1);
    Psw_sic_d1(m+1)=Pswitching(1,2);
    %% S2 and D2
    Psw_mos_s2(m+1)=Pswitching(2,1);
    Psw_sic_d2(m+1)=Pswitching(2,2);
    %% total power loss
    Psum_mos_s1(m+1)=Psw_mos_s1(m+1)+Pc_mos_s1(m+1);
    Psum_sic_d1(m+1)=Psw_sic_d1(m+1)+Pc_sic_d1(m+1);
    Psum_mos_s2(m+1)=Psw_mos_s2(m+1)+Pc_mos_s2(m+1);
    Psum_sic_d2(m+1)=Psw_sic_d2(m+1)+Pc_sic_d2(m+1);
    %% Reset temp parameters
    Pcond=[0,0;
    0,0];
    Pconduction=[0,0;
    0,0];
end
%% Conculsion of Power Loss
TotalConductionPowerLoss=1./fs.*f1*[sum(Pc_mos_s1) sum(Pc_sic_d1) sum(Pc_mos_s2) sum(Pc_sic_d2)];% sum(PswitchPb1s) sum(PswitchPb1d) sum(PswitchPb2s) sum(PswitchPb2d) sum(PswitchPc1s) sum(PswitchPc1d) sum(PswitchPc2s) sum(PswitchPc2d)];
TotalSwitchingPowerLoss=1./fs.*f1*[sum(Psw_mos_s1) sum(Psw_sic_d1) sum(Psw_mos_s2) sum(Psw_sic_d2)];% sum(Pb1s) sum(Pb1d) sum(Pb2s) sum(Pb2d) sum(Pc1s) sum(Pc1d) sum(Pc2s) sum(Pc2d)];
TotalPowerLoss=TotalSwitchingPowerLoss+TotalConductionPowerLoss;
%%
Loss=sum(TotalPowerLoss);
Switch_Loss=(TotalSwitchingPowerLoss);
Cond_Loss=(TotalConductionPowerLoss);
end



function Pconduction=Pcondution_function_2L(S,T,i,Device_temp,Device_sw,Device_num,System_para)
%% Conduction Loss Calculation
fs=System_para(2);
Pconduction=[0,0;
    0,0];
N_mos=Device_num(1);
N_sicD=Device_num(2);
for t=1:1:3
        Sa=S(t,1);
        %accodrding to different conditions, we can calculate the current
        %loop and conduction loss based on current in each phase and
        %switching function.
        Pcond=T(t).*fs.*CondPowerLoss_2L(i,Sa,Device_temp,Device_sw,Device_num);
        Pconduction=Pcond+Pconduction;
end
    %% S1 and D1
    Pconduction(1,1)=Pconduction(1,1)*N_mos;
    Pconduction(1,2)=Pconduction(1,2)*N_sicD;
    %% S2 and D2
    Pconduction(2,1)=Pconduction(2,1)*N_mos;
    Pconduction(2,2)=Pconduction(2,2)*N_sicD;
end

%%
function  Pcond=CondPowerLoss_2L(i,Sa,Device_temp,Device_sw,Device_num)
%%

%% i calacution
ia=i(1);
%% Phase Leg Current Sharing and Forward Voltage
[Vs_mos,is_mos]=V_eq_2L(ia,Device_temp(1),Device_sw(1),Device_num(1));
[Vd_Diode,id_sicD]=V_eqc_2L(ia,Device_temp(2),Device_sw(2),Device_num(2));

%% S1 and D1 Conduction Loss 
Pcond_mos_s1=(Vs_mos*is_mos)*((ia>=0)&(Sa==1));
Pcond_sic_d1=(Vd_Diode*id_sicD)*((ia<0)&(Sa==1));
%% S2 and D2 Conduction Loss 
Pcond_mos_s2=(Vs_mos*is_mos)*((ia<0)&(Sa==0));
Pcond_sic_d2=(Vd_Diode*id_sicD)*((ia>=0)&(Sa==0));

Pcond=[Pcond_mos_s1,Pcond_sic_d1;
       Pcond_mos_s2,Pcond_sic_d2];
end

function [Vfs,i_mos]=V_eq_2L(i,Device_temp,Device_sw,Device_num)
%% tempreture dependent parameters
Phaseleg_mos=Device_sw;
%%
ts_mos=Device_temp;
%%
N_mos=Device_num;
%% Mosfet tempreture dependent parameters
k1_mos=Phaseleg_mos.ks1;
k2_mos=Phaseleg_mos.ks2;
a1_mos=Phaseleg_mos.as1;
a2_mos=Phaseleg_mos.as2;
t1_mos=Phaseleg_mos.ts1;
t2_mos=Phaseleg_mos.ts2;
%%
i_total=abs(i);
i_mos=i_total/N_mos;
K_MOS=((ts_mos-t1_mos)/(t2_mos-t1_mos)*(k2_mos-k1_mos)+k1_mos);
A_MOS=(ts_mos-t1_mos)/(t2_mos-t1_mos)*(a2_mos-a1_mos)+a1_mos;
%%
Vfs=K_MOS*i_mos+A_MOS;
end

function [Vfs,i_sicD]=V_eqc_2L(i,Device_temp,Device_sw,Device_num)
%% tempreture dependent parameters
Phaseleg_sicD=Device_sw;
%%
ts_sicD=Device_temp;
%%
N_mos=Device_num;
%% Mosfet tempreture dependent parameters
k1_mos=Phaseleg_sicD.kd1;
k2_mos=Phaseleg_sicD.kd2;
a1_mos=Phaseleg_sicD.ad1;
a2_mos=Phaseleg_sicD.ad2;
t1_mos=Phaseleg_sicD.td1;
t2_mos=Phaseleg_sicD.td2;

%%
i_total=abs(i);
K_MOS=((ts_sicD-t1_mos)/(t2_mos-t1_mos)*(k2_mos-k1_mos)+k1_mos);
A_MOS=(ts_sicD-t1_mos)/(t2_mos-t1_mos)*(a2_mos-a1_mos)+a1_mos;

%%
i_sicD=i_total/N_mos;
Vfs=K_MOS*i_sicD+A_MOS;
end

function Pswitching=Pswitching_function_2L(S,i,System_para,Device_temp,Device_sw,Device_num,Rg)
Vc=System_para(3)/Device_num(3);
fs=System_para(2);
ia=i(1);
Pswitching=fs.*(Esw_2L(S(1,1),S(2,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg)...
    +Esw_2L(S(2,1),S(3,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg)...
    +Esw_2L(S(3,1),S(2,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg)...
    +Esw_2L(S(2,1),S(1,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg));
end



function  Esw=Esw_2L(S1,S2,ia,Vc,Device_temp,Device_sw,Device_num,Rg)
%% Leg device
Leg_Mosfet=Device_sw(1);
Leg_Diode=Device_sw(2);
%% Initial loss of leg device(s1 s4 d1 d4)
%% Phase Leg Mosfet Parameters

N_mos_leg = Device_num(1);
sicD_leg  = Device_num(2);
I_single_Mos_Leg=ia/N_mos_leg;
I_single_sicD_Leg=ia/sicD_leg;
ix=abs(I_single_Mos_Leg);


a11_on_mos_leg=Leg_Mosfet.a11_on;
a12_on_mos_leg=Leg_Mosfet.a12_on;
a13_on_mos_leg=Leg_Mosfet.a13_on;
a14_on_mos_leg=Leg_Mosfet.a14_on;
a11_off_mos_leg=Leg_Mosfet.a11_off;
a12_off_mos_leg=Leg_Mosfet.a12_off;
a13_off_mos_leg=Leg_Mosfet.a13_off;
a14_off_mos_leg=Leg_Mosfet.a14_off;
v1_mos_Leg=Leg_Mosfet.V1;

rg1_on=Leg_Mosfet.rg1_on;
rg2_on=Leg_Mosfet.rg2_on;
rg1_off=Leg_Mosfet.rg1_off;
rg2_off=Leg_Mosfet.rg2_off;
I_ref=Leg_Mosfet.I_ref;

E1_on_mos_leg=(a14_on_mos_leg*ix^3)+(a13_on_mos_leg*ix^2)+(a12_on_mos_leg*ix)+a11_on_mos_leg;
E1_off_mos_leg=(a14_off_mos_leg*ix^3)+(a13_off_mos_leg*ix^2)+(a12_off_mos_leg*ix)+a11_off_mos_leg;

Es_on_mos(1)=Vc*(E1_on_mos_leg/v1_mos_Leg);
Es_on_mos(2)=Vc*(E1_on_mos_leg/v1_mos_Leg);
Es_off_mos(1)=Vc*(E1_off_mos_leg/v1_mos_Leg);
Es_off_mos(2)=Vc*(E1_off_mos_leg/v1_mos_Leg);

E1_on_mos_leg_ref=(a14_on_mos_leg*I_ref^3)+(a13_on_mos_leg*I_ref^2)+(a12_on_mos_leg*I_ref)+a11_on_mos_leg;
E1_off_mos_leg_ref=(a14_off_mos_leg*I_ref^3)+(a13_off_mos_leg*I_ref^2)+(a12_off_mos_leg*I_ref)+a11_off_mos_leg;
E_ON_scaling=(rg2_on*Rg+rg1_on)/E1_on_mos_leg_ref;
E_OFF_scaling=(rg2_off*Rg+rg1_off)/E1_off_mos_leg_ref;

Es_on_mos(1)=Es_on_mos(1)*E_ON_scaling;
Es_on_mos(2)=Es_on_mos(2)*E_ON_scaling;
Es_off_mos(1)=Es_off_mos(1)*E_OFF_scaling;
Es_off_mos(2)=Es_off_mos(2)*E_OFF_scaling;



%% Phase Leg Sic Diode Parameters
Vnd_sicD=Leg_Diode.Vnd;
Ind_sicD=Leg_Diode.Ind;
td1_sicD=Leg_Diode.td1;
td2_sicD=Leg_Diode.td2;
Qrr_d_sicD=Leg_Diode.Qrr1;
%% Phase Leg Diode Loss Calculation
Ed_on_sicD(1)=0;
Ed_on_sicD(2)=0;

%Ed_off_sicD(1)=((Td_sic(1)-td1_sicD)/(td2_sicD-td1_sicD)*Qrr_d_sicD*Ind_sicD);
%Ed_off_sicD(2)=((Td_sic(2)-td1_sicD)/(td2_sicD-td1_sicD)*Qrr_d_sicD*Ind_sicD);
Ed_off_sicD(1)=Qrr_d_sicD*Vc;
Ed_off_sicD(2)=Qrr_d_sicD*Vc;
%%
%% Loss Calculation
%% IGBT loss
Es1_mos=Es_off_mos(1)*((S1==1)&(S2==0)&(ia>=0))+Es_on_mos(1)*((S1==0)&(S2==1)&(ia>=0));
Es2_mos=Es_off_mos(2)*((S1==0)&(S2==1)&(ia<=0))+Es_on_mos(2)*((S1==1)&(S2==0)&(ia<=0));

%% diode loss
%Ed1_sicD=-Ed_off_sicD(1)*Vc*ia/(Vnd_sicD*Ind_sicD)*((S1==1)&(S2==0)&(ia<0))-Ed_on_sicD(1)*Vc*ia/(Vnd_sicD*Ind_sicD)*((S1==0)&(S2==1)&(ia<0));
%Ed2_sicD=Ed_off_sicD(2)*Vc*ia/(Vnd_sicD*Ind_sicD)*((S1==0)&(S2==1)&(ia>0))+Ed_on_sicD(2)*Vc*ia/(Vnd_sicD*Ind_sicD)*((S1==1)&(S2==0)&(ia>0));
Ed1_sicD=-Ed_off_sicD(1)*ia/(Ind_sicD)*((S1==1)&(S2==0)&(ia<0))-Ed_on_sicD(1)*ia/(Ind_sicD)*((S1==0)&(S2==1)&(ia<0));
Ed2_sicD=Ed_off_sicD(2)*ia/(Ind_sicD)*((S1==0)&(S2==1)&(ia>0))+Ed_on_sicD(2)*ia/(Ind_sicD)*((S1==1)&(S2==0)&(ia>0));

%%
Esw =[Es1_mos*N_mos_leg , Ed1_sicD;
    Es2_mos*N_mos_leg , Ed2_sicD];
end
