function [T_device, Loss, Cond_Loss, Switch_Loss] =ThermalModel_2L(System_para,Device_sw,Device_num,Rg)
f1=System_para(1);
fs=System_para(2);
Vdc=System_para(3);
Vref=System_para(4);
P=System_para(5);
pf=System_para(6);
Rcs=System_para(7);
Rsa=System_para(8);
Tamb=System_para(9);
T_device=System_para(10);

Rjc=Rcs;
Rca=Rsa;
Rth=Rjc+Rca;

for i=1:1:20
    System_para=[f1,fs,Vdc,Vref,P,pf,Rcs,Rsa,Tamb,T_device];
    [Loss, Cond_Loss, Switch_Loss] =PowerLossFun_2L(System_para,Device_sw,Device_num,Rg);
    Increase=(Rth*sum(Loss))/2/Device_num(1);
    T_device_new=Increase+Tamb;
         if (T_device_new>150)
            disp('Non feasible Design');
         break;
         elseif ((T_device_new-T_device)<.05)
         break;
         end
    T_device=T_device_new;   
end
return;
end


