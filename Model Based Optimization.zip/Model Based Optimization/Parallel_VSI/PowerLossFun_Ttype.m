function [Loss, Cond_Loss, Switch_Loss] =PowerLossFun_Ttype(System_para,Device_sw,Device_num,Rg)
%% This is the loss calculation function, several assumptions have been made:
% Assume that the chip temperatures for same parallel switches are the same
% Assume that the parralleled chips have equal current sharing
%% initial system parameters
f1=System_para(1);
fs=System_para(2);
Vdc=System_para(3);
Vref=System_para(4);
P=System_para(5);
pf=System_para(6);
T_device=System_para(10);
%% Calculate system parameters
i=[0 0 0];  % three phase currents
%Vc=Vdc/2;   % commutation voltage of devices
if (pf>0)angle=acos(pf);
else angle=-acos(-pf);
end
Carrier=fs/f1;    % carrier ratio
N=floor(Carrier);
%% Device Initial
% Phase Leg:        LegMosfet  LegIGBT    LegDiode,
% Pahse Leg No.:    Ns1_MOS    Ns1_IGBT   Nd1_DIODE
%                   Ns2_MOS    Ns2_IGBT   Nd2_DIODE
%% Load Calculation p.f.
Power=P;            % active power
AP=Power/pf;        % apparent power
I=(2/3)*AP/Vref;    % magnitude of phase current
%% initial power matrix
Pcond=[0 0; 0 0; 0 0; 0 0];
Pconduction=[0 0; 0 0; 0 0; 0 0];
Pswitch=[0 0; 0 0; 0 0; 0 0];
PowerLoss1=0;
PowerLoss2=0;

%% intial tempurature as well as forward voltage
T_phaseleg_mos=[T_device T_device];
T_phaseleg_sicD=[T_device T_device];
T_clamping_mos=[T_device T_device];
T_clamping_siD=[T_device T_device];
Device_temp=[T_phaseleg_mos, T_phaseleg_sicD,T_clamping_mos,T_clamping_siD]; % Temperature:[s1 s4;d1 d4;s2 s3;d2 d3] 

    %% calculate the power loss in one switching cycle
for m=0:1:N
    %% three phase current calculation
    theta=m*2*pi/N;
    i(1)=I*cos(theta-angle);
    i(2)=I*cos(theta-angle-2*pi/3);
    i(3)=I*cos(theta-angle+2*pi/3);
    %% calcuation Switching function and time
    [S, T]=DPWM_3L(Vref,theta,Vdc,fs);
    
    %% Conduction Loss Power Calculation
     Pconduction=Pconduction_function_Ttype(S,T,i,Device_temp,Device_sw,Device_num,System_para);
     %% S1 and D1
    Pc_mos_s1(m+1)=Pconduction(1,1);
    Pc_sic_d1(m+1)=Pconduction(1,2);
     %% S2 and D2
    Pc_mos_s2(m+1)=Pconduction(2,1);
    Pc_sic_d2(m+1)=Pconduction(2,2);
     %% S3 and D3
    Pc_mos_s3(m+1)=Pconduction(3,1);
    Pc_sic_d3(m+1)=Pconduction(3,2);
     %% S4 and D4
    Pc_mos_s4(m+1)=Pconduction(4,1);
    Pc_sic_d4(m+1)=Pconduction(4,2);  
    %% swtiching loss power Calculation
    Pswitching=Pswitching_function_Ttype(S,i,System_para,Device_temp,Device_sw,Device_num,Rg);
     %% S1 and D1
    Psw_mos_s1(m+1)=Pswitching(1,1);
    Psw_sic_d1(m+1)=Pswitching(1,2);
     %% S2 and D2
    Psw_mos_s2(m+1)=Pswitching(2,1);
    Psw_sic_d2(m+1)=Pswitching(2,2);    
     %% S3 and D3
    Psw_mos_s3(m+1)=Pswitching(3,1);
    Psw_sic_d3(m+1)=Pswitching(3,2);
     %% S4 and D4
    Psw_mos_s4(m+1)=Pswitching(4,1);
    Psw_sic_d4(m+1)=Pswitching(4,2);

    %% total power loss
     %% S1 and D1    
    Psum_mos_s1(m+1)=Psw_mos_s1(m+1)+Pc_mos_s1(m+1);
    Psum_sic_d1(m+1)=Psw_sic_d1(m+1)+Pc_sic_d1(m+1);
     %% S2 and D2   
    Psum_mos_s2(m+1)=Psw_mos_s2(m+1)+Pc_mos_s2(m+1);
    Psum_sic_d2(m+1)=Psw_sic_d2(m+1)+Pc_sic_d2(m+1);
     %% S3 and D3
    Psum_mos_s3(m+1)=Psw_mos_s3(m+1)+Pc_mos_s3(m+1);
    Psum_sic_d3(m+1)=Psw_sic_d3(m+1)+Pc_sic_d3(m+1);
     %% S4 and D4
    Psum_mos_s4(m+1)=Psw_mos_s4(m+1)+Pc_mos_s4(m+1);
    Psum_sic_d4(m+1)=Psw_sic_d4(m+1)+Pc_sic_d4(m+1);

    %% Reset temp parameters
    Pcond=[0 0; 0 0; 0 0; 0 0];
    Pconduction=[0 0; 0 0; 0 0; 0 0];
end
%% Conculsion of Power Loss
TotalConductionPowerLoss=1./fs.*f1*[sum(Pc_mos_s1) sum(Pc_sic_d1) sum(Pc_mos_s2) sum(Pc_sic_d2) sum(Pc_mos_s3) sum(Pc_sic_d3) sum(Pc_mos_s4) sum(Pc_sic_d4) ];
TotalSwitchingPowerLoss=1./fs.*f1*[sum(Psw_mos_s1) sum(Psw_sic_d1) sum(Psw_mos_s2) sum(Psw_sic_d2) sum(Psw_mos_s3) sum(Psw_sic_d3) sum(Psw_mos_s4) sum(Psw_sic_d4)];
TotalPowerLoss=TotalSwitchingPowerLoss+TotalConductionPowerLoss;
%%
Loss=sum(TotalPowerLoss);
Cond_Loss=sum(TotalConductionPowerLoss);
Switch_Loss=sum(TotalSwitchingPowerLoss);
end
 
function Pconduction=Pconduction_function_Ttype(S,T,i,Device_temp,Device_sw,Device_num,System_para)
%% This function calculate the conduction loss of single discrete switch/diode the switch notations follow the convetional notation

fs=System_para(2);
Pconduction=[0,0;     % Conduction loss matrix [s1 d1; s2 d2; s3 d3; s4 d4]
             0,0;
             0,0;
             0,0];
N_leg_mos=Device_num(1);
N_leg_sicD=Device_num(2);
N_clamp_mos=Device_num(3);
N_clamp_sicD=Device_num(4);
for t=1:1:3
        Sa=S(t,1);
        %accodrding to different conditions, we can calculate the current
        %loop and conduction loss based on current in each phase and
        %switching function.
        Pcond=T(t).*fs.*CondPowerLoss_Ttype(i,Sa,Device_temp,Device_sw,Device_num);
        Pconduction=Pcond+Pconduction;
end

    %% S1 and D1
    Pconduction(1,1)=Pconduction(1,1)*N_leg_mos;
    Pconduction(1,2)=Pconduction(1,2)*N_leg_sicD;
    %% S2 and D2
    Pconduction(2,1)=Pconduction(2,1)*N_clamp_mos;
    Pconduction(2,2)=Pconduction(2,2)*N_clamp_sicD;
    %% S3 and D3
    Pconduction(3,1)=Pconduction(3,1)*N_clamp_mos;
    Pconduction(3,2)=Pconduction(3,2)*N_clamp_sicD;
    %% S4 and D4
    Pconduction(4,1)=Pconduction(4,1)*N_leg_mos;
    Pconduction(4,2)=Pconduction(4,2)*N_leg_sicD;    
end



function  Pcond=CondPowerLoss_Ttype(i,Sa,Device_temp,Device_sw,Device_num)
%% i calacution
ia=i(1);

%% Current Sharing and Forward Voltage
[Vs_mos_leg,is_mos_leg]=V_eq_s_Ttype(ia,Device_temp(1),Device_sw(1),Device_num(1));
[Vd_Diode_leg,id_sicD_leg]=V_eq_d_Ttype(ia,Device_temp(3),Device_sw(2),Device_num(2));
[Vs_mos_clamp,is_mos_clamp]=V_eq_s_Ttype(ia,Device_temp(5),Device_sw(3),Device_num(3));
[Vd_Diode_clamp,id_sicD_clamp]=V_eq_d_Ttype(ia,Device_temp(7),Device_sw(4),Device_num(4));

%% Conduction Loss
Pcond_s1=Device_num(5)*(Vs_mos_leg*is_mos_leg)*((ia>=0)&(Sa==1));
Pcond_s2=Device_num(6)*(Vs_mos_clamp*is_mos_clamp)*((ia>=0)&(Sa==0));
Pcond_s3=Device_num(6)*(Vs_mos_clamp*is_mos_clamp)*((ia<0)&(Sa==0));
Pcond_s4=Device_num(5)*(Vs_mos_leg*is_mos_leg)*((ia<0)&(Sa==-1));


Pcond_d1=Device_num(5)*(Vd_Diode_leg*id_sicD_leg)*((ia<0)&(Sa==1));
Pcond_d2=Device_num(6)*(Vd_Diode_clamp*id_sicD_clamp)*((ia<0)&(Sa==0));
Pcond_d3=Device_num(6)*(Vd_Diode_clamp*id_sicD_clamp)*((ia>=0)&(Sa==0));
Pcond_d4=Device_num(5)*(Vd_Diode_leg*id_sicD_leg)*((ia>=0)&(Sa==-1));


Pcond=[Pcond_s1  Pcond_d1;Pcond_s2  Pcond_d2;Pcond_s3  Pcond_d3;Pcond_s4  Pcond_d4];
end

function [Vs_mos,is_mos]=V_eq_s_Ttype(i,Device_temp,Device_sw,Device_num)
%% This fuction calculate the forward voltage of one single switch
% Funtion input is the conduction current and device parameters/temperature
Device_mos=Device_sw;
%%
ts_mos=Device_temp;
%%
N_mos=Device_num;
%% Mosfet tempreture dependent parameters
k1_mos=Device_mos.ks1;
k2_mos=Device_mos.ks2;
a1_mos=Device_mos.as1;
a2_mos=Device_mos.as2;
t1_mos=Device_mos.ts1;
t2_mos=Device_mos.ts2;
%%
i_total=abs(i);
is_mos=i_total/N_mos;
K_MOS=((ts_mos-t1_mos)*(k2_mos-k1_mos)/(t2_mos-t1_mos)+k1_mos);
A_MOS=(ts_mos-t1_mos)/(t2_mos-t1_mos)*(a2_mos-a1_mos)+a1_mos;
%%
Vs_mos=K_MOS*is_mos+A_MOS;

end


function [Vd_Diode,id_sicD]=V_eq_d_Ttype(i,Device_temp,Device_sw,Device_num)
%% This fuction calculate the forward voltage of one single diode
% Funtion input is the conduction current and device parameters/temperature
Device_sicD=Device_sw;
%%
ts_sicD=Device_temp;
%%
N_sicD=Device_num;
%% Mosfet tempreture dependent parameters
k1_sicD=Device_sicD.kd1;
k2_sicD=Device_sicD.kd2;
a1_sicD=Device_sicD.ad1;
a2_sicD=Device_sicD.ad2;
t1_sicD=Device_sicD.td1;
t2_sicD=Device_sicD.td2;
%%
i_total=abs(i);
id_sicD=i_total/N_sicD;
K_SICD=((ts_sicD-t1_sicD)/(t2_sicD-t1_sicD)*(k2_sicD-k1_sicD)+k1_sicD);
A_SICD=(ts_sicD-t1_sicD)/(t2_sicD-t1_sicD)*(a2_sicD-a1_sicD)+a1_sicD;
%%
Vd_Diode=K_SICD*id_sicD+A_SICD;
end



function Pswitching=Pswitching_function_Ttype(S,i,System_para,Device_temp,Device_sw,Device_num,Rg)
%% Switching Loss Calculation Function
Vc=System_para(3)/2;
fs=System_para(2);
ia=i(1);
Pswitching=fs.*(Esw_Ttype(S(1,1),S(2,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg)...
    +Esw_Ttype(S(2,1),S(3,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg)...
    +Esw_Ttype(S(3,1),S(2,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg)...
    +Esw_Ttype(S(2,1),S(1,1),ia,Vc,Device_temp,Device_sw,Device_num,Rg));
end



function  Esw=Esw_Ttype(S1,S2,ia,Vc,Device_temp,Device_sw,Device_num,Rg)
%% Device
Leg_Mosfet=Device_sw(1);
Leg_Diode=Device_sw(2);
Clamp_Mosfet=Device_sw(3);
Clamp_Diode=Device_sw(4);

%% Initial loss of leg device(s1 s4 d1 d4)
%% Phase Leg Mosfet Parameters
%Vn_mos_leg=Leg_Mosfet.Vns;
%In_mos_leg=Leg_Mosfet.Ins;
%E1_on_mos_leg=Leg_Mosfet.E1_on;
%E2_on_mos_leg=Leg_Mosfet.E2_on;
%E1_off_mos_leg=Leg_Mosfet.E1_off;
%E2_off_mos_leg=Leg_Mosfet.E2_off;
%ts1_mos_leg=Leg_Mosfet.ts1;
%ts2_mos_leg=Leg_Mosfet.ts2;

N_mos_leg = Device_num(1);
sicD_leg  = Device_num(2);
N_mos_clamp = Device_num(3);
sicD_clamp = Device_num(4);
I_single_Mos_Leg=ia/N_mos_leg;
I_single_sicD_Leg=ia/sicD_leg;
I_single_Mos_clamp=ia/N_mos_clamp;
I_single_sicD_clamp=ia/sicD_clamp;
ix=abs(I_single_Mos_Leg);
iy=abs(I_single_Mos_clamp);


a11_on_mos_leg=Leg_Mosfet.a11_on;
a12_on_mos_leg=Leg_Mosfet.a12_on;
a13_on_mos_leg=Leg_Mosfet.a13_on;
a14_on_mos_leg=Leg_Mosfet.a14_on;
a11_off_mos_leg=Leg_Mosfet.a11_off;
a12_off_mos_leg=Leg_Mosfet.a12_off;
a13_off_mos_leg=Leg_Mosfet.a13_off;
a14_off_mos_leg=Leg_Mosfet.a14_off;
v1_mos_Leg=Leg_Mosfet.V1;


rg1_on_leg=Leg_Mosfet.rg1_on;
rg2_on_leg=Leg_Mosfet.rg2_on;
rg1_off_leg=Leg_Mosfet.rg1_off;
rg2_off_leg=Leg_Mosfet.rg2_off;
I_ref_leg=Leg_Mosfet.I_ref;


E1_on_mos_leg=(a14_on_mos_leg*ix^3)+(a13_on_mos_leg*ix^2)+(a12_on_mos_leg*ix)+a11_on_mos_leg;
E1_off_mos_leg=(a14_off_mos_leg*ix^3)+(a13_off_mos_leg*ix^2)+(a12_off_mos_leg*ix)+a11_off_mos_leg;


Es_on_mos(1)=Vc*(E1_on_mos_leg/v1_mos_Leg);
Es_on_mos(4)=Vc*(E1_on_mos_leg/v1_mos_Leg);
Es_off_mos(1)=Vc*(E1_off_mos_leg/v1_mos_Leg);
Es_off_mos(4)=Vc*(E1_off_mos_leg/v1_mos_Leg);


E1_on_mos_leg_ref=(a14_on_mos_leg*I_ref_leg^3)+(a13_on_mos_leg*I_ref_leg^2)+(a12_on_mos_leg*I_ref_leg)+a11_on_mos_leg;
E1_off_mos_leg_ref=(a14_off_mos_leg*I_ref_leg^3)+(a13_off_mos_leg*I_ref_leg^2)+(a12_off_mos_leg*I_ref_leg)+a11_off_mos_leg;
E_ON_scaling_leg=(rg2_on_leg*Rg+rg1_on_leg)/E1_on_mos_leg_ref;
E_OFF_scaling_leg=(rg2_off_leg*Rg+rg1_off_leg)/E1_off_mos_leg_ref;

Es_on_mos(1)=Es_on_mos(1)*E_ON_scaling_leg;
Es_on_mos(4)=Es_on_mos(4)*E_ON_scaling_leg;
Es_off_mos(1)=Es_off_mos(1)*E_OFF_scaling_leg;
Es_off_mos(4)=Es_off_mos(4)*E_OFF_scaling_leg;


a11_on_mos_clamp=Clamp_Mosfet.a11_on;
a12_on_mos_clamp=Clamp_Mosfet.a12_on;
a13_on_mos_clamp=Clamp_Mosfet.a13_on;
a14_on_mos_clamp=Clamp_Mosfet.a14_on;
a11_off_mos_clamp=Clamp_Mosfet.a11_off;
a12_off_mos_clamp=Clamp_Mosfet.a12_off;
a13_off_mos_clamp=Clamp_Mosfet.a13_off;
a14_off_mos_clamp=Clamp_Mosfet.a14_off;
v1_mos_clamp=Clamp_Mosfet.V1;

rg1_on_clamp=Clamp_Mosfet.rg1_on;
rg2_on_clamp=Clamp_Mosfet.rg2_on;
rg1_off_clamp=Clamp_Mosfet.rg1_off;
rg2_off_clamp=Clamp_Mosfet.rg2_off;
I_ref_clamp=Clamp_Mosfet.I_ref;


E1_on_mos_clamp=(a14_on_mos_clamp*iy^3)+(a13_on_mos_clamp*iy^2)+(a12_on_mos_clamp*iy)+a11_on_mos_clamp;
E1_off_mos_clamp=(a14_off_mos_clamp*iy^3)+(a13_off_mos_clamp*iy^2)+(a12_off_mos_clamp*iy)+a11_off_mos_clamp;


Es_on_mos(2)=Vc*(E1_on_mos_clamp/v1_mos_clamp);
Es_on_mos(3)=Vc*(E1_on_mos_clamp/v1_mos_clamp);
Es_off_mos(2)=Vc*(E1_off_mos_clamp/v1_mos_clamp);
Es_off_mos(3)=Vc*(E1_off_mos_clamp/v1_mos_clamp);

E1_on_mos_clamp_ref=(a14_on_mos_clamp*I_ref_clamp^3)+(a13_on_mos_clamp*I_ref_clamp^2)+(a12_on_mos_clamp*I_ref_clamp)+a11_on_mos_clamp;
E1_off_mos_clamp_ref=(a14_off_mos_clamp*I_ref_clamp^3)+(a13_off_mos_clamp*I_ref_clamp^2)+(a12_off_mos_clamp*I_ref_clamp)+a11_off_mos_clamp;
E_ON_scaling_clamp=(rg2_on_clamp*Rg+rg1_on_clamp)/E1_on_mos_clamp_ref;
E_OFF_scaling_clamp=(rg2_off_clamp*Rg+rg1_off_clamp)/E1_off_mos_clamp_ref;

Es_on_mos(2)=Es_on_mos(2)*E_ON_scaling_clamp;
Es_on_mos(3)=Es_on_mos(3)*E_ON_scaling_clamp;
Es_off_mos(2)=Es_off_mos(2)*E_OFF_scaling_clamp;
Es_off_mos(3)=Es_off_mos(3)*E_OFF_scaling_clamp;


%{
%% Phase Leg Mos Switching Loss Calculation
Es_on_mos(1)=((Ts_mos(1)-ts1_mos_leg)/(ts2_mos_leg-ts1_mos_leg)*(E2_on_mos_leg-E1_on_mos_leg)+E1_on_mos_leg);
Es_on_mos(4)=((Ts_mos(4)-ts1_mos_leg)/(ts2_mos_leg-ts1_mos_leg)*(E2_on_mos_leg-E1_on_mos_leg)+E1_on_mos_leg);
Es_off_mos(1)=((Ts_mos(1)-ts1_mos_leg)/(ts2_mos_leg-ts1_mos_leg)*(E2_off_mos_leg-E1_off_mos_leg)+E1_off_mos_leg);
Es_off_mos(4)=((Ts_mos(4)-ts1_mos_leg)/(ts2_mos_leg-ts1_mos_leg)*(E2_off_mos_leg-E1_off_mos_leg)+E1_off_mos_leg);
%}

%% Phase Leg Sic Diode Parameters
Vnd_sicD_leg=Leg_Diode.Vnd;
Ind_sicD_leg=Leg_Diode.Ind;
td1_sicD_leg=Leg_Diode.td1;
td2_sicD_leg=Leg_Diode.td2;
Qrr_d_sicD_leg=Leg_Diode.Qrr1;
%% Phase Leg Diode Loss Calculation
Ed_on_sicD(1)=0;
Ed_on_sicD(4)=0;
%Ed_off_sicD(1)=((Td_sic(1)-td1_sicD_leg)/(td2_sicD_leg-td1_sicD_leg)*Qrr_d_sicD_leg*Vnd_sicD_leg);
%Ed_off_sicD(4)=((Td_sic(4)-td1_sicD_leg)/(td2_sicD_leg-td1_sicD_leg)*Qrr_d_sicD_leg*Vnd_sicD_leg);
Ed_off_sicD(1)=(Qrr_d_sicD_leg*Vc);
Ed_off_sicD(4)=(Qrr_d_sicD_leg*Vc);
%% Clamping device calculation
%% Initial loss of clamping device(s2 s3 d2 d3)
%% Clamping Mosfet Parameters
%%Vn_mos_clamp=Clamp_Mosfet.Vns;
%%In_mos_clamp=Clamp_Mosfet.Ins;
%%E1_on_mos_clamp=Clamp_Mosfet.E1_on;
%%E2_on_mos_clamp=Clamp_Mosfet.E2_on;
%%E1_off_mos_clamp=Clamp_Mosfet.E1_off;
%%E2_off_mos_clamp=Clamp_Mosfet.E2_off;
%%ts1_mos_clamp=Clamp_Mosfet.ts1;
%%ts2_mos_clamp=Clamp_Mosfet.ts2;
%% Clamping Leg Switching Loss Calculation
%%Es_on_mos(2)=((Ts_mos(2)-ts1_mos_clamp)/(ts2_mos_clamp-ts1_mos_clamp)*(E2_on_mos_clamp-E1_on_mos_clamp)+E1_on_mos_clamp);
%%Es_on_mos(3)=((Ts_mos(3)-ts1_mos_clamp)/(ts2_mos_clamp-ts1_mos_clamp)*(E2_on_mos_clamp-E1_on_mos_clamp)+E1_on_mos_clamp);
%%Es_off_mos(2)=((Ts_mos(2)-ts1_mos_clamp)/(ts2_mos_clamp-ts1_mos_clamp)*(E2_off_mos_clamp-E1_off_mos_clamp)+E1_off_mos_clamp);
%%Es_off_mos(3)=((Ts_mos(3)-ts1_mos_clamp)/(ts2_mos_clamp-ts1_mos_clamp)*(E2_off_mos_clamp-E1_off_mos_clamp)+E1_off_mos_clamp);

%% Clamping Leg SiC Diode Parameters
Vnd_sicD_clamp=Clamp_Diode.Vnd;
Ind_sicD_clamp=Clamp_Diode.Ind;
td1_sicD_clamp=Clamp_Diode.td1;
td2_sicD_clamp=Clamp_Diode.td2;
Qrr_d_sicD_clamp=Clamp_Diode.Qrr1;
%% Clamping Leg Diode Loss Calculation
Ed_on_sicD(2)=0;
Ed_on_sicD(3)=0;
%Ed_off_sicD(2)=((Td_sic(2)-td1_sicD_clamp)/(td2_sicD_clamp-td1_sicD_clamp)*Qrr_d_sicD_clamp*Vnd_sicD_clamp);
%Ed_off_sicD(3)=((Td_sic(3)-td1_sicD_clamp)/(td2_sicD_clamp-td1_sicD_clamp)*Qrr_d_sicD_clamp*Vnd_sicD_clamp);
Ed_off_sicD(2)=(Qrr_d_sicD_clamp*Vc);
Ed_off_sicD(3)=(Qrr_d_sicD_clamp*Vc);

%% Loss Calculation
%% IGBT loss
Es1_mos=Es_off_mos(1)*((S1==1)&(S2==0)&(ia>=0))+Es_on_mos(1)*((S1==0)&(S2==1)&(ia>=0));
Es4_mos=Es_off_mos(4)*((S1==-1)&(S2==0)&(ia<0))+Es_on_mos(4)*((S1==0)&(S2==-1)&(ia<0));

Es2_mos=Es_on_mos(2)*((S1==-1)&(S2==0)&(ia>=0))+Es_off_mos(2)*((S1==0)&(S2==-1)&(ia>=0));
Es3_mos=Es_on_mos(3)*((S1==1)&(S2==0)&(ia<0))+Es_off_mos(3)*((S1==0)&(S2==1)&(ia<0));

%% diode loss
%Ed1_sicD=-Ed_off_sicD(1)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==1)&(S2==0)&(ia<0))-Ed_on_sicD(1)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==1)&(S2==0)&(ia<0));
%Ed4_sicD=Ed_off_sicD(4)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==1)&(S2==0)&(ia>=0))+Ed_on_sicD(4)*Vc*ia/(Vnd_sicD_leg*Ind_sicD_leg)*((S1==0)&(S2==-1)&(ia>0));

%Ed2_sicD=-Ed_on_sicD(2)*Vc*ia/(Vnd_sicD_clamp*Ind_sicD_clamp)*((S1==-1)&(S2==0)&(ia<0))-Ed_off_sicD(2)*Vc*ia/(Vnd_sicD_clamp*Ind_sicD_clamp)*((S1==0)&(S2==-1)&(ia<0));
%Ed3_sicD=Ed_on_sicD(3)*Vc*ia/(Vnd_sicD_clamp*Ind_sicD_clamp)*((S1==1)&(S2==0)&(ia>=0))+Ed_off_sicD(3)*Vc*ia/(Vnd_sicD_clamp*Ind_sicD_clamp)*((S1==0)&(S2==1)&(ia>=0));
Ed1_sicD=-Ed_off_sicD(1)*ia/(Ind_sicD_leg)*((S1==1)&(S2==0)&(ia<0))-Ed_on_sicD(1)*ia/(Ind_sicD_leg)*((S1==0)&(S2==1)&(ia<0));
Ed4_sicD=Ed_off_sicD(4)*ia/(Ind_sicD_leg)*((S1==-1)&(S2==0)&(ia>=0))+Ed_on_sicD(4)*ia/(Ind_sicD_leg)*((S1==0)&(S2==-1)&(ia>0));

Ed2_sicD=-Ed_on_sicD(2)*ia/(Ind_sicD_clamp)*((S1==-1)&(S2==0)&(ia<0))-Ed_off_sicD(2)*ia/(Ind_sicD_clamp)*((S1==0)&(S2==-1)&(ia<0));
Ed3_sicD=Ed_on_sicD(3)*ia/(Ind_sicD_clamp)*((S1==1)&(S2==0)&(ia>=0))+Ed_off_sicD(3)*ia/(Ind_sicD_clamp)*((S1==0)&(S2==1)&(ia>=0));

%%
Esw =[Es1_mos*N_mos_leg, Ed1_sicD;
      Es2_mos*N_mos_clamp, Ed2_sicD;
      Es3_mos*N_mos_clamp, Ed3_sicD;
      Es4_mos*N_mos_leg, Ed4_sicD];
end


