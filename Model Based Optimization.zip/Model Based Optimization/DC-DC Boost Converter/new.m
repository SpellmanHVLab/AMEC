clc
clear all
close all

% Mosfet1:  MicorSemi MSC035SMA170B 1700V 68/48A SiC MOSFET 35mohm
% Mosfet2:  CREE C2M0080170P 1700V 40/27a SiC MOSFET        80mohm
% Mosfet3:  C3M0065090J 900V 35A SiC MOSFET                 65mohm
% Mosfet4:  CREE C2M0045170P 1700V 72/48A SiC MOSFET        45mohm
% Mosfet5:  CREE C2M0045170D 1700V 72/48A SiC MOSFET        45mohm
% Mosfet6:  CREE C3M0016120K 1200V 115/85A SiC MOSFET       16mohm
% Mosfet7:  CREE C3M0021120K 1200V 100/74A SiC MOSFET       21mohm
% Mosfet8:  ON-SEMI NTBG020N120SC1 1200V 98 SiC MOSFET      20mohm
% Mosfet9:  CREE C2M0025120D 1200V 90/60A SiC MOSFET        25mohm
% Mosfetx:  USiC UF3SC120009K4S 1200V 120A SiC MOSFET       8.6mohm

% Diode1:   Infineon IDWD40G120C5 1200V/40A Schottcky Diode
% Diode2;   Infineon IDWD30G120C5 1200V/30A Schottcky Diode
% Diode3:   GeneSiC GC50MPS12-247 1200V/50A Schottcky diode
% Diode4:   ON Semi FFSH50120A    1200V/50A Schottcky diode
% Diode5:   CREE C4D40120D        1200V/54A Schottcky diode

Number_Mosfet=2;
Junction=25;
Number_Diode=2;
Type_Diode=3;

Type_Mosfet=6;
[DCDC_16_mohm_25]=Efficiency_cal_main(Number_Mosfet,Type_Mosfet,Number_Diode,Type_Diode,Junction);
plot(DCDC_16_mohm_25(2,:)','Linewidth',4,'color','green');hold on;
%Junction=125;
%[DCDC_16_mohm_125]=Efficiency_cal_main(Number_Mosfet,Type_Mosfet,Number_Diode,Type_Diode,Junction);
%plot(DCDC_16_mohm_125(2,:)','Linewidth',4,'color','green');hold on;


set(gca,'FontSize',8,'FontName','Times New Roman');
set(gca,'FontSize',8,'FontName','Times New Roman');
legend('2 8.6m USiC devices','2 16m CREE devices','2 21m CREE devices');
grid on;
xlabel('Frequency (kHz)','Fontsize',16,'FontName','Times New Roman','fontweight','bold');
set(gca,'XMinorGrid','on');set(gca,'YMinorGrid','on');
title('Analysis of DC-DC using Different Devices at 125^o','fontsize',12,'FontName','Times New Roman');
ylabel('Efficiency (%)','fontsize',16,'FontName','Times New Roman','fontweight','bold');
%set(gca,'FontSize',16,'FontName','Times New Roman');
set(gca,'XTick',[1:1:10],'fontweight','bold');
%set(gca,'xtickLabel',{'10','20','30','40','50','60','70','80','90','100'});
set(gca,'xtickLabel',{'20','40','60','80','100'});



%{



%save('Single_DC_DC_Predictions_20mohm','Efficiency');
%save('Single_DC_DC_Predictions_25mohm','Efficiency');
%Efficiency_cal_main
%save('Interleaved_DC_DC_Predictions','Efficiency');
 
x=load('Single_DC_DC_Predictions');
y=load('Interleaved_DC_DC_Predictions');

figure(1)
for i=1:1:3
plot(x.Efficiency(2*i,:)','Linewidth',4,'color','red');hold on;
plot(y.Efficiency(i,:)','Linewidth',4,'color','blue');hold on;
end
%}