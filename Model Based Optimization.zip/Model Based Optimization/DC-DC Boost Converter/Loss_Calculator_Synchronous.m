function [Loss_Total, Conduction_Loss, Switch_Loss] = Loss_Calculator_Synchronous(System_para,Device_temp,Device_sw,Device_num,Rg)    
fs=System_para(1);
I_cond_major=System_para(2)/System_para(3);
Vout=System_para(4);
D=System_para(5);
ESR_L=System_para(6);
ESR_C=System_para(7);


[P_cond_major] = D.*CondPowerLoss_2L(I_cond_major,Device_temp(1),Device_sw(1),Device_num(1));      %Conduction Losses of Major Transistor%
[P_cond_minor] = (1-D).*CondPowerLoss_2L(I_cond_major,Device_temp(2),Device_sw(2),Device_num(2));  %Conduction Losses of Minor Transistor%
[E_sw_major]   = D.*fs*Esw_2L_new(I_cond_major,Vout,Device_sw(1),Device_num(1),Rg);                %ON and OFF Energy Determination of Major Transistor%
[E_sw_minor]   = (1-D).*fs*Esw_2L_new(I_cond_major,Vout,Device_sw(2),Device_num(2),Rg);            %ON and OFF Energy Determination of Major Transistor%

P_ESR_L=I_cond_major^2*ESR_L;
P_ESR_C=0;

Conduction_Loss=P_cond_major(1)+P_cond_minor(1)+P_ESR_L+P_ESR_C;
Switch_Loss=E_sw_major(1)+E_sw_major(2)+E_sw_minor(1)+E_sw_minor(2);
Loss_Total=Conduction_Loss+Switch_Loss;


function  Esw=Esw_2L_new(ia,Vc,Device_sw,Device_num,Rg)
%% Leg device
Leg_Mosfet=Device_sw;
%% Initial loss of leg device(s1 s4 d1 d4)
%% Phase Leg Mosfet Parameters

N_mos_leg = Device_num;
I_single_Mos_Leg=ia/N_mos_leg;
ix=abs(I_single_Mos_Leg);
Vc=abs(Vc);

a11_on_mos_leg=Leg_Mosfet.a11_on;
a12_on_mos_leg=Leg_Mosfet.a12_on;
a13_on_mos_leg=Leg_Mosfet.a13_on;
a14_on_mos_leg=Leg_Mosfet.a14_on;
a11_off_mos_leg=Leg_Mosfet.a11_off;
a12_off_mos_leg=Leg_Mosfet.a12_off;
a13_off_mos_leg=Leg_Mosfet.a13_off;
a14_off_mos_leg=Leg_Mosfet.a14_off;
v1_mos_Leg=Leg_Mosfet.V1;

rg1_on=Leg_Mosfet.rg1_on;
rg2_on=Leg_Mosfet.rg2_on;
rg1_off=Leg_Mosfet.rg1_off;
rg2_off=Leg_Mosfet.rg2_off;
I_ref=Leg_Mosfet.I_ref;

E1_on_mos_leg=(a14_on_mos_leg*ix^3)+(a13_on_mos_leg*ix^2)+(a12_on_mos_leg*ix)+a11_on_mos_leg;
E1_off_mos_leg=(a14_off_mos_leg*ix^3)+(a13_off_mos_leg*ix^2)+(a12_off_mos_leg*ix)+a11_off_mos_leg;

Es_on_mos=Vc*(E1_on_mos_leg/v1_mos_Leg);
Es_off_mos=Vc*(E1_off_mos_leg/v1_mos_Leg);

E1_on_mos_leg_ref=(a14_on_mos_leg*I_ref^3)+(a13_on_mos_leg*I_ref^2)+(a12_on_mos_leg*I_ref)+a11_on_mos_leg;
E1_off_mos_leg_ref=(a14_off_mos_leg*I_ref^3)+(a13_off_mos_leg*I_ref^2)+(a12_off_mos_leg*I_ref)+a11_off_mos_leg;
E_ON_scaling=(rg2_on*Rg+rg1_on)*Vc/v1_mos_Leg/E1_on_mos_leg_ref;
E_OFF_scaling=(rg2_off*Rg+rg1_off)*Vc/v1_mos_Leg/E1_off_mos_leg_ref;

Es_on_mos=Es_on_mos*E_ON_scaling;
Es_off_mos=Es_off_mos*E_OFF_scaling;

Qrr=Leg_Mosfet.Qrr1;
Es_qrr_mos=Qrr*Vc*ix./I_ref;

Es_on_mos(isnan(Es_on_mos))=0;
Es_off_mos(isnan(Es_off_mos))=0;
Es_qrr_mos(isnan(Es_qrr_mos))=0;

Esw =[Es_on_mos*N_mos_leg;Es_off_mos*N_mos_leg;Es_qrr_mos*N_mos_leg];
end
function  Pcond=CondPowerLoss_2L(ITx_n,Device_temp,Device_sw,Device_num)
%%

%% i calacution
ia=ITx_n;
%% Phase Leg Current Sharing and Forward Voltage
[Vs_mos,is_mos]=V_eq_2L(ia,Device_temp,Device_sw,Device_num);
[Vs_mos_reverse,is_mos_reverse]=V_eq_2L_3rd_quadrant(ia,Device_temp,Device_sw,Device_num);
Pcond_forward=Device_num*Vs_mos*is_mos;
Pcond_backward=Device_num*Vs_mos_reverse*is_mos_reverse;
Pcond=[Pcond_forward,Pcond_backward];
end
function [Vfs,i_mos]=V_eq_2L(i,Device_temp,Device_sw,Device_num)
%% tempreture dependent parameters
Phaseleg_mos=Device_sw;
%%
ts_mos=Device_temp;
%%
N_mos=Device_num;
%% Mosfet tempreture dependent parameters
k1_mos=Phaseleg_mos.ks1;
k2_mos=Phaseleg_mos.ks2;
a1_mos=Phaseleg_mos.as1;
a2_mos=Phaseleg_mos.as2;
t1_mos=Phaseleg_mos.ts1;
t2_mos=Phaseleg_mos.ts2;
%%
i_total=abs(i);
i_mos=i_total/N_mos;
K_MOS=((ts_mos-t1_mos)/(t2_mos-t1_mos)*(k2_mos-k1_mos)+k1_mos);
A_MOS=(ts_mos-t1_mos)/(t2_mos-t1_mos)*(a2_mos-a1_mos)+a1_mos;
%%
Vfs=K_MOS*i_mos+A_MOS;
end
function [Vs_mos_reverse,is_mos_reverse]=V_eq_2L_3rd_quadrant(i,Device_temp,Device_sw,Device_num)
%% tempreture dependent parameters
Phaseleg_mos=Device_sw;
%%
ts_mos=Device_temp;
%%
N_mos=Device_num;
%% Mosfet tempreture dependent parameters
k1_mos=Phaseleg_mos.kd1;
k2_mos=Phaseleg_mos.kd2;
a1_mos=Phaseleg_mos.ad1;
a2_mos=Phaseleg_mos.ad2;
t1_mos=Phaseleg_mos.td1;
t2_mos=Phaseleg_mos.td2;
%%
i_total=abs(i);
is_mos_reverse=i_total/N_mos;
K_MOS=((ts_mos-t1_mos)/(t2_mos-t1_mos)*(k2_mos-k1_mos)+k1_mos);
A_MOS=(ts_mos-t1_mos)/(t2_mos-t1_mos)*(a2_mos-a1_mos)+a1_mos;
%%
Vs_mos_reverse=K_MOS*is_mos_reverse+A_MOS;
end
end