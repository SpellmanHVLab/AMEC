function Efficiency = Efficiency_cal_main(Number_Mosfet,Type_Mosfet,Number_Diode,Type_Diode,Junction)
%*********************** Efficiency & Loss calculation **************************
%clear all;
%close all;
%clc;
%% This is the program for Ttype efficiency calculation
%% Entering Device type
run('Device_initial.m');
load('Mosfetdata.mat');   % Loading discrete SiC Mosfet database
load('Diodedata.mat');    % Loading diode database
%% Devices:
%% Mosfet

%% Topology & Device Combination Selection
disp('************************** Loss Evaluation ***************************');
disp('************************ Topology Selection **************************');
disp('------- Input 1: Single DC-DC Converter ------------------------------');
disp('------- Input 2: Interleaved DC-DC Converter -------------------------');
Topology=input('------- Enter Topology Number: '); 
disp(' ');

disp('************************ Combination Selection ***********************');
disp('------- Input 1: aSynchronous Switches -------------------------------');
disp('------- Input 2: Synchronous Switches --------------------------------');
comb=input('------- Enter Combination Number: '); 
disp(' ');

disp('************************ Combination Selection ***********************');
disp('------- Input 1: Vin=500;Vout=1000;P=75e3 ----------------------------');
disp('------- Input 2: Vin=500;Vout=1000;P=37.5e3 --------------------------');
Case=input('------- Enter Case Type: ');
disp(' ');
%%
switch Topology;
    case 1 %% Single DC-DC Converter
     switch comb
         case 1  %%aSynchronous
             Major_switch=Mosfet(Type_Mosfet);   %%CREE C2M0045170D 1700V 72/48A
             %Major_switch=Mosfet(4);  %%CREE C2M0045170P 1700V 72/48A
             %Major_switch=Mosfet(2);  %%CREE CC2M0080170P 1700V 40/27A
             %Major_switch=Mosfet(1);  %%MicroSemi MSC035SMA170B 1700V 68/48A
             Minor_switch=Diode(Type_Diode);
             Major_switch_parallel_num=1;
             Minor_switch_parallel_num=1;
             
         case 2  %%Synchronous
            % Mosfet1:  MicorSemi MSC035SMA170B 1700V 68/48A SiC MOSFET 35mohm
            % Mosfet2:  CREE C2M0080170P 1700V 40/27a SiC MOSFET        80mohm
            % Mosfet3:  C3M0065090J 900V 35A SiC MOSFET                 65mohm
            % Mosfet4:  CREE C2M0045170P 1700V 72/48A SiC MOSFET        45mohm
            % Mosfet5:  CREE C2M0045170D 1700V 72/48A SiC MOSFET        45mohm
            % Mosfet6:  CREE C3M0016120K 1200V 115/85A SiC MOSFET       16mohm
            % Mosfet7:  CREE C3M0021120K 1200V 100/74A SiC MOSFET       21mohm
            % Mosfet8:  ON-SEMI NTBG020N120SC1 1200V 98 SiC MOSFET      20mohm
            % Mosfet9:  CREE C2M0025120D 1200V 90/60A SiC MOSFET        25mohm
          
             Major_switch=Mosfet(Type_Mosfet);
             Minor_switch=Mosfet(Type_Mosfet);
             Major_switch_parallel_num=1;
             Minor_switch_parallel_num=1;
             
         case 3  %%Both
             MMajor_switch=Mosfet(Type_Mosfet);   %%CREE C2M0045170D 1700V 72/48A
             %Major_switch=Mosfet(4);  %%CREE C2M0045170P 1700V 72/48A
             %Major_switch=Mosfet(2);  %%CREE CC2M0080170P 1700V 40/27A
             %Major_switch=Mosfet(1);  %%MicroSemi MSC035SMA170B 1700V 68/48A
             Minor_switch=Mosfet(Type_Mosfet);
             Major_switch_parallel_num=1;
             Minor_switch_parallel_num=1;
     end
     %%
    case 2 %% Interleaved DC-DC Converter
       switch comb
         case 1  %%SiC MOSFET as Major ; SiC Diode as Minor
             Major_switch=Mosfet(Type_Mosfet);   %%CREE C2M0045170D 1700V 72/48A
             %Major_switch=Mosfet(4);  %%CREE C2M0045170P 1700V 72/48A
             %Major_switch=Mosfet(2);  %%CREE CC2M0080170P 1700V 40/27A
             %Major_switch=Mosfet(1);  %%MicroSemi MSC035SMA170B 1700V 68/48A
             Minor_switch=Diode(Type_Diode);
             Major_switch_parallel_num=1;
             Minor_switch_parallel_num=1;
             
         case 2  %%SiC MOSFET as Major ; SiC MOSFET as Minor
             Major_switch=Mosfet(Type_Mosfet);   
             Minor_switch=Mosfet(Type_Mosfet);
             Major_switch_parallel_num=1;
             Minor_switch_parallel_num=1;
             
         case 3  %%Both
             Major_switch=Mosfet(Type_Mosfet);   %%CREE C2M0045170D 1700V 72/48A
             %Major_switch=Mosfet(4);  %%CREE C2M0045170P 1700V 72/48A
             %Major_switch=Mosfet(2);  %%CREE CC2M0080170P 1700V 40/27A
             %Major_switch=Mosfet(1);  %%MicroSemi MSC035SMA170B 1700V 68/48A
             Minor_switch=Mosfet(Type_Mosfet);
             Major_switch_parallel_num=1;
             Minor_switch_parallel_num=1;
       end
end
%% Select system parameters
switch Case
    case 1
        Vin=500;
        Vout=800;
        P=75e3;
        V_Ripple=10/100; %Numerator is Percentage
        I_Ripple=10/100; %Numerator is Percentage
        D=1-(Vin/Vout); 
        Iin=P/Vin;
        Rload=Vout/(P/Vout);
        ESR_L=0;
        ESR_C=0;
        Tamb=Junction;
  
    case 2 
        Vin=500;
        Vout=800;
        P=75e3/2;
        V_Ripple=10/100; %Numerator is Percentage
        I_Ripple=10/100; %Numerator is Percentage
        D=1-(Vin/Vout); 
        Iin=P/Vin;
        Rload=Vout/(P/Vout);
        ESR_L=0;
        ESR_C=0;
        Tamb=Junction;
   end


Device_sw=[Major_switch,Minor_switch];
Device_num=[Major_switch_parallel_num,Minor_switch_parallel_num];
Loss_Total=0;
Loss_Total=0;
S=P;

%%
 for j=1:1:Number_Mosfet                %Just Comment it when no more interested in Sweeping options
      Device_num=[j,j];      %Just Comment it when no more interested in Sweeping options
      Number_Interleaved=1;
      for m=1:1:10
            fs=10e3+(m-1)*10e3;
            %fs=60e3;
            P=S;
            P_interleaved=P/Number_Interleaved;
            Rg=4.5;
            C=(Iin*D*(1-D)*(1-D))/(fs*Vin*V_Ripple);
            L=(Vin*Vin*D)/(fs*P*I_Ripple);
            System_para=[fs,P_interleaved,Vin,Vout,D,ESR_L,ESR_C,L,C]; % Setting system parameters
            Device_temp = [Tamb,Tamb];
            switch Topology
                case 1  %%Single DC-DC Converter
                    switch comb
                        case 1 %%Mosfet-Diode
                            [Loss_Total, Conduction_Loss, Switch_Loss] = Loss_Calculator_aSynchronous(System_para,Device_temp,Device_sw,Device_num,Rg);           
                        case 2 %%Mosfet-Mosfet
                            [Loss_Total, Conduction_Loss, Switch_Loss] = Loss_Calculator_Synchronous(System_para,Device_temp,Device_sw,Device_num,Rg);
                    end
                case 2
                     switch comb
                        case 1 %%Mosfet-Mosfet
                            [Loss_Total, Conduction_Loss, Switch_Loss] = Loss_Calculator_aSynchronous(System_para,Device_temp,Device_sw,Device_num,Rg);           
                        case 2 %%Mosfet-Mosfet
                            [Loss_Total, Conduction_Loss, Switch_Loss] = Loss_Calculator_Synchronous(System_para,Device_temp,Device_sw,Device_num,Rg);
                      end
                    
            end
        Efficiency(j,m)=(P_interleaved)./((P_interleaved)+Loss_Total)*100;
        P_cond(j,m)=sum(Conduction_Loss);
        P_sw(j,m)=sum(Switch_Loss);
        end
        figure(1)
        plot(P_sw(1,:)','Linewidth',4,'color','blue');hold on;
 end
 
end