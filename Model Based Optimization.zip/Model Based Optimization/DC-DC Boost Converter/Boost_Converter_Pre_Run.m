clc
clear
Vin=500;
Vout=1000;
P=75e3;
ripple=1/100;  %Numerator is The Percentage
fs=50e3;
d=1-(Vin/Vout);
L=(Vin*Vin*d)/(fs*P*ripple);
Iin=P/Vin;
C=(Iin*d*(1-d)*(1-d))/(fs*Vin*ripple);
Rload=Vout/(P/Vout);
ESR_L=0;
ESR_C=0;
R_DIODE_ON=0;
V_F_DIODE=0;

a=0;b=0.5;c=1;
sim('Boost_Converter');