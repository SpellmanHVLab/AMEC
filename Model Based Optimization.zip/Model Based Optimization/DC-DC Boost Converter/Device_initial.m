function Device_initial()
%% These codes are for generating device database
%% Devices:
% Diode1:   ONSEMI FFSH2065A-D 650V 20A Schottcky diode
% Diode2:   CREE C5D50065D 650V 50A Schottcky diode        Confirmed by Mustafeez
% Diode3:   CVFD20065A 650V 26A Schottcky diode
% Diode4:   IXYS DSEI2x101-06A 600V 200A Schottcky diode

% Mosfet1:  MicorSemi MSC035SMA170B 1700V 68/48A SiC MOSFET Confirmed by Mustafeez
% Mosfet2:  CREE C2M0080170P 1700V 40/27a SiC MOSFET        Confirmed by Mustafeez
% Mosfet3:  C3M0065090J 900V 35A SiC MOSFET                 Confirmed by Mustafeez
% Mosfet4:  CREE C2M0045170P 1700V 72/48A SiC MOSFET        Confirmed by Mustafeez
% Mosfet5:  CREE C2M0045170D 1700V 72/48A SiC MOSFET        Confirmed by Mustafeez
 
% Igbt1:    Onsemi Discrete Si MOSFET FCH023N65S3L4 650V 75A
% Igbt2:    Infineon Discrete IGBT IKW40T120 1200V 40A
% Igbt3:    Infineon Discrete IGBT IGW75N60T 600V 75A
% Igbt4:    Infineon Discrete IGBT IGW60T120 1200V 60A
% Igbt5:    Infineon Discrete IGBT IKW40N120T2 1200V 40A

%% Devices:
% Module1:  CREE SiC Module Powermodule CAS300M17BM2 1700V 225A 
% Module2:  CREE SiC Module Powermodule CAS300M12BM2  1200V 404/285A
% Module3:  Infineon IGBT Module FF600R17ME4 1700V 600A
% Module4:  Infineon IGBT module FF150R17KE4 1700V 150A
% Module5:  CREE SiC Module Powermodule CAS120M12BM2 1200V 193/138A
% Module6:  Infineon IGBT Module FD1000R33HL3-K 3300V 1000A
% Module7:  CREE SiC Module Powermodule Experiment CAS300M17BM2 1700V 225A

%% Devices:
% Bjt1: GeneSiC GA100JT17-227 1700V 160/100A SiC Junction Transistor       Confirmed by Mustafeez
% Bjt2: GeneSiC GA100SICP12-227 1200V 160/100A SiC Junction Transistor     Partially Confirmed by Mustafeez



%% These parts are for generating diode database
% Naming rules: Brand Product# Volt Current Diodetype

%% ONSEMI FFSH2065A-D 650V 20A Schottcky diode
% Switch parameters
Diode(1).Vns=0;
Diode(1).Ins=0;
Diode(1).ts1=0;
Diode(1).ts2=0;
%  Switch temperature dependent parameters
Diode(1).ks1=0;
Diode(1).ks2=0;
Diode(1).as1=0;
Diode(1).as2=0;
%  Switching energy (J)
Diode(1).E1_on=0;
Diode(1).E2_on=0;
Diode(1).E1_off=0;
Diode(1).E2_off=0;
%  Thermal model
Diode(1).Rjct=0;

% Diode parameters
Diode(1).Vnd=800;
Diode(1).Ind=20;
Diode(1).td1=25;
Diode(1).td2=125;
%  Diode temperature dependent parameters
Diode(1).kd1=(1.4-1.01)/(18-2);
%Diode(1).kd2=(1.61-1.02)/(20-4);
Diode(1).kd2=(1.4-1.01)/(18-2);      %No Temperature Dependency%
Diode(1).ad1=1.01-(1.4-1.01)/(18-2)*2;
%Diode(1).ad2=1.02-(1.61-1.02)/(20-4)*4;
Diode(1).ad2=1.01-(1.4-1.01)/(18-2)*2;
%  Reverse recovery charge
Diode(1).Qrr1=0;
Diode(1).Qrr2=0;
%  Thermal model
Diode(1).Rjcd=0.29;

%  Judge whether it is a module
Diode(1).Module=0;
%  Price(dollar)
Diode(1).Price_sw=45;
%  Weight(g)
Diode(1).Weight_sw=8;
%  Price(dollar)
Diode(1).Price_gd=0;
%  Weight(g)
Diode(1).Weight_gd=0; 


%% CPW5-1200-Z050B Silicon Carbide Schottcky Diode Chip
% Switch parameters
Diode(2).Vns=1200;
Diode(2).Ins=50;
Diode(2).ts1=25;
Diode(2).ts2=125;
%  Switch temperature dependent parameters
Diode(2).ks1=13.64*10^-3;
Diode(2).ks2=13.64*10^-3;
Diode(2).as1=0.9344;
Diode(2).as2=0.9344;
%  Switching energy (J)
Diode(2).E1_on=0;
Diode(2).E2_on=0;
Diode(2).E1_off=0;
Diode(2).E2_off=0;
%  Thermal model
Diode(2).Rjct=0;

%Diode parameters
Diode(2).Vnd=1200;
Diode(2).Ind=50;
Diode(2).td1=25;
Diode(2).td2=125;
%  Diode temperature dependent parameters
Diode(2).kd1=13.64*10^-3;
Diode(2).kd2=13.64*10^-3;
Diode(2).ad1=0.9344;
Diode(2).ad2=0.9344;

%Diode(2).kd1=31.25*10^-3;
%Diode(2).kd2=31.25*10^-3;
%Diode(2).ad1=0.95;
%Diode(2).ad2=0.95;
%  Reverse recovery charge
Diode(2).Qrr1=246*10^-9;
Diode(2).Qrr2=0;
%  Thermal model
Diode(2).Rjcd=0.5;

%  Judge whether it is a module
Diode(2).Module=0;
%  Price(dollar)
Diode(2).Price_sw=25.8;
%  Weight(g)
Diode(2).Weight_sw=8;
%  Price(dollar)
Diode(2).Price_gd=0;
%  Weight(g)
Diode(2).Weight_gd=0; 
%
Diode(2).a11_on   =0;        %ZEROTH order co-efficienct
Diode(2).a12_on   =0;        %FIRST order co-efficienct
Diode(2).a13_on   =0;        %SECOND order co-efficienct
Diode(2).a14_on   =0;        %THIRD order co-efficienct
Diode(2).a11_off  =0;
Diode(2).a12_off  =0;
Diode(2).a13_off  =0;
Diode(2).a14_off  =0;
Diode(2).V1       =0;

Diode(2).rg1_on   =0;        %%ZEROTH order co-efficienct
Diode(2).rg2_on   =0;

Diode(2).rg1_off  =0;        %%ZEROTH order co-efficienct
Diode(2).rg2_off  =0;
Diode(2).I_ref    =0;        %Reference current for E with Rg curve


%% CREE CVFD20065A 26A Schottcky diode
% Switch parameters
Diode(3).Vns=650;
Diode(3).Ins=26;
Diode(3).ts1=25;
Diode(3).ts2=125;
%  Switch temperature dependent parameters
Diode(3).ks1=0.01995;
Diode(3).ks2=0.01995;
Diode(3).as1=0.9484;
Diode(3).as2=0.9484;
%  Switching energy (J)
Diode(3).E1_on=0;
Diode(3).E2_on=0;
Diode(3).E1_off=0;
Diode(3).E2_off=0;
%  Thermal model
Diode(3).Rjct=0;

%Diode parameters
Diode(3).Vnd=650;
Diode(3).Ind=26;
Diode(3).td1=25;
Diode(3).td2=125;
%  Diode temperature dependent parameters
Diode(3).kd1=0.01995;
Diode(3).kd2=0.01995;
Diode(3).ad1=0.9484;
Diode(3).ad2=0.9484;
%  Reverse recovery charge
Diode(3).Qrr1=62*10^-9;
Diode(3).Qrr2=0*10^-9;
%  Thermal model
Diode(3).Rjcd=0.4;

%  Judge whether it is a module
Diode(3).Module=0;
%  Price(dollar)
Diode(3).Price_sw=25.8;
%  Weight(g)
Diode(3).Weight_sw=8;
%  Price(dollar)
Diode(3).Price_gd=0;
%  Weight(g)
Diode(3).Weight_gd=0; 

Diode(3).a11_on   =0;        %ZEROTH order co-efficienct
Diode(3).a12_on   =0;        %FIRST order co-efficienct
Diode(3).a13_on   =0;        %SECOND order co-efficienct
Diode(3).a14_on   =0;        %THIRD order co-efficienct
Diode(3).a11_off  =0;
Diode(3).a12_off  =0;
Diode(3).a13_off  =0;
Diode(3).a14_off  =0;
Diode(3).V1       =0;

Diode(3).rg1_on   =0;        %%ZEROTH order co-efficienct
Diode(3).rg2_on   =0;

Diode(3).rg1_off  =0;        %%ZEROTH order co-efficienct
Diode(3).rg2_off  =0;
Diode(3).I_ref    =20;        %Reference current for E with Rg curve


%% IXYS DSEI2x101-06A 600V 200A Schottcky diode
% Switch parameters
Diode(4).Vns=0;
Diode(4).Ins=0;
Diode(4).ts1=0;
Diode(4).ts2=0;
%  Switch temperature dependent parameters
Diode(4).ks1=0;
Diode(4).ks2=0;
Diode(4).as1=0;
Diode(4).as2=0;
%  Switching energy (J)
Diode(4).E1_on=0;
Diode(4).E2_on=0;
Diode(4).E1_off=0;
Diode(4).E2_off=0;
%  Thermal model
Diode(4).Rjct=0;

%Diode parameters
Diode(4).Vnd=300;
Diode(4).Ind=100;
Diode(4).td1=25;
Diode(4).td2=150;
%  Diode temperature dependent parameters
Diode(4).kd1=(1.25-0.9)/100;
Diode(4).kd2=(1.2-0.7)/100;
Diode(4).ad1=0.9;
Diode(4).ad2=0.7;
%  Reverse recovery charge
Diode(4).Qrr1=200*10^-9;
Diode(4).Qrr2=200*10^-9;
%  Thermal model
Diode(4).Rjcd=0.4;

%  Judge whether it is a module
Diode(4).Module=0;
%  Price(dollar)
Diode(4).Price_sw=22.12;
%  Weight(g)
Diode(4).Weight_sw=30;
%  Price(dollar)
Diode(4).Price_gd=0;
%  Weight(g)
Diode(4).Weight_gd=0; 


%% C2M0045170D Transistor's Body diode
% Switch parameters
Diode(5).Vns=1200;
Diode(5).Ins=50;
Diode(5).ts1=25;
Diode(5).ts2=150;
%  Switch temperature dependent parameters
Diode(5).ks1=(5.7-3.5)/90;
Diode(5).ks2=(5.1-3.35)/90;
Diode(5).as1=1.85;
Diode(5).as2=1.4;
%  Switching energy (J)
Diode(5).E1_on=4.7e-3;
Diode(5).E2_on=4.6e-3;
Diode(5).E1_off=0.93e-3;
Diode(5).E2_off=1.1e-3;
%  Thermal model
Diode(5).Rjct=0.7;

%Diode parameters
Diode(5).Vnd=1200;
Diode(5).Ind=50;
Diode(5).td1=25;
Diode(5).td2=150;
%  Diode temperature dependent parameters
Diode(5).kd1=(5.7-3.5)/90;
Diode(5).kd2=(5.1-3.35)/90;
Diode(5).ad1=1.85;
Diode(5).ad2=1.4;
%  Reverse recovery charge
Diode(5).Qrr1=530*10^-9;
Diode(5).Qrr2=550*10^-9;
%  Thermal model
Diode(5).Rjcd=0;

%  Judge whether it is a module
Diode(5).Module=0;
%  Price(dollar)
Diode(5).Price_sw=22.12;
%  Weight(g)
Diode(5).Weight_sw=30;
%  Price(dollar)
Diode(5).Price_gd=0;
%  Weight(g)
Diode(5).Weight_gd=0;

Diode(5).a11_on=0.0003879;        %ZEROTH order co-efficienct
Diode(5).a12_on=2.869e-05;        %FIRST order co-efficienct
Diode(5).a13_on=4.654e-07;        %SECOND order co-efficienct
Diode(5).a14_on=-1.263e-10;       %THIRD order co-efficienct
Diode(5).a11_off=0.0001109;
Diode(5).a12_off=-6.548e-06;
Diode(5).a13_off=3.149e-07;
Diode(5).a14_off=5.051e-10;
Diode(5).V1     =1200;

Diode(5).rg1_on=0.002808;      %%ZEROTH order co-efficienct
Diode(5).rg2_on=8.229e-05;

Diode(5).rg1_off=0.0003573;    %%ZEROTH order co-efficienct
Diode(5).rg2_off=0.0001334;
Diode(5).I_ref=50;             %Reference current for E with Rg curve


save('Diodedata','Diode');


%% These codes are for generating MOSFET database
% Naming rules: Brand Product# Volt Current MOSFETtype

%% MSC035SMA170B
% Switch parameters
Mosfet(1).Vns=1300;
Mosfet(1).Ins=50;
Mosfet(1).ts1=25;
Mosfet(1).ts2=175;
%  MOSFET temperature dependent parameters
Mosfet(1).ks1=35*10^-3;
Mosfet(1).ks2=61.25*10^-3;
Mosfet(1).as1=0;
Mosfet(1).as2=0;
%  Switching energy (J)
Mosfet(1).E1_on=  4.7*10^-3;
Mosfet(1).E2_on=  4.6*10^-3;
Mosfet(1).E1_off=0.93*10^-3;
Mosfet(1).E2_off= 1.1*10^-3;
%  Thermal model
Mosfet(1).Rjct=0.7;

% Diode parameters
Mosfet(1).Vnd=1300;
Mosfet(1).Ind=50;
Mosfet(1).td1=25;
Mosfet(1).td2=175;
%  Diode temperature dependent parameters
Mosfet(1).kd1=35*10^-3;
Mosfet(1).kd2=61.25*10^-3;
Mosfet(1).ad1=0;
Mosfet(1).ad2=0;
%  Reverse recovery charge
Mosfet(1).Qrr1=650*10^-9;
%Mosfet(5).Qrr1=0;
Mosfet(1).Qrr2=0;
%  Thermal model
Mosfet(1).Rjcd=0;

%  Judge whether it is a module
Mosfet(1).Module=0;
%  Price(dollar)
Mosfet(1).Price_sw=9.07;
%  Weight(g)
Mosfet(1).Weight_sw=8;
%  Price(dollar)
Mosfet(1).Price_gd=50;
%  Weight(g)
Mosfet(1).Weight_gd=50;


Mosfet(1).a11_on=0.0002537;         %ZEROTH order co-efficienct
Mosfet(1).a12_on=3.681e-05;         %FIRST order co-efficienct
Mosfet(1).a13_on=-1.528e-07;        %SECOND order co-efficienct
Mosfet(1).a14_on=0;                 %THIRD order co-efficienct
Mosfet(1).a11_off=0.001651;
Mosfet(1).a12_off=-5.469e-05;
Mosfet(1).a13_off=5.444e-07;
Mosfet(1).a14_off=0;
Mosfet(1).V1     =1300;

Mosfet(1).rg1_on=0.001536;      %%ZEROTH order co-efficienct
Mosfet(1).rg2_on=4.4e-05;

Mosfet(1).rg1_off=0.000234;     %%ZEROTH order co-efficienct
Mosfet(1).rg2_off= 1.1e-05;
Mosfet(1).I_ref=50;             %Reference current for E with Rg curve



%% C2M0080170P
% Switch parameters
Mosfet(2).Vns=1200;
Mosfet(2).Ins=20;
Mosfet(2).ts1=25;
Mosfet(2).ts2=150;
%  MOSFET temperature dependent parameters
Mosfet(2).ks1=80*10^-3;
Mosfet(2).ks2=168*10^-3;
Mosfet(2).as1=0;
Mosfet(2).as2=0;
%  Switching energy (J)
Mosfet(2).E1_on=  4.7*10^-3;
Mosfet(2).E2_on=  4.6*10^-3;
Mosfet(2).E1_off=0.93*10^-3;
Mosfet(2).E2_off= 1.1*10^-3;
%  Thermal model
Mosfet(2).Rjct=0.7;

% Diode parameters     (Third Quadrant Operation)
Mosfet(2).Vnd=1200;
Mosfet(2).Ind=20;
Mosfet(2).td1=25;
Mosfet(2).td2=150;
%  Diode temperature dependent parameters (Third Quadrant Operation)
Mosfet(2).kd1=80*10^-3;
Mosfet(2).kd2=168*10^-3;
Mosfet(2).ad1=0;
Mosfet(2).ad2=0;
%  Reverse recovery charge
Mosfet(2).Qrr1=1*10^-6;
%Mosfet(5).Qrr1=0;
Mosfet(2).Qrr2=0;
%  Thermal model
Mosfet(2).Rjcd=0;

%  Judge whether it is a module
Mosfet(2).Module=0;
%  Price(dollar)
Mosfet(2).Price_sw=9.07;
%  Weight(g)
Mosfet(2).Weight_sw=8;
%  Price(dollar)
Mosfet(2).Price_gd=50;
%  Weight(g)
Mosfet(2).Weight_gd=50;


Mosfet(2).a11_on=3.4e-07;           %ZEROTH order co-efficienct
Mosfet(2).a12_on=7.833e-09;         %FIRST order co-efficienct
Mosfet(2).a13_on= 3.5e-10;          %SECOND order co-efficienct
Mosfet(2).a14_on=-3.333e-1          %THIRD order co-efficienct
Mosfet(2).a11_off=9.2e-08;
Mosfet(2).a12_off=1.383e-09;
Mosfet(2).a13_off=-7e-11;
Mosfet(2).a14_off=1.167e-12;
Mosfet(2).V1     =1200;

Mosfet(2).rg1_on=0.00115;       %%ZEROTH order co-efficienct
Mosfet(2).rg2_on=9.3e-05;

Mosfet(2).rg1_off=5e-05;        %%ZEROTH order co-efficienct
Mosfet(2).rg2_off= 9.2e-05;
Mosfet(2).I_ref=50;             %%Reference current for E with Rg curve


%% C3M0065090J 900V 35A SiC MOSFET
% Switch parameters
Mosfet(3).Vns=900;
Mosfet(3).Ins=35;
Mosfet(3).ts1=25;
Mosfet(3).ts2=150;
%  MOSFET temperature dependent parameters
Mosfet(3).ks1=65*10^-3;
Mosfet(3).ks2=65*10^-3;
Mosfet(3).as1=0;
Mosfet(3).as2=0;
%  Switching energy (J)
Mosfet(3).E1_on=61*10^-6;
Mosfet(3).E2_on=60*10^-6;
Mosfet(3).E1_off=41*10^-6;
Mosfet(3).E2_off=42*10^-6;
%  Thermal model
Mosfet(3).Rjct=0.7;

% Diode parameters
Mosfet(3).Vnd=900;
Mosfet(3).Ind=35;
Mosfet(3).td1=25;
Mosfet(3).td2=125;
%  Diode temperature dependent parameters
Mosfet(3).kd1=65*10^-3;
Mosfet(3).kd2=65*10^-3;
Mosfet(3).ad1=0;
Mosfet(3).ad2=0;
%  Reverse recovery charge
Mosfet(3).Qrr1=215*10^-9;
Mosfet(3).Qrr2=0;
%  Thermal model
Mosfet(3).Rjcd=0;

%  Judge whether it is a module
Mosfet(3).Module=0;
%  Price(dollar)
Mosfet(3).Price_sw=9.07;
%  Weight(g)
Mosfet(3).Weight_sw=8;
%  Price(dollar)
Mosfet(3).Price_gd=50;
%  Weight(g)
Mosfet(3).Weight_gd=50; 


Mosfet(3).a11_on=2.171e-05;          %ZEROTH order co-efficienct
Mosfet(3).a12_on=1.56e-06;           %FIRST order co-efficienct
Mosfet(3).a13_on=-2.857e-08;         %SECOND order co-efficienct
Mosfet(3).a14_on=4.444e-10;          %THIRD order co-efficienct
Mosfet(3).a11_off=9.714e-06;
Mosfet(3).a12_off=-6.075e-07;
Mosfet(3).a13_off=2.548e-08;
Mosfet(3).a14_off=-2.222e-10;
Mosfet(3).V1     =400;

Mosfet(3).rg1_on=3.081e-05;      %%ZEROTH order co-efficienct
Mosfet(3).rg2_on=3.849e-06;

Mosfet(3).rg1_off=-1.432e-06;    %%ZEROTH order co-efficienct
Mosfet(3).rg2_off=1.854e-06;
Mosfet(3).I_ref=20;             %Reference current for E with Rg curve




%% CREE C2M0045170P 1700V 72/48A SiC MOSFET
% Switch parameters
Mosfet(4).Vns=1200;     %Reference Voltage at which switching losses are given
Mosfet(4).Ins=50;       %Reference Current at which switching losses are given
Mosfet(4).ts1=25;       %Normal Junction Temperature
Mosfet(4).ts2=150;      %Maximum Junction Temperature
%  MOSFET temperature dependent parameters
Mosfet(4).ks1=45*10^-3; %Normal Temperature ON Resistance
Mosfet(4).ks2=90*10^-3; %Maximum Temperature ON Resesistance
Mosfet(4).as1=0;        %Offset in ON Resistance
Mosfet(4).as2=0;        %Offset in ON Resistance
%  Switching energy (J)
Mosfet(4).E1_on=  4.7*10^-3; %Just Ignore
Mosfet(4).E2_on=  4.6*10^-3; %Ignore
Mosfet(4).E1_off=0.93*10^-3; %Ignore
Mosfet(4).E2_off= 1.1*10^-3; %Ignore
%  Thermal model
Mosfet(4).Rjct=0.7;

% Diode parameters
Mosfet(4).Vnd=1200;  
Mosfet(4).Ind=50;
Mosfet(4).td1=25;
Mosfet(4).td2=150;
%  Third Quadrant Operation of Transistor
Mosfet(4).kd1=45*10^-3;
Mosfet(4).kd2=90*10^-3;
Mosfet(4).ad1=0;
Mosfet(4).ad2=0;
%  Reverse recovery charge
Mosfet(4).Qrr1=2*10^-6;
%Mosfet(5).Qrr1=0;
Mosfet(4).Qrr2=0;
%  Thermal model
Mosfet(4).Rjcd=0;

%  Judge whether it is a module
Mosfet(4).Module=0;
%  Price(dollar)
Mosfet(4).Price_sw=9.07;
%  Weight(g)
Mosfet(4).Weight_sw=8;
%  Price(dollar)
Mosfet(4).Price_gd=50;
%  Weight(g)
Mosfet(4).Weight_gd=50;


Mosfet(4).a11_on=0.0004179 ;        %ZEROTH order co-efficienct
Mosfet(4).a12_on=1.158e-05;        %FIRST order co-efficienct
Mosfet(4).a13_on=1.959e-07;        %SECOND order co-efficienct
Mosfet(4).a14_on=-1.01e-09;       %THIRD order co-efficienct
Mosfet(4).a11_off=0.00019;
Mosfet(4).a12_off=-5.183e-06;
Mosfet(4).a13_off=1.738e-07;
Mosfet(4).a14_off=-5.556e-10;
Mosfet(4).V1     =1200;

Mosfet(4).rg1_on= 0.00115;      %%ZEROTH order co-efficienct
Mosfet(4).rg2_on= 9.2e-05;

Mosfet(4).rg1_off=5e-05;    %%ZEROTH order co-efficienct
Mosfet(4).rg2_off=9.2e-05;
Mosfet(4).I_ref=50;             %Reference current for E with Rg curve


%% CREE C2M0045170D 1700V 72/48A SiC MOSFET
% Switch parameters
Mosfet(5).Vns=1200;     %Reference Voltage at which switching losses are given
Mosfet(5).Ins=50;       %Reference Current at which switching losses are given
Mosfet(5).ts1=25;       %Normal Junction Temperature
Mosfet(5).ts2=150;      %Maximum Junction Temperature
%  MOSFET temperature dependent parameters
Mosfet(5).ks1=45*10^-3; %Normal Temperature ON Resistance
Mosfet(5).ks2=90*10^-3; %Maximum Temperature ON Resesistance
Mosfet(5).as1=0;        %Offset in ON Resistance
Mosfet(5).as2=0;        %Offset in ON Resistance
%  Switching energy (J)
Mosfet(5).E1_on=  4.7*10^-3; %Just Ignore
Mosfet(5).E2_on=  4.6*10^-3; %Ignore
Mosfet(5).E1_off=0.93*10^-3; %Ignore
Mosfet(5).E2_off= 1.1*10^-3; %Ignore
%  Thermal model
Mosfet(5).Rjct=0.7;

% Diode parameters
Mosfet(5).Vnd=1200;  
Mosfet(5).Ind=50;
Mosfet(5).td1=25;
Mosfet(5).td2=150;
%  Third Quadrant Operation of Transistor
Mosfet(5).kd1=45*10^-3;
Mosfet(5).kd2=90*10^-3;
Mosfet(5).ad1=0;
Mosfet(5).ad2=0;
%  Reverse recovery charge
Mosfet(5).Qrr1=530*10^-9;
%Mosfet(5).Qrr1=0;
Mosfet(5).Qrr2=0;
%  Thermal model
Mosfet(5).Rjcd=0;

%  Judge whether it is a module
Mosfet(5).Module=0;
%  Price(dollar)
Mosfet(5).Price_sw=9.07;
%  Weight(g)
Mosfet(5).Weight_sw=8;
%  Price(dollar)
Mosfet(5).Price_gd=50;
%  Weight(g)
Mosfet(5).Weight_gd=50;


Mosfet(5).a11_on=0.0003607;        %ZEROTH order co-efficienct
Mosfet(5).a12_on=3.015e-05;        %FIRST order co-efficienct
Mosfet(5).a13_on=4.545e-07;        %SECOND order co-efficienct
Mosfet(5).a14_on=-1.263e-10;       %THIRD order co-efficienct
Mosfet(5).a11_off=0.0001913;
Mosfet(5).a12_off=-1.422e-05;
Mosfet(5).a13_off=5.058e-07;
Mosfet(5).a14_off=-7.702e-10;
Mosfet(5).V1     =1200;

Mosfet(5).rg1_on= 0.0028;      %%ZEROTH order co-efficienct
Mosfet(5).rg2_on= 8e-05;

Mosfet(5).rg1_off=0.00035;    %%ZEROTH order co-efficienct
Mosfet(5).rg2_off=0.000134;
Mosfet(5).I_ref=50;             %Reference current for E with Rg curve



%% CREE C3M0016120K 1200V 115/85A SiC MOSFET
% Switch parameters
Mosfet(6).Vns=800;     %Reference Voltage at which switching losses are given
Mosfet(6).Ins=75;       %Reference Current at which switching losses are given
Mosfet(6).ts1=25;       %Normal Junction Temperature
Mosfet(6).ts2=175;      %Maximum Junction Temperature
%  MOSFET temperature dependent parameters
Mosfet(6).ks1=16*10^-3;   %Normal Temperature ON Resistance
Mosfet(6).ks2=28.8*10^-3; %Maximum Temperature ON Resesistance
Mosfet(6).as1=0;        %Offset in ON Resistance
Mosfet(6).as2=0;        %Offset in ON Resistance
%  Switching energy (J)
Mosfet(6).E1_on=  4.7*10^-3; %Just Ignore
Mosfet(6).E2_on=  4.6*10^-3; %Ignore
Mosfet(6).E1_off=0.93*10^-3; %Ignore
Mosfet(6).E2_off= 1.1*10^-3; %Ignore
%  Thermal model
Mosfet(6).Rjct=0.7;

% Diode parameters
Mosfet(6).Vnd=800;  
Mosfet(6).Ind=75;
Mosfet(6).td1=25;
Mosfet(6).td2=175;
%  Third Quadrant Operation of Transistor
Mosfet(6).kd1=16*10^-3;   %%Vgs is nearly equal to 10/12V
Mosfet(6).kd2=28.8*10^-3; 
Mosfet(6).ad1=0;
Mosfet(6).ad2=0;
%  Reverse recovery charge
Mosfet(6).Qrr1=1238*10^-9;
%Mosfet(5).Qrr1=0;
Mosfet(6).Qrr2=0;
%  Thermal model
Mosfet(6).Rjcd=0;

%  Judge whether it is a module
Mosfet(6).Module=0;
%  Price(dollar)
Mosfet(6).Price_sw=9.07;
%  Weight(g)
Mosfet(6).Weight_sw=8;
%  Price(dollar)
Mosfet(6).Price_gd=50;
%  Weight(g)
Mosfet(6).Weight_gd=50;


Mosfet(6).a11_on=0.0003897;        %ZEROTH order co-efficienct
Mosfet(6).a12_on=4.25e-07;        %FIRST order co-efficienct
Mosfet(6).a13_on=2.749e-07;        %SECOND order co-efficienct
Mosfet(6).a14_on=-1.001e-09;       %THIRD order co-efficienct
Mosfet(6).a11_off=8.053e-06;
Mosfet(6).a12_off=3.577e-06;
Mosfet(6).a13_off=5.247e-08;
Mosfet(6).a14_off=5.116e-12;
Mosfet(6).V1     =800;

Mosfet(6).rg1_on= 0.00125;      %%ZEROTH order co-efficienct
Mosfet(6).rg2_on= 0.000124;

Mosfet(6).rg1_off=0.000525;    %%ZEROTH order co-efficienct
Mosfet(6).rg2_off=9e-05;
Mosfet(6).I_ref=75;             %Reference current for E with Rg curve



%% CREE C3M0021120K 1200V 100/74A SiC MOSFET
% Switch parameters
Mosfet(7).Vns=800;     %Reference Voltage at which switching losses are given
Mosfet(7).Ins=50;       %Reference Current at which switching losses are given
Mosfet(7).ts1=25;       %Normal Junction Temperature
Mosfet(7).ts2=175;      %Maximum Junction Temperature
%  MOSFET temperature dependent parameters
Mosfet(7).ks1=21*10^-3;   %Normal Temperature ON Resistance
Mosfet(7).ks2=38*10^-3; %Maximum Temperature ON Resesistance
Mosfet(7).as1=0;        %Offset in ON Resistance
Mosfet(7).as2=0;        %Offset in ON Resistance
%  Switching energy (J)
Mosfet(7).E1_on=  4.7*10^-3; %Just Ignore
Mosfet(7).E2_on=  4.6*10^-3; %Ignore
Mosfet(7).E1_off=0.93*10^-3; %Ignore
Mosfet(7).E2_off= 1.1*10^-3; %Ignore
%  Thermal model
Mosfet(7).Rjct=0.7;

% Diode parameters
Mosfet(7).Vnd=800;  
Mosfet(7).Ind=50;
Mosfet(7).td1=25;
Mosfet(7).td2=175;
%  Third Quadrant Operation of Transistor
Mosfet(7).kd1=21*10^-3;   %%Vgs is nearly equal to 10/12V
Mosfet(7).kd2=38*10^-3; 
Mosfet(7).ad1=0;
Mosfet(7).ad2=0;
%  Reverse recovery charge
Mosfet(7).Qrr1=928*10^-9;
%Mosfet(5).Qrr1=0;
Mosfet(7).Qrr2=0;
%  Thermal model
Mosfet(7).Rjcd=0;

%  Judge whether it is a module
Mosfet(7).Module=0;
%  Price(dollar)
Mosfet(7).Price_sw=9.07;
%  Weight(g)
Mosfet(7).Weight_sw=8;
%  Price(dollar)
Mosfet(7).Price_gd=50;
%  Weight(g)
Mosfet(7).Weight_gd=50;


Mosfet(7).a11_on=0.0002607;        %ZEROTH order co-efficienct
Mosfet(7).a12_on=6.6e-06 ;        %FIRST order co-efficienct
Mosfet(7).a13_on=2.013e-07;        %SECOND order co-efficienct
Mosfet(7).a14_on=-6.313e-10;       %THIRD order co-efficienct
Mosfet(7).a11_off=7.786e-05;
Mosfet(7).a12_off=-9.946e-07 ;
Mosfet(7).a13_off=1.133e-07;
Mosfet(7).a14_off=-1.515e-10;
Mosfet(7).V1     =800;

Mosfet(7).rg1_on= 0.000925;      %%ZEROTH order co-efficienct
Mosfet(7).rg2_on= 7.9e-05;

Mosfet(7).rg1_off=0.0002;        %%ZEROTH order co-efficienct
Mosfet(7).rg2_off=6.3e-05;
Mosfet(7).I_ref=50;              %%Reference current for E with Rg curve



%% ON-SEMI NTBG020N120SC1 1200V 98/74A SiC MOSFET
% Switch parameters
Mosfet(8).Vns=800;     %Reference Voltage at which switching losses are given
Mosfet(8).Ins=80;       %Reference Current at which switching losses are given
Mosfet(8).ts1=25;       %Normal Junction Temperature
Mosfet(8).ts2=175;      %Maximum Junction Temperature
%  MOSFET temperature dependent parameters
Mosfet(8).ks1=20*10^-3;   %Normal Temperature ON Resistance
Mosfet(8).ks2=35*10^-3; %Maximum Temperature ON Resesistance
Mosfet(8).as1=0;        %Offset in ON Resistance
Mosfet(8).as2=0;        %Offset in ON Resistance
%  Switching energy (J)
Mosfet(8).E1_on=  4.7*10^-3; %Just Ignore
Mosfet(8).E2_on=  4.6*10^-3; %Ignore
Mosfet(8).E1_off=0.93*10^-3; %Ignore
Mosfet(8).E2_off= 1.1*10^-3; %Ignore
%  Thermal model
Mosfet(8).Rjct=0.7;

% Diode parameters
Mosfet(8).Vnd=800;  
Mosfet(8).Ind=80;
Mosfet(8).td1=25;
Mosfet(8).td2=175;
%  Third Quadrant Operation of Transistor
Mosfet(8).kd1=20*10^-3;   %%Vgs is nearly equal to 10/12V
Mosfet(8).kd2=35*10^-3; 
Mosfet(8).ad1=0;
Mosfet(8).ad2=0;
%  Reverse recovery charge
Mosfet(8).Qrr1=228*10^-9;
%Mosfet(5).Qrr1=0;
Mosfet(8).Qrr2=0;
%  Thermal model
Mosfet(8).Rjcd=0;

%  Judge whether it is a module
Mosfet(8).Module=0;
%  Price(dollar)
Mosfet(8).Price_sw=9.07;
%  Weight(g)
Mosfet(8).Weight_sw=8;
%  Price(dollar)
Mosfet(8).Price_gd=50;
%  Weight(g)
Mosfet(8).Weight_gd=50;


Mosfet(8).a11_on= 0.0006718;        %ZEROTH order co-efficienct
Mosfet(8).a12_on=-3.264e-05;        %FIRST order co-efficienct
Mosfet(8).a13_on= 5.686e-07;        %SECOND order co-efficienct
Mosfet(8).a14_on=-2.417e-09;        %THIRD order co-efficienct
Mosfet(8).a11_off=-0.0003468;
Mosfet(8).a12_off=2.718e-05;
Mosfet(8).a13_off=-5.364e-07;
Mosfet(8).a14_off=3.917e-09;
Mosfet(8).V1     =800;

Mosfet(8).rg1_on= 0.0003926;      %%ZEROTH order co-efficienct
Mosfet(8).rg2_on= 3.46e-05;

Mosfet(8).rg1_off=0.0003372;      %%ZEROTH order co-efficienct
Mosfet(8).rg2_off=3.12e-05;
Mosfet(8).I_ref=80;               %%Reference current for E with Rg curve



%% CREE C2M0025120D 1200V 90/60A SiC MOSFET
% Switch parameters
Mosfet(9).Vns=800;     %Reference Voltage at which switching losses are given
Mosfet(9).Ins=50;       %Reference Current at which switching losses are given
Mosfet(9).ts1=25;       %Normal Junction Temperature
Mosfet(9).ts2=150;      %Maximum Junction Temperature
%  MOSFET temperature dependent parameters
Mosfet(9).ks1=25*10^-3;   %Normal Temperature ON Resistance
Mosfet(9).ks2=43*10^-3; %Maximum Temperature ON Resesistance
Mosfet(9).as1=0;        %Offset in ON Resistance
Mosfet(9).as2=0;        %Offset in ON Resistance
%  Switching energy (J)
Mosfet(9).E1_on=  4.7*10^-3; %Just Ignore
Mosfet(9).E2_on=  4.6*10^-3; %Ignore
Mosfet(9).E1_off=0.93*10^-3; %Ignore
Mosfet(9).E2_off= 1.1*10^-3; %Ignore
%  Thermal model
Mosfet(9).Rjct=0.7;

% Diode parameters
Mosfet(9).Vnd=800;  
Mosfet(9).Ind=50;
Mosfet(9).td1=25;
Mosfet(9).td2=150;
%  Third Quadrant Operation of Transistor
Mosfet(9).kd1=25*10^-3;   %%Vgs is nearly equal to 10/12V
Mosfet(9).kd2=43*10^-3; 
Mosfet(9).ad1=0;
Mosfet(9).ad2=0;
%  Reverse recovery charge
Mosfet(9).Qrr1=406*10^-9;
%Mosfet(5).Qrr1=0;
Mosfet(9).Qrr2=0;
%  Thermal model
Mosfet(9).Rjcd=0;

%  Judge whether it is a module
Mosfet(9).Module=0;
%  Price(dollar)
Mosfet(9).Price_sw=9.07;
%  Weight(g)
Mosfet(9).Weight_sw=8;
%  Price(dollar)
Mosfet(9).Price_gd=50;
%  Weight(g)
Mosfet(9).Weight_gd=50;


Mosfet(9).a11_on= 0.0001833;        %ZEROTH order co-efficienct
Mosfet(9).a12_on= 7.275e-08;        %FIRST order co-efficienct
Mosfet(9).a13_on= 6.984e-07;        %SECOND order co-efficienct
Mosfet(9).a14_on=-2.315e-09;        %THIRD order co-efficienct
Mosfet(9).a11_off= 0.0001333;
Mosfet(9).a12_off=-8.677e-06;
Mosfet(9).a13_off= 5.377e-07;
Mosfet(9).a14_off=-2.315e-09;
Mosfet(9).V1     =800;

Mosfet(9).rg1_on= 0.00125;          %%ZEROTH order co-efficienct
Mosfet(9).rg2_on= 5e-05;

Mosfet(9).rg1_off=0.00017;      %%ZEROTH order co-efficienct
Mosfet(9).rg2_off=6.6e-05;
Mosfet(9).I_ref=50;               %%Reference current for E with Rg curve


%% United UF3SC120009K4S 1200V 120A SiC MOSFET
% Switch parameters
Mosfet(10).Vns=800;     %Reference Voltage at which switching losses are given
Mosfet(10).Ins=100;       %Reference Current at which switching losses are given
Mosfet(10).ts1=25;       %Normal Junction Temperature
Mosfet(10).ts2=175;      %Maximum Junction Temperature
%  MOSFET temperature dependent parameters
Mosfet(10).ks1=8.6*10^-3;   %Normal Temperature ON Resistance
Mosfet(10).ks2=18.2*10^-3; %Maximum Temperature ON Resesistance
Mosfet(10).as1=0;        %Offset in ON Resistance
Mosfet(10).as2=0;        %Offset in ON Resistance
%  Switching energy (J)
Mosfet(10).E1_on=  4.7*10^-3; %Just Ignore
Mosfet(10).E2_on=  4.6*10^-3; %Ignore
Mosfet(10).E1_off=0.93*10^-3; %Ignore
Mosfet(10).E2_off= 1.1*10^-3; %Ignore
%  Thermal model
Mosfet(10).Rjct=0.7;

% Diode parameters
Mosfet(10).Vnd=800;  
Mosfet(10).Ind=100;
Mosfet(10).td1=25;
Mosfet(10).td2=175;
%  Third Quadrant Operation of Transistor
Mosfet(10).kd1=8.6*10^-3;   %%Vgs is nearly equal to 10/12V
Mosfet(10).kd2=18.2*10^-3; 
Mosfet(10).ad1=0;
Mosfet(10).ad2=0;
%  Reverse recovery charge
Mosfet(10).Qrr1=1373*10^-9;
%Mosfet(5).Qrr1=0;
Mosfet(10).Qrr2=0;
%  Thermal model
Mosfet(10).Rjcd=0;

%  Judge whether it is a module
Mosfet(10).Module=0;
%  Price(dollar)
Mosfet(10).Price_sw=9.07;
%  Weight(g)
Mosfet(10).Weight_sw=8;
%  Price(dollar)
Mosfet(10).Price_gd=50;
%  Weight(g)
Mosfet(10).Weight_gd=50;


Mosfet(10).a11_on=   0.00131;        %ZEROTH order co-efficienct
Mosfet(10).a12_on= 1.885e-05;        %FIRST order co-efficienct
Mosfet(10).a13_on= 2.217e-08;        %SECOND order co-efficienct
Mosfet(10).a14_on= 6.249e-11;        %THIRD order co-efficienct
Mosfet(10).a11_off= 0.0001463;
Mosfet(10).a12_off= 5.211e-06;
Mosfet(10).a13_off= -8.12e-08;
Mosfet(10).a14_off= 8.644e-10;
Mosfet(10).V1     =800;

Mosfet(10).rg1_on= 0.0032260;          %%ZEROTH order co-efficienct
Mosfet(10).rg2_on= 0.0001061;

Mosfet(10).rg1_off=0.0005587;      %%ZEROTH order co-efficienct
Mosfet(10).rg2_off=3.128e-05;
Mosfet(10).I_ref=100;               %%Reference current for E with Rg curve


save('Mosfetdata','Mosfet');

end