// generated using template: cop_main.template---------------------------------------------
/******************************************************************************************
**
**  Module Name: cop_main.c
**  NOTE: Automatically generated file. DO NOT MODIFY!
**  Description:
**            Main file
**
******************************************************************************************/
// generated using template: arm/custom_include.template-----------------------------------


#ifdef __cplusplus
#include <limits>

extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <complex.h>

// x86 libraries:
#include "../include/sp_functions_dev0.h"


#ifdef __cplusplus
}
#endif


// ----------------------------------------------------------------------------------------                // generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) (((value) > (limit)) ? (value) : (limit))
#endif
#ifndef MIN
#define MIN(value, limit) (((value) < (limit)) ? (value) : (limit))
#endif

// generated using template: VirtualHIL/custom_defines.template----------------------------

typedef unsigned char X_UnInt8;
typedef char X_Int8;
typedef signed short X_Int16;
typedef unsigned short X_UnInt16;
typedef int X_Int32;
typedef unsigned int X_UnInt32;
typedef unsigned int uint;
typedef double real;

// ----------------------------------------------------------------------------------------
// generated using template: custom_consts.template----------------------------------------

// arithmetic constants
#define C_SQRT_2                    1.4142135623730950488016887242097f
#define C_SQRT_3                    1.7320508075688772935274463415059f
#define C_PI                        3.1415926535897932384626433832795f
#define C_E                         2.7182818284590452353602874713527f
#define C_2PI                       6.283185307179586476925286766559f

//@cmp.def.start
//component defines






















































































//@cmp.def.end


//-----------------------------------------------------------------------------------------
// generated using template: common_variables.template-------------------------------------
// true global variables



//@cmp.var.start
// variables
double _3_ph_pmsm1_machine_wrapper1__out[3];

double _constant2__out = 4.0;
double _constant6__out = 1.0;
double _constant7__out = 0.0;
double _constant8__out = 1.0;
double _ia1_ia1__out;
double _ia3_ia1__out;
double _integrator__out;
double _reference__out;
double _step2__out;
double _subsystem1_constant1__out = 1.0;
double _subsystem1_constant10__out = -21.0;
double _subsystem1_constant11__out = 0.5176;
double _subsystem1_constant12__out = 0.0068;
double _subsystem1_constant13__out = 3.0;
double _subsystem1_constant14__out = 2.0;
double _subsystem1_constant15__out = 0.5;
double _subsystem1_constant16__out = 1025.0;
double _subsystem1_constant17__out = 3.14;
double _subsystem1_constant2__out = 0.08;
double _subsystem1_constant3__out = 3.0;
double _subsystem1_constant4__out = 1.0;
double _subsystem1_constant5__out = 0.035;
double _subsystem1_constant6__out = 1.0;
double _subsystem1_constant7__out = 116.0;
double _subsystem1_constant8__out = 0.4;
double _subsystem1_constant9__out = 5.0;
double _subsystem2_bus_split1__out;
double _subsystem2_bus_split1__out1;
double _subsystem2_bus_split1__out2;
double _tidal_speed__out;
double _va1_va1__out;
double _va2_va1__out;
double _range_shifter_const__out = 0.5;
double _mean_value2__out;
double _subsystem1_mathematical_function4__out;
double _subsystem1_product12__out;
double _subsystem1_product4__out;
double _subsystem1_mathematical_function1__out;
double _subsystem1_product7__out;
double _gain2__out;
double _gain3__out;
double _subsystem1_limit3__out;
double _subsystem1_mathematical_function3__out;
double _subsystem1_product2__out;
double _mean_value3__out;
double _sum1__out;
double _subsystem1_sum2__out;
double _sum3__out;
double _subsystem1_limit1__out;
double _subsystem1_product10__out;
double _product1__out;
double _i__out;
double _p__out;
double _subsystem1_product5__out;
double _pid_controller1__out;
double _pid_controller1__pi_reg_out_int;
double _subsystem1_sum1__out;
double _sum2__out;
double _limit1__out;
double _subsystem1_product3__out;
double _limit__out;
double _subsystem1_sum3__out;
double _range_shifter_gain1__out;
double _subsystem1_product1__out;
double _range_shifter_sum3__out;
double _subsystem1_product6__out;
double _subsystem1_product8__out;
double _subsystem1_sum4__out;
double _subsystem1_mathematical_function2__out;
double _subsystem1_product9__out;
double _subsystem1_sum5__out;
double _subsystem1_limit2__out;
double _subsystem1_product11__out;
double _subsystem1_product13__out;
double _subsystem1_limit4__out;
double _gain1__out;//@cmp.var.end

//@cmp.svar.start
// state variables
double _3_ph_pmsm1_machine_wrapper1__model_load;
double _integrator__state;
double _step2__state;
double _mean_value2__vector[100];
double _mean_value2__sum;
X_Int32 _mean_value2__cnt_i;
X_Int32 _mean_value2__cnt_j;
double _mean_value3__vector[100];
double _mean_value3__sum;
X_Int32 _mean_value3__cnt_i;
X_Int32 _mean_value3__cnt_j;
double _pid_controller1__integrator_state;
double _pid_controller1__filter_state;//@cmp.svar.end

//
// Tunable parameters
//
static struct Tunable_params {
} __attribute__((__packed__)) tunable_params;

void *tunable_params_dev0_cpu0_ptr = &tunable_params;

// Dll function pointers
#if defined(_WIN64)
#else
// Define handles for loading dlls
#endif








// generated using template: virtual_hil/custom_functions.template---------------------------------
void ReInit_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rReInitTimer");
#endif
    //@cmp.init.block.start
    _3_ph_pmsm1_machine_wrapper1__model_load = 0.0;
    _integrator__state = 0.0;
    _step2__state = 0x0;
    _mean_value2__sum = 0;
    _mean_value2__cnt_i = 0;
    _mean_value2__cnt_j = 0;
    _mean_value2__vector[_mean_value2__cnt_i] = 0;
    HIL_OutAO(0x4001, 0.0f);
    HIL_OutAO(0x4007, 0.0f);
    HIL_OutAO(0x4009, 0.0f);
    _mean_value3__sum = 0;
    _mean_value3__cnt_i = 0;
    _mean_value3__cnt_j = 0;
    _mean_value3__vector[_mean_value3__cnt_i] = 0;
    HIL_OutAO(0x4005, 0.0f);
    HIL_OutAO(0x4006, 0.0f);
    HIL_OutAO(0x400b, 0.0f);
    HIL_OutAO(0x400a, 0.0f);
    _pid_controller1__integrator_state =  0.0;
    _pid_controller1__filter_state =  0.0;
    HIL_OutAO(0x4004, 0.0f);
    HIL_OutAO(0x4002, 0.0f);
    HIL_OutAO(0x4000, 0.0f);
    HIL_OutAO(0x4003, 0.0f);
    HIL_OutAO(0x4008, 0.0f);
    //@cmp.init.block.end
}


// Dll function pointers and dll reload function
#if defined(_WIN64)
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}

#else
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}
#endif

void load_fmi_libraries_user_sp_cpu0_dev0(void) {
#if defined(_WIN64)
#else
#endif
}


void ReInit_sp_scope_user_sp_cpu0_dev0() {
    // initialise SP Scope buffer pointer
}
// generated using template: common_timer_counter_handler.template-------------------------

/*****************************************************************************************/
/**
* This function is the handler which performs processing for the timer counter.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when the timer counter expires
* if interrupts are enabled.
*
*
* @param    None
*
* @return   None
*
* @note     None
*
*****************************************************************************************/

void TimerCounterHandler_0_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_0");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Set tunable parameters
    //////////////////////////////////////////////////////////////////////////
    // Generated from the component: Constant2
    // Generated from the component: Constant6
    // Generated from the component: Constant7
    // Generated from the component: Constant8
    // Generated from the component: Subsystem1.Constant1
    // Generated from the component: Subsystem1.Constant10
    // Generated from the component: Subsystem1.Constant11
    // Generated from the component: Subsystem1.Constant12
    // Generated from the component: Subsystem1.Constant13
    // Generated from the component: Subsystem1.Constant14
    // Generated from the component: Subsystem1.Constant15
    // Generated from the component: Subsystem1.Constant16
    // Generated from the component: Subsystem1.Constant17
    // Generated from the component: Subsystem1.Constant2
    // Generated from the component: Subsystem1.Constant3
    // Generated from the component: Subsystem1.Constant4
    // Generated from the component: Subsystem1.Constant5
    // Generated from the component: Subsystem1.Constant6
    // Generated from the component: Subsystem1.Constant7
    // Generated from the component: Subsystem1.Constant8
    // Generated from the component: Subsystem1.Constant9
    // Generated from the component: range shifter.const
//////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: 3 ph PMSM1.Machine Wrapper1
    HIL_OutFloat((0x800000 + 0x40000 * 0x0 + 0x18),  _3_ph_pmsm1_machine_wrapper1__model_load);
    _3_ph_pmsm1_machine_wrapper1__out[0] = HIL_InFloat(0xc80000 + 32776);
    _3_ph_pmsm1_machine_wrapper1__out[1] = HIL_InFloat(0xc80000 + 32778);
    _3_ph_pmsm1_machine_wrapper1__out[2] = HIL_InFloat(0xc80000 + 32779);
    // Generated from the component: Ia1.Ia1
    _ia1_ia1__out = (HIL_InFloat(0xc80000 + 0x11));
    // Generated from the component: Ia3.Ia1
    _ia3_ia1__out = (HIL_InFloat(0xc80000 + 0x12));
    // Generated from the component: Integrator
    _integrator__out = _integrator__state;
    // Generated from the component: Reference
    _reference__out = XIo_InFloat(0x55000100);
    // Generated from the component: Step2
    if (_step2__state < 0.5) {
        _step2__out = 1.0;
    } else {
        _step2__out = 2.0;
    }
    // Generated from the component: Subsystem2.Bus Split1
    _subsystem2_bus_split1__out = _3_ph_pmsm1_machine_wrapper1__out[0];
    _subsystem2_bus_split1__out1 = _3_ph_pmsm1_machine_wrapper1__out[1];
    _subsystem2_bus_split1__out2 = _3_ph_pmsm1_machine_wrapper1__out[2];
    // Generated from the component: Tidal speed
    _tidal_speed__out = XIo_InFloat(0x55000104);
    // Generated from the component: Va1.Va1
    _va1_va1__out = (HIL_InFloat(0xc80000 + 0x7));
    // Generated from the component: Va2.Va1
    _va2_va1__out = (HIL_InFloat(0xc80000 + 0x8));
    // Generated from the component: Mean Value2
    if (_mean_value2__cnt_i < 100 ) {
        _mean_value2__vector[_mean_value2__cnt_i] = _ia3_ia1__out;
        _mean_value2__sum = _mean_value2__sum + _ia3_ia1__out;
        _mean_value2__cnt_i++;
    }
    else {
        _mean_value2__sum = _mean_value2__sum - _mean_value2__vector[_mean_value2__cnt_j];
        _mean_value2__sum = _mean_value2__sum + _ia3_ia1__out;
        _mean_value2__vector[_mean_value2__cnt_j] = _ia3_ia1__out;
        if (_mean_value2__cnt_j < 100 - 1 ) {
            _mean_value2__cnt_j++;
        }
        else {
            _mean_value2__cnt_j = 0;
        }
    }
    _mean_value2__out = _mean_value2__sum / _mean_value2__cnt_i;
    // Generated from the component: Input
    HIL_OutAO(0x4001, (float)_step2__out);
    // Generated from the component: Subsystem1.Mathematical function4
    _subsystem1_mathematical_function4__out = pow(_constant2__out, _subsystem1_constant14__out);
    // Generated from the component: Subsystem1.Product12
    _subsystem1_product12__out = (_subsystem1_constant15__out * _subsystem1_constant16__out * _subsystem1_constant17__out);
    // Generated from the component: Subsystem1.Product4
    _subsystem1_product4__out = (_subsystem1_constant2__out * _constant7__out);
    // Generated from the component: Subsystem1.Mathematical function1
    _subsystem1_mathematical_function1__out = pow(_constant7__out, _subsystem1_constant3__out);
    // Generated from the component: Subsystem1.Product7
    _subsystem1_product7__out = (_subsystem1_constant8__out * _constant7__out);
    // Generated from the component: Gain2
    _gain2__out = -1.0 * _subsystem2_bus_split1__out;
    // Generated from the component: Gain3
    _gain3__out = 10.0 * _subsystem2_bus_split1__out1;
    // Generated from the component: Subsystem1.Limit3
    _subsystem1_limit3__out = MIN(MAX(_subsystem2_bus_split1__out1, 1e-06), 1000000.0);
    // Generated from the component: Theta_m
    HIL_OutAO(0x4007, (float)_subsystem2_bus_split1__out2);
    // Generated from the component: Wg
    HIL_OutAO(0x4009, (float)_subsystem2_bus_split1__out1);
    // Generated from the component: Subsystem1.Mathematical function3
    _subsystem1_mathematical_function3__out = pow(_tidal_speed__out, _subsystem1_constant13__out);
    // Generated from the component: Subsystem1.Product2
    _subsystem1_product2__out = (_subsystem2_bus_split1__out1 * _constant2__out) * 1.0 / (_tidal_speed__out);
    // Generated from the component: Mean Value3
    if (_mean_value3__cnt_i < 100 ) {
        _mean_value3__vector[_mean_value3__cnt_i] = _va2_va1__out;
        _mean_value3__sum = _mean_value3__sum + _va2_va1__out;
        _mean_value3__cnt_i++;
    }
    else {
        _mean_value3__sum = _mean_value3__sum - _mean_value3__vector[_mean_value3__cnt_j];
        _mean_value3__sum = _mean_value3__sum + _va2_va1__out;
        _mean_value3__vector[_mean_value3__cnt_j] = _va2_va1__out;
        if (_mean_value3__cnt_j < 100 - 1 ) {
            _mean_value3__cnt_j++;
        }
        else {
            _mean_value3__cnt_j = 0;
        }
    }
    _mean_value3__out = _mean_value3__sum / _mean_value3__cnt_i;
    // Generated from the component: Sum1
    _sum1__out = _reference__out - _va2_va1__out;
    // Generated from the component: R^2
    HIL_OutAO(0x4005, (float)_subsystem1_mathematical_function4__out);
    // Generated from the component: Subsystem1.Sum2
    _subsystem1_sum2__out = _subsystem1_mathematical_function1__out + _subsystem1_constant4__out;
    // Generated from the component: Te
    HIL_OutAO(0x4006, (float)_gain2__out);
    // Generated from the component: Sum3
    _sum3__out = _gain3__out - _constant6__out;
    // Generated from the component: speed_3
    HIL_OutAO(0x400b, (float)_subsystem1_mathematical_function3__out);
    // Generated from the component: Subsystem1.Limit1
    _subsystem1_limit1__out = MIN(MAX(_subsystem1_product2__out, 1e-06), 1000000.0);
    // Generated from the component: Subsystem1.Product10
    _subsystem1_product10__out = (_subsystem1_constant12__out * _subsystem1_product2__out);
    // Generated from the component: lambda
    HIL_OutAO(0x400a, (float)_subsystem1_product2__out);
    // Generated from the component: Product1
    _product1__out = (_mean_value2__out * _mean_value3__out);
    // Generated from the component: I
    _i__out = 0.49 * _sum1__out;
    // Generated from the component: P
    _p__out = 0.006 * _sum1__out;
    // Generated from the component: Subsystem1.Product5
    _subsystem1_product5__out = (_subsystem1_constant5__out) * 1.0 / (_subsystem1_sum2__out);
    // Generated from the component: PID controller1
    _pid_controller1__pi_reg_out_int = _pid_controller1__integrator_state + 10.0 * _sum3__out;
    _pid_controller1__out = _pid_controller1__pi_reg_out_int;
    // Generated from the component: Subsystem1.Sum1
    _subsystem1_sum1__out = _subsystem1_limit1__out + _subsystem1_product4__out;
    // Generated from the component: Pout
    HIL_OutAO(0x4004, (float)_product1__out);
    // Generated from the component: Sum2
    _sum2__out = _p__out + _integrator__out;
    // Generated from the component: Limit1
    _limit1__out = MIN(MAX(_pid_controller1__out, 0.0), 30.0);
    // Generated from the component: Subsystem1.Product3
    _subsystem1_product3__out = (_subsystem1_constant1__out) * 1.0 / (_subsystem1_sum1__out);
    // Generated from the component: Limit
    _limit__out = MIN(MAX(_sum2__out, -0.6), 0.6);
    // Generated from the component: Subsystem1.Sum3
    _subsystem1_sum3__out = _subsystem1_product3__out - _subsystem1_product5__out;
    // Generated from the component: range shifter.Gain1
    _range_shifter_gain1__out = 0.5 * _limit__out;
    // Generated from the component: Subsystem1.Product1
    _subsystem1_product1__out = (_subsystem1_constant6__out) * 1.0 / (_subsystem1_sum3__out);
    // Generated from the component: range shifter.Sum3
    _range_shifter_sum3__out = _range_shifter_gain1__out + _range_shifter_const__out;
    // Generated from the component: Subsystem1.Product6
    _subsystem1_product6__out = (_subsystem1_constant7__out) * 1.0 / (_subsystem1_product1__out);
    // Generated from the component: Subsystem1.Product8
    _subsystem1_product8__out = (_subsystem1_constant10__out) * 1.0 / (_subsystem1_product1__out);
    // Generated from the component: Modulation Signal
    HIL_OutAO(0x4002, (float)_range_shifter_sum3__out);
    // Generated from the component: Subsystem1.Sum4
    _subsystem1_sum4__out = _subsystem1_product6__out - _subsystem1_product7__out - _subsystem1_constant9__out;
    // Generated from the component: Subsystem1.Mathematical function2
    _subsystem1_mathematical_function2__out = pow(M_E, _subsystem1_product8__out);
    // Generated from the component: Subsystem1.Product9
    _subsystem1_product9__out = (_subsystem1_constant11__out * _subsystem1_mathematical_function2__out * _subsystem1_sum4__out);
    // Generated from the component: Subsystem1.Sum5
    _subsystem1_sum5__out = _subsystem1_product9__out + _subsystem1_product10__out;
    // Generated from the component: Cp
    HIL_OutAO(0x4000, (float)_subsystem1_sum5__out);
    // Generated from the component: Subsystem1.Limit2
    _subsystem1_limit2__out = MIN(MAX(_subsystem1_sum5__out, 1e-06), 1000000.0);
    // Generated from the component: Subsystem1.Product11
    _subsystem1_product11__out = (_subsystem1_mathematical_function3__out * _subsystem1_limit2__out * _subsystem1_mathematical_function4__out * _subsystem1_product12__out);
    // Generated from the component: Pm
    HIL_OutAO(0x4003, (float)_subsystem1_product11__out);
    // Generated from the component: Subsystem1.Product13
    _subsystem1_product13__out = (_subsystem1_product11__out) * 1.0 / (_subsystem1_limit3__out);
    // Generated from the component: Subsystem1.Limit4
    _subsystem1_limit4__out = MIN(MAX(_subsystem1_product13__out, 1e-06), 1000000.0);
    // Generated from the component: Gain1
    _gain1__out = -1.0 * _subsystem1_limit4__out;
    // Generated from the component: Tm
    HIL_OutAO(0x4008, (float)_gain1__out);
//@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: 3 ph PMSM1.Machine Wrapper1
    _3_ph_pmsm1_machine_wrapper1__model_load = _gain1__out;
    // Generated from the component: Integrator
    _integrator__state += _i__out * 0.0001;
    // Generated from the component: Step2
    if (_step2__state <= 0.5)
        _step2__state += 0.0001;
    // Generated from the component: PID controller1
    _pid_controller1__integrator_state += 100.0 * _sum3__out * 0.0001;
    //@cmp.update.block.end
}
// ----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------